<?php

class owFormInputButton extends owFormInput
{
    var $type='button';
}

?>