<?php

class owFormPassword extends owFormText
{

}

?>