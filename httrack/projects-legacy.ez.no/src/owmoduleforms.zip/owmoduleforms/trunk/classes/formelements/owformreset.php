<?php

class owFormReset extends owFormInput
{

}

?>