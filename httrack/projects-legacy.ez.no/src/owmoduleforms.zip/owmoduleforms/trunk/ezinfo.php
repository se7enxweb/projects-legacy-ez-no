<?php

class owModuleFormsInfo
{
    static function info()
    {
        return array(
        	'Name'      => '<a href="http://projects.ez.no/owmoduleforms">OW Module Forms</a> extension',
            'Version'   => '1.0.0',
            'Copyright' => 'Copyright (C) 2010-2011 Franck Magnan <franck.magnan@openwide.fr>',
            'License'   => 'GNU General Public License v2.0',
        );
    }
}

?>