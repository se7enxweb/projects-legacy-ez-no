<?php /* #?ini charset="utf-8"?

[ezjscServer]
FunctionList[]=ezjscowforms

[ezjscServer_ezjscowforms]
Class=ezjscOwFormServerFunctions
File=extension/owmoduleforms/classes/ezjscowformserverfunctions.php

[eZJSCore]
PreferredLibrary=jquery

*/ ?>