<?php /* #?ini charset="utf-8"?

[RoleSettings]
PolicyOmitList[]=owmoduleformssamples/register
PolicyOmitList[]=owmoduleformssamples/calculator

*/ ?>