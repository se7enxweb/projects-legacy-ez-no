<?php 

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/is_ssl/autoloads/ezis_ssloperator.php',
                                    'class' => 'eZIsSSLOperator',
                                    'operator_names' => array( 'is_ssl' ) );
?>