<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=is_ssl

*/ ?>