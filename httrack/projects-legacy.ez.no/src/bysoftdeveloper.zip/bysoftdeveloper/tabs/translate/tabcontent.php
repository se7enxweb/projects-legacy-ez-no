<div id='bysoftdeveloper-translate-wrap'>
	<p>Source string:</p>
	<textarea id='bysoftdeveloper-translate-source' rows=5 onkeyup='javascript:bysoftdeveloperTranslate();' style='margin-left:20px;width:90%'></textarea>
	<p>Converted applicable characters in string:</p>
	<textarea id='bysoftdeveloper-translate-result' rows=5 style='margin-left:20px;width:90%'></textarea>
</div>