<?php /* #?ini charset="utf-8"?

[RegionalSettings]
#DevelopmentMode=disabled
#Locale=eng-GB

[TemplateSettings]
TemplateCache=disabled
TemplateCompile=disabled
ShowUsedTemplates=enabled
Debug=enabled
# turn on this, will show info about template file in page.
#ShowXHTMLCode=enabled
#TemplateOptimization=disabled
#TemplateCompression=disabled
#DevelopmentMode=disabled

[ContentSettings]
ViewCaching=disabled
StaticCache=disabled

[OverrideSettings]
Cache=disabled

[DebugSettings]
DebugOutput=enabled
#DisplayDebugWarnings=disabled


*/?>
