<?php /*

[NavigationPart]
Part[ezdevelopernavigationpart]=Developer

[TopAdminMenu]
# Activate the newsletter tab here to show the tab
# Older layout tabs
Tabs[]=bysoftdeveloper

[Topmenu_bysoftdeveloper]
NavigationPartIdentifier=ezbysoftdevelopernavigationpart
Name=Developer
Tooltip=Developer menu
URL[]
URL[default]=bysoftdeveloper/class
URL[browse]=bysoftdeveloper/class
URL[edit]=bysoftdeveloper/class
Enabled[]
Enabled[default]=true
Enabled[browse]=true
Enabled[edit]=true
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true


*/ ?>
