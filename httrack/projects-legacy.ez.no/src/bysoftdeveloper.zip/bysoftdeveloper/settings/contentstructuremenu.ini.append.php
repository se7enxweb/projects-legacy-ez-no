<?php /*
#?ini charset="utf-8"?

[TreeMenu]
# If set to enabled, the admin tree menu is fetched and built dynamically on
# fly. Requires a web browser with AJAX support.
#Dynamic=disabled

#ShowClasses[]
#ShowClasses[]=folder

*/?>
