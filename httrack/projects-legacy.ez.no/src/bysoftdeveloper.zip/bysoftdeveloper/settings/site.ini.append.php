<?php /* #?ini charset="utf-8"?
# do not modify it
[TemplateSettings]
ExtensionAutoloadPath[]=bysoftdeveloper

ShowUsedTemplates=enabled
Debug=enabled
ShowXHTMLCode=disabled
DevelopmentMode=enabled


[DebugSettings]
DebugOutput=enabled

# do not modify it
[RoleSettings]
PolicyOmitList[]=bysoftdeveloper

# do not modify it
[SiteAccessSettings]
AnonymousAccessList[]=bysoftdeveloper



################################
#
#   Your configuration below:
#
################################
[RegionalSettings]
#Locale=eng-GB

*/?>
