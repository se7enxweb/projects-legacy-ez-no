<?php /*

[SchemaSettings]
SchemaPaths[sqlite3]=extension/ezsqlite3/ezdb/dbms-schema/ezsqliteschema.php
SchemaHandlerClasses[sqlite3]=eZSQLiteSchema

SchemaPaths[sqlite]=extension/ezsqlite3/ezdb/dbms-schema/ezsqliteschema.php
SchemaHandlerClasses[sqlite]=eZSQLiteSchema

*/ ?>