<?php /*

[DatabaseSettings]
ImplementationAlias[sqlite3]=ezsqlite3

*/ ?>