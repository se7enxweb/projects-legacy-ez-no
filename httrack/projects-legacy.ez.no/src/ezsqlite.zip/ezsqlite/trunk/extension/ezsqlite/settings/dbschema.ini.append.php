<?php /*

[SchemaSettings]
SchemaPaths[sqlite]=extension/ezsqlite/ezdb/dbms-schema/ezsqliteschema.php
SchemaHandlerClasses[sqlite]=eZSQLiteSchema

*/ ?>