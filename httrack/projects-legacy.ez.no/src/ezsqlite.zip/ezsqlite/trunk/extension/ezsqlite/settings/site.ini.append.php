<?php /*

[DatabaseSettings]
ImplementationAlias[sqlite]=ezsqlite

*/ ?>