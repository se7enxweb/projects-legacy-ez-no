<?php
/**
 * SNMP Handler used to retrieve info-related information, eg. info that is not
 * subject to constant change. Version nr. etc...
 * Handles access to the 'info' branch of the MIB (3)
 *
 * @author G. Giunta
 * @version $Id: ezsnmpdinfohandler.php 85 2010-02-08 11:33:32Z gg $
 * @copyright (C) G. Giunta 2009
 * @license code licensed under the GPL License: see README
 */

class eZsnmpdInfoHandler extends eZsnmpdHandler {

    function oidRoot()
    {
        return '3.';
    }

    /*function oidList( )
    {
        return array( '3.1', '3.2', '3.3' );
    }*/

    function get( $oid )
    {
        $internaloid = preg_replace( '/\.0$/', '', $oid );
        switch( $internaloid )
        {
            case '3.1':
                return array(
                    'oid' => $oid,
                    'type' => eZSNMPd::TYPE_STRING,
                    'value' => eZPublishSDK::version(),
                );

            case '3.2':
                return array(
                    'oid' => $oid,
                    'type' => eZSNMPd::TYPE_STRING,
                    'value' => eZSNMPd::VERSION,
                );

            case '3.3':
                return array(
                    'oid' => $oid,
                    'type' => eZSNMPd::TYPE_STRING,
                    'value' => $GLOBALS['eZCurrentAccess']['name'],
            );
        }

        return self::NO_SUCH_OID; // oid not managed
    }

    function getMIBTree()
    {
        return array(
            'name' => 'eZPublish',
            'children' => array(
                3 => array(
                    'name' => 'info',
                    'children' => array(
                        1 => array(
                            'name' => 'ezpInfoeZPVersion',
                            'syntax' => 'DisplayString',
                            'description' => 'The eZ Publish release number.'
                        ),
                        2 => array(
                            'name' => 'ezpInfoezsnmpdVersion',
                            'syntax' => 'DisplayString',
                            'description' => 'The ezsnmpd extension release number.'
                        ),
                        3 => array(
                            'name' => 'ezpInfoSiteAccess',
                            'syntax' => 'DisplayString',
                            'description' => 'The siteaccess in use when answering this request.'
                        ),
                    )
                )
            )
        );
    }

    /*function getMIB()
    {
        return '
info            OBJECT IDENTIFIER ::= {eZPublish 3}

ezpInfoeZPVersion OBJECT-TYPE
    SYNTAX          DisplayString
    MAX-ACCESS      read-only
    STATUS          current
    DESCRIPTION
            "The eZ Publish release number."
    ::= { info 1 }

ezpInfoezsnmpdVersion OBJECT-TYPE
    SYNTAX          DisplayString
    MAX-ACCESS      read-only
    STATUS          current
    DESCRIPTION
            "The ezsnmpd extension release number."
    ::= { info 2 }

ezpInfoSiteAccess OBJECT-TYPE
    SYNTAX          DisplayString
    MAX-ACCESS      read-only
    STATUS          current
    DESCRIPTION
    "The siteaccess in use when answering this request."
    ::= { info 3 }';
    }*/
}
?>