<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezsnmpd

ModuleList[]=snmp

*/ ?>