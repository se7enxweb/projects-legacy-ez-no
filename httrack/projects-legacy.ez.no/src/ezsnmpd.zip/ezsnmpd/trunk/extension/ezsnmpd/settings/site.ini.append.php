<?php /*

[RoleSettings]
PolicyOmitList[]=snmp/mib

/* ?>