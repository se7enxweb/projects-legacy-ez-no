<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[snmpmonitorpart]=SNMP Monitor

[TopAdminMenu]
Tabs[]=snmpmonitor

[Topmenu_snmpmonitor]
Name=SNMP Monitor
Tooltip=Monitor remote servers via the SNMP protocol
URL[default]=snmpmonitor/summary
NavigationPartIdentifier=snmpmonitorpart

Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false

Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>