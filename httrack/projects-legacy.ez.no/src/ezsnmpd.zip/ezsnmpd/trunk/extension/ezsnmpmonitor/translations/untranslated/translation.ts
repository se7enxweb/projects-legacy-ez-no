<!DOCTYPE TS><TS>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>SNMP Monitor</source>
        <comment>Navigation part</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/snmpmonitor</name>
</context>
</TS>