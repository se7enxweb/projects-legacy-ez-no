<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=ezsnmpmonitor

[CronjobPart-rotatewslogs]
Scripts[]=snmppoller.php

*/ ?>
