<?php /*

[ModuleSettings]
ExtensionRepositories[]=sitemap

*/ ?>