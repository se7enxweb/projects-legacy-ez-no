<?php /*

[SitemapSettings]
SiteURL=http://www.mysite.com
RootNode=2
MaxDepth=5
ClassArray[]
ClassArray[]=folder
ClassArray[]=article

*/ ?>