<?php
class wikidesignInfo
{
    static function info()
    {
        return array(
            'Name' => "Wiki design",
            'Version' => "0.x",
            'Copyright' => "Copyright (C) 2006-2009 Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>