<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezpediadesign

# [RegionalSettings]
# TranslationExtensions[]=ezpediadesign

*/ ?>