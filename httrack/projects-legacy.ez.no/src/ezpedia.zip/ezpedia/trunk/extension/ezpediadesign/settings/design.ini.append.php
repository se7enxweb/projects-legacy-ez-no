<?php /* #?ini charset="utf-8"?
# eZ publish configuration file for modules

[StylesheetSettings]
SiteCSS=extension/ezpediadesign/design/wiki/stylesheets/wiki_t1/site-colors.css
ClassesCSS=extension/ezpediadesign/design/wiki/stylesheets/wiki_t1/classes-colors.css

[ExtensionSettings]
DesignExtensions[]=ezpediadesign


[ExtensionSettings]
DesignExtensions[]=wiki

*/ ?>
