<?php
/**
 * File containing the eZKeyConverter class.
 *
 * @package import
 * @version //autogentag//
 * @copyright Copyright (C) 2007 xrow. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl.txt GPL License
 */
class eZKeyConverter
{
	var $data  = array();
	var $defaults  = array();
	function eZKeyConverter( )
	{

	}
	function setDefault( $namespace , $value )
	{
		$this->defaults[$namespace] = $value;
	}
	function generateKey( $old )
	{
		//old should accept arrays too
		return md5( $old );
	}
	function convert( $namespaces, $old )
	{
		if ( !is_array( $namespaces ) )
		{
			$namespaces = array( $namespaces );
		}
		$hash = eZKeyConverter::generateKey( $old );
		foreach ( $namespaces as $namespace )
		{
			if ( array_key_exists( $namespace , $this->data ) and array_key_exists( $hash , $this->data[$namespace] ) )
			{
				return $this->data[$namespace][$hash];
			}
		}
		foreach ( $namespaces as $namespace )
		{
			if ( array_key_exists( $namespace , $this->defaults ) )
			{
				return $this->defaults[$namespace];
			}
		}
		return false;
	}
	function hasRegister( $namespace = false, $old = false )
	{
		if ( $namespace and $old )
		{
			$hash = eZKeyConverter::generateKey( $old );
			if ( array_key_exists( $namespace, $this->data ) and array_key_exists( $hash, $this->data[$namespace] ) )
				return true;
		}
		return false;
	}
	function register( $namespace, $old, $new, $force = false )
	{	
		if ( !$old or !$new )
			return false;

		$hash = eZKeyConverter::generateKey( $old );
		$this->data[$namespace][$hash] = $new;
	}
	//does something to cleanup this mess
	function reset()
	{
		$this->data = array();
	}
	function &instance( )
	{
		if ( array_key_exists( "eZKeyConverter", $GLOBALS ) and ( $GLOBALS["eZKeyConverter"] ) )
		{
			$impl =& $GLOBALS["eZKeyConverter"];
		}
		else
		{
			$impl =& $GLOBALS['eZKeyConverter'];
			$impl = new eZKeyConverter();  
			$GLOBALS["eZKeyConverter"] =& $impl;
		}
		return $impl;
	}
}
?>