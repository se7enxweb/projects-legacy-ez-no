<?php

abstract class eZImportFilter
{
    abstract public function filter( $text );
}
?>