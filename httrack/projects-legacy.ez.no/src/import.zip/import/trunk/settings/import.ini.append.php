<?php /* #?ini charset="utf-8"?
[ImportSettings]
RepositoryDirectories[]=extension/import/classes
ExtensionDirectories[]=import
#HandlerAlias[contentclass]=ezcontentclass
FilterExtensionDirectories[]=import
*/ ?>