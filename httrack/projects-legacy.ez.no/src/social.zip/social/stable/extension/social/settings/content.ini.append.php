<?php /*

[DataTypeSettings]
ExtensionDirectories[]=social
AvailableDataTypes[]=axsocial

*/ ?>
