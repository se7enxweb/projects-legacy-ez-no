<?php /*

[ExtensionSettings]
DesignExtensions[]=social

*/ ?>
