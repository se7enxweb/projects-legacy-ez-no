<?php

class socialInfo
{
    static function info()
    {
        $eZCopyrightString = 'Copyright (C) '.date('Y').' all2e GmbH & xrow GmbH';

        return array( 'Name'      => '<a href="http://projects.ez.no/social">Social</a> extension',
                      'Version'   => '1.0',
                      'Copyright' => $eZCopyrightString,
                      'License'   => 'GNU General Public License v2.0'
                    );
    }
}

?>
