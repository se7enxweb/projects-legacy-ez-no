<?php

class axSocialFacebookMobileAPI implements axSocialInterface
{
    public function __construct( $blockName )
    {
        $this->baseURI = 'http://m.facebook.com';
        $this->curlOptions['cookieFile'] = 'var/log/fb'.eZUser::currentUserID().'.cookie.txt';
        $this->curlOptions['UserAgent'] = $_SERVER['HTTP_USER_AGENT'];
        $this->ini = eZINI::instance( 'axsocial.ini' );
        if( $this->ini->hasGroup( axSocialInterface::INIBLOCKPREFIX . $blockName ) )
        {
            $this->accessOptions = $this->ini->group( axSocialInterface::INIBLOCKPREFIX . $blockName );
        }
        else
        {
            eZDebug::writeError( "Undefined group: '$blockName' in " . $this->ini->FileName, __METHOD__ );
            return null;
        }
    }

    
    public function connect()
    {
        $login = $this->accessOptions['Login'];
        $password = $this->accessOptions['Password'];
        
        $this->sendCurlRequest( $this->baseURI );
        
        $fbLoginURI = $this->getFormActionURL( $this->lastRequest['data'], 'login_form' );
        $fbLoginParams = $this->getInputValuesFromFormContent( $this->lastRequest['data'], 'login_form' );
        $fbLoginParams .= '&email=' . $login . '&pass=' . $password;
        
        $this->sendCurlRequest( $fbLoginURI, $fbLoginParams );
    }
    
        
    public function disconnect()
    {
        return true;
    }
    
    /*!
     * post( $message ):
     * @TODO: ProfileID or WallID to post contents to can be choosed dynamicly or per ini
     */
    public function post( $message )
    {
        $this->sendCurlRequest( $this->baseURI );
        
        $fbPostMessageURI = $this->baseURI . $this->getFormActionURL( $this->lastRequest['data'], 'composer_form' );
        $fbPostParams = $this->getInputValuesFromFormContent( $this->lastRequest['data'], 'composer_form' );
        $fbPostParams .= '&status=' . $message;
        
        $this->sendCurlRequest( $fbPostMessageURI, $fbPostParams );
    }
    
    /*!
     * 
     */
    public function sendCurlRequest( $url, $postData = false )
    {
        $curl = curl_init();
        
        if( $postData !== false && $postData != '' )
        {
            curl_setopt( $curl, CURLOPT_POST, 1 );
            curl_setopt( $curl, CURLOPT_POSTFIELDS, $postData );
        }
        
        curl_setopt( $curl, CURLOPT_URL,              $url );
        curl_setopt( $curl, CURLOPT_FOLLOWLOCATION,   1 );
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER,   1 );
        curl_setopt( $curl, CURLOPT_HEADER,           0 );     // output headers above page content
        curl_setopt( $curl, CURLINFO_HEADER_OUT,      true );      // also get headers via curlinfo (not necessary)
        curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER,   false );
        curl_setopt( $curl, CURLOPT_ENCODING,         "" );
        curl_setopt( $curl, CURLOPT_COOKIEFILE,       $this->curlOptions['cookieFile'] );
        curl_setopt( $curl, CURLOPT_COOKIEJAR,        $this->curlOptions['cookieFile'] );
        curl_setopt( $curl, CURLOPT_USERAGENT,        $this->curlOptions['UserAgent'] );
        
        $this->lastRequest['data'] = curl_exec( $curl );
        $this->lastRequest['header'] = curl_getinfo( $curl );
        
        curl_close( $curl );
        return $this->lastRequest;
    }
    
    public function getInputValuesFromFormContent( $contents, $form_id )
    {
        $inputParams = array();
        $doc = new DOMDocument();
        if( $doc->loadhtml( $contents ) )
        {
            $xpath = new DOMXpath( $doc );
            foreach( $xpath->query( '//form[@id="'.$form_id.'"]//input' ) as $eInput )
            {
                $inputParams[$eInput->getAttribute( 'name' )] = $eInput->getAttribute( 'value' );
            }
        }
        $tmp = array();
        foreach( $inputParams as $k => $v )
        {
            $tmp[] = $k . '=' . $v;
        }
        $inputParams = join( '&', $tmp );
        return $inputParams;
    }
    
    public function getFormActionURL( $contents, $form_id )
    {
        $inputParams = array();
        $doc = new DOMDocument();
        if( $doc->loadhtml( $contents ) )
        {
            $xpath = new DOMXpath( $doc );
            foreach( $xpath->query( '//form[@id="'.$form_id.'"]' ) as $eForm )
            {
                $inputParams[] = $eForm->getAttribute( 'action' );
            }
        }
        return $inputParams[0];
    }
    
    private $ini;
    private $connection;
    private $accessOptions;
    private $baseURI;
    private $curlOptions;
    private $lastRequest;
}


?>
