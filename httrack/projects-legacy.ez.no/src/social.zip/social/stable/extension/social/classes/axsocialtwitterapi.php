<?php

class axSocialTwitterAPI implements axSocialInterface
{
    public function __construct( $blockName )
    {
        $this->ini = eZINI::instance( 'axsocial.ini' );
        if( $this->ini->hasGroup( axSocialInterface::INIBLOCKPREFIX . $blockName ) )
        {
            $this->accessOptions = $this->ini->group( axSocialInterface::INIBLOCKPREFIX . $blockName );
        }
        else
        {
            eZDebug::writeError( "Undefined group: '$blockName' in " . $this->ini->FileName, __METHOD__ );
            return null;
        }
    }
    
    public function connect()
    {
        $this->connection = new TwitterOAuth(
            $this->accessOptions['ConsumerKey'],
            $this->accessOptions['ConsumerSecret'],
            $this->accessOptions['OAuthToken'],
            $this->accessOptions['OAuthTokenSecret']
        );
    }
    
    public function disconnect()
    {
        return true;
    }
    
    public function post( $message )
    {
        $res = $this->connection->post( 'statuses/update', array( 'status' => $message ) );
    }
    
    public function getAuthorizeURL()
    {
        $requestToken = $this->connection->getRequestToken();
        $authorizeURL = $this->connection->getAuthorizeURL( $requestToken['oauth_token'] );
        return $authorizeURL;
    }
    
    private $ini;
    private $connection;
    private $accessOptions;
}


?>
