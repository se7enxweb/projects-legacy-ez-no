<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[ezstaticexportnavigationpart]=Static export

[TopAdminMenu]
Tabs[]=ezstaticexport

[Topmenu_ezstaticexport]
NavigationPartIdentifier=ezstaticexportnavigationpart
Name=Export Statique
Tooltip=Manage static export
URL[]
URL[default]=ezstaticexport/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>
