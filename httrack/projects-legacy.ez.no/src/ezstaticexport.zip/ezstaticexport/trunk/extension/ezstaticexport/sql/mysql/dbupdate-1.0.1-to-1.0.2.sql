ALTER TABLE `ezstaticexport_export` ADD `total` BIGINT NOT NULL DEFAULT '0', ADD `offset` INT NOT NULL DEFAULT '0';
