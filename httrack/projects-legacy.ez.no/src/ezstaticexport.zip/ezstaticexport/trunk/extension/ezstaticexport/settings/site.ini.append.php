<?php /* #?ini charset="utf-8"?
[TemplateSettings]
ExtensionAutoloadPath[]=ezstaticexport

[RegionalSettings]
TranslationExtensions[]=ezstaticexport
*/?>
