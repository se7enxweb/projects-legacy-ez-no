<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=ezstaticexport
AvailableEventTypes[]=event_ezstaticexport

*/?>
