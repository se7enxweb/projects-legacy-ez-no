<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=ezstaticexport

[CronjobPart-staticexport]
Scripts[]=staticexport.php
Scripts[]=workflow.php

[CronjobPart-prestaticexport]
Scripts[]=interruptexport.php

*/ ?>
