<?php

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] =

 array( 'script'         => 'extension/ezstaticexport/autoloads/ezstaticexportoperators.php',
        'class'          => 'eZStaticExportOperators',
        'operator_names' => array( 'ezstaticexport_tokenispresent' ) );

 

?>
