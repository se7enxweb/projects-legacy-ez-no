<?php /* #?ini charset="utf8"?

[Tool]
AvailableToolArray[]=static_cache_info

*/ ?>