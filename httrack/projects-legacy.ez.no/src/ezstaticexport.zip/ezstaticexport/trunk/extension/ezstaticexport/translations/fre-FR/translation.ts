<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="fr_FR">
<context>
    <name>design/admin/node/view/full</name>
    <message>
        <location filename="" line="1107558400"/>
        <source>Another language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Edit the contents of this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Last modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Move this item to another location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Node ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Not available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Object ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Remove this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>You do not have permissions to edit this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>You do not have permissions to move this item to another location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>You do not have permissions to remove this item.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/ezstaticexport</name>
    <message>
        <location filename="" line="1107558400"/>
        <source>An export is running you will not be able to publish any content until it is finished</source>
        <translation type="unfinished">Un export est en cours, vous ne pourrez pas publier du contenu avant qu&apos;il soit terminé</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Choose a date</source>
        <translation type="unfinished">Veuillez choisir une date</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Choose Target</source>
        <translation type="unfinished">Veuillez choisir une cible</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Date</source>
        <translation type="unfinished">Date</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Day</source>
        <translation type="unfinished">Jour</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Default Target</source>
        <translation type="unfinished">Cible par défaut</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Delete token</source>
        <translation type="unfinished">Supprimer le jeton</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Export id</source>
        <translation type="unfinished">Identifiant de l&apos;export</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Export the subtree</source>
        <translation type="unfinished">Exporter le sous-arbre</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Exported on yyy/mm/dd at hh:mm:ss</source>
        <translation type="unfinished">Exporté le jj/mm/aaaa à hh:mm:ss</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Flag as JSP</source>
        <translation type="unfinished">Marquer comme JSP</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Hour</source>
        <translation type="unfinished">Heure</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Immediate export to another target</source>
        <translation type="unfinished">Export immédiat dans une autre cible</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Immediate export to default target</source>
        <translation type="unfinished">Export immédiat dans la cible par défaut</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Is export running ?</source>
        <translation type="unfinished">Est-ce que l&apos;export est en cours ?</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>List</source>
        <translation type="unfinished">Liste</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Minutes</source>
        <translation type="unfinished">Minutes</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Month</source>
        <translation type="unfinished">Mois</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Name</source>
        <translation type="unfinished">Nom</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>NodeID to export</source>
        <translation type="unfinished">ID du noeud à exporter</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Option</source>
        <translation type="unfinished">Option</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Recurrence</source>
        <translation type="unfinished">Récurrence</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Running Export</source>
        <translation type="unfinished">Export(s) en cours</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Scheduled export</source>
        <translation type="unfinished">Export planifié</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Scheduled exports</source>
        <translation type="unfinished">Exports plannifiés</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Show running export(s)</source>
        <translation type="unfinished">Voir l&apos; (les) export(s) en cours</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Show static exports list</source>
        <translation type="unfinished">Voir la liste des exports statiques</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Static export</source>
        <translation type="unfinished">Export statique</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Subtree exported ?</source>
        <translation type="unfinished">Le sous-arbre sera-t&apos;il exporté ?</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Target Name</source>
        <translation type="unfinished">Nom de la cible</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Token</source>
        <translation type="unfinished">Jeton</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Token deleted</source>
        <translation type="unfinished">Le jeton a été supprimé</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Value</source>
        <translation type="unfinished">Valeur</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>View informations</source>
        <translation type="unfinished">Voir les informations</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>View scheduled export(s)</source>
        <translation type="unfinished">Voir l&apos;(les) export planifié(s)</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Week</source>
        <translation type="unfinished">Semaine</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Flags list</source>
        <translation type="unfinished">Liste des marqueurs</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Content type flag list</source>
        <translation type="unfinished">Liste des type de contenus pour les marqueurs</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Content type</source>
        <translation type="unfinished">Type de contenu</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Flag node as JSP</source>
        <translation type="unfinished">Marquer le noeud comme JSP</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Flag node as HTML</source>
        <translation type="unfinished">Marquer le noeud comme HTML</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Flag subtree as JSP</source>
        <translation type="unfinished">Marquer le sous arbre comme JSP</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Flag subtree as HTML</source>
        <translation type="unfinished">Marquer le sous arbre comme HTML</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Exported as %content_type</source>
        <translation type="unfinished">Exporté comme %content_type</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Assigned as %flag_type</source>
        <translation type="unfinished">Marqué comme %flag_type</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>None</source>
        <translation type="unfinished">Aucune</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Hourly</source>
        <translation type="unfinished">Horaire</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Daily</source>
        <translation type="unfinished">Quotidienne</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Weekly</source>
        <translation type="unfinished">Hebdomadaire</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Monthly</source>
        <translation type="unfinished">Mensuelle</translation>
    </message>
</context>
<context>
    <name>extension/ezstaticexport/flaglist</name>

    <message>
        <location filename="" line="1107558400"/>
        <source>Node</source>
        <translation type="unfinished">Noeud</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Nodes</source>
        <translation type="unfinished">Noeuds</translation>
    </message>

    <message>
        <location filename="" line="1107558400"/>
        <source>Scope</source>
        <translation type="unfinished">Portée</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Content-type</source>
        <translation type="unfinished">Type de contenu</translation>
    </message>
    <message>
        <location filename="" line="1107558400"/>
        <source>Remove selected</source>
        <translation type="unfinished">Supprimer la sélection</translation>
    </message>

</context>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <location filename="" line="1107558400"/>
        <source>Static export</source>
        <translation type="unfinished">Export statique</translation>
    </message>
</context>
</TS>
