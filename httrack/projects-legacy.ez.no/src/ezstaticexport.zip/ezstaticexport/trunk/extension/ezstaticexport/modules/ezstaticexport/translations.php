<?php
// see settings/menu.ini line 63 for more details.
// Tab translation
ezi18n( 'kernel/navigationpart', 'Static export', 'Export statique' );

// page top path translation
ezi18n( 'extension/ezstaticexport', 'Static export', 'Export statique' );

?>
