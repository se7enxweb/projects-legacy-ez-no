<?php /* #?ini charset="utf-8"?

[AdditionalMenuSettings]
ContextMenuTemplateArray[]=contextmenu/ezstaticexportcontextmenu.tpl
SubitemsContextMenuTemplateArray[]=contextmenu/ezstaticexportsubitemscontextmenu.tpl
SubMenuTemplateArray[]=contextmenu/ezstaticexportcontextsubmenu.tpl
*/ ?>
