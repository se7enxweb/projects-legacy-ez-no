<?php
/*
[ExtensionSettings]
DesignExtensions[]=nmattributefilter
*/
?>