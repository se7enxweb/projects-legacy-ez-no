<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/nmattributefilter/operators/templateattributefilterformoperator.php',
                                    'class' => 'TemplateAttributeFilterFormOperator',
                                    'operator_names' => array( 'attributefilterform' ) );
                                    
?>