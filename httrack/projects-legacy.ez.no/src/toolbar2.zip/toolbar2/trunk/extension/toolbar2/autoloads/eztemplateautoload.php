<?php
/**
 * File eztemplateautoload
 *
 * @package toolbar2
 * @version //autogentag//
 * @copyright Copyright (C) 2007 xrow. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl.txt GPL License
 */
$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] = array( 'script' => 'extension/toolbar2/autoloads/toolbar2operator.php',
                                    'class' => 'toolbar2Operator',
                                    'operator_names' => array( 'toolbar2' ) );
?>