<?php /* #?ini charset="utf-8"?

[Toolbar]
AvailableToolBarArray[]
AvailableToolBarArray[]=default

[Tool]
AvailableToolArray[]
AvailableToolArray[]=Tool

*/ ?>