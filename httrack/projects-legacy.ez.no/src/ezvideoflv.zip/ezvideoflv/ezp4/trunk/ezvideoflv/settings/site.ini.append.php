<?php /*
#
# $Id: site.ini.append.php 22 2009-10-04 15:18:33Z dpobel $
# $HeadURL: http://svn.projects.ez.no/ezvideoflv/ezp4/trunk/ezvideoflv/settings/site.ini.append.php $
#

[RegionalSettings]
TranslationExtensions[]=ezvideoflv

#######################################################################
# if you want to give read access to videos to all users (anonymous and
# identified), you can uncomment the following two lines so that there's
# no need to add video/read function in users' roles
# (point 7 in http://projects.ez.no/ezvideoflv#eztoc7442_3)
#######################################################################
#[RoleSettings]
#PolicyOmitList[]=video
 
*/ ?>
