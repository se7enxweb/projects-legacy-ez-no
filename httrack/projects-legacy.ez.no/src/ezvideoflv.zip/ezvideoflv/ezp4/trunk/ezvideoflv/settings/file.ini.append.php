<?php /*
#
# $Id: file.ini.append.php 22 2009-10-04 15:18:33Z dpobel $
# $HeadURL: http://svn.projects.ez.no/ezvideoflv/ezp4/trunk/ezvideoflv/settings/file.ini.append.php $
#

[BinaryFileSettings]
Handler=eZVideoFLVHandler

*/ ?>
