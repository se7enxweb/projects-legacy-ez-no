<!DOCTYPE TS><TS>
<context>
	<name>ezvideoflv/datatype</name>
	<message>
		<source>Current file and its flv version</source>
		<translation>Fichier courant et sa version FLV</translation>
	</message>
	<message>
		<source>Preview</source>
		<translation>Aperçu</translation>
	</message>
	<message>
		<source>FLV Version</source>
		<translation>Version FLV</translation>
	</message>
	<message>
		<source>Not yet generated</source>
		<translation>Pas encore généré</translation>
	</message>
	<message>
		<source>New video file</source>
		<translation>Nouveau fichier à télécharger et à convertir en FLV</translation>
	</message>
	<message>
		<source>FLV version not yet generated</source>
		<translation>La version FLV n'a pas encore été générée</translation>
	</message>
	<message>
		<source>Download the original video file</source>
		<translation>Télécharger la vidéo originale</translation>
	</message>
	<message>
		<source>No file</source>
		<translation>Aucun fichier</translation>
	</message>
	<message>
		<source>Duration</source>
		<translation>Durée</translation>
	</message>
	<message>
		<source>Unable to determine duration</source>
		<translation>Impossible de déterminer la durée de la video</translation>
	</message>
</context>
</TS>
