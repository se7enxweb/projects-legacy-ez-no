<?php /*

[CronjobSettings]
ExtensionDirectories[]=ezvideoflv

[CronjobPart-flv]
Scripts[]=convert_flv.php

*/ ?>
