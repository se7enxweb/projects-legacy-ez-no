<?php /*

[DataTypeSettings]
ExtensionDirectories[]=ezvideoflv
AvailableDataTypes[]=ezvideoflv

*/ ?>
