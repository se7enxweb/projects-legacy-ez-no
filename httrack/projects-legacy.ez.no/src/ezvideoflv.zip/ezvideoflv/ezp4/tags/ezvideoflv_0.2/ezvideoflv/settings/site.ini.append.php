<?php /*

[RegionalSettings]
TranslationExtensions[]=ezvideoflv

#######################################################################
# if you want to give read access to videos to all users (anonymous and
# identified), you can uncomment the following two lines so that there's
# no need to add video/read function in users' roles
# (point 7 in http://projects.ez.no/ezvideoflv#eztoc7442_3)
#######################################################################
#[RoleSettings]
#PolicyOmitList[]=video
 
*/ ?>
