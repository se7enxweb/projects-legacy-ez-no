<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezvideoflv
ModuleList[]=video

*/ ?>
