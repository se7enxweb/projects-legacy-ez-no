<?php /*

[ExtensionSettings]
DesignExtensions[]=ezvideoflv

*/ ?>
