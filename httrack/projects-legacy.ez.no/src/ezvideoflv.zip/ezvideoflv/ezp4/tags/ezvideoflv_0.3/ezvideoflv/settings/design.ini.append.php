<?php /*
#
# $Id: design.ini.append.php 22 2009-10-04 15:18:33Z dpobel $
# $HeadURL: http://svn.projects.ez.no/ezvideoflv/ezp4/tags/ezvideoflv_0.3/ezvideoflv/settings/design.ini.append.php $
#

[ExtensionSettings]
DesignExtensions[]=ezvideoflv

*/ ?>
