<?php /*

[RegionalSettings]
TranslationExtensions[]=ezvideoflv
 
*/ ?>
