<?php /*

[ExtensionSettings]
DesignExtensions[]=objectvalidation

*/ ?>