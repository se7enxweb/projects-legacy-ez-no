<?php /*

[ExtensionSettings]
DesignExtensions[]=ezkeyword_autocomplete

*/ ?>