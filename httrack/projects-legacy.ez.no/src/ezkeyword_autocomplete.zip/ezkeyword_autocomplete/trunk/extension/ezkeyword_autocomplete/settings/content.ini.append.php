<?php /*

# [DataTypeSettings]
# ExtensionDirectories[]=ezkeyword_autocomplete
# AvailableDataTypes[]=ezpage

*/ ?>