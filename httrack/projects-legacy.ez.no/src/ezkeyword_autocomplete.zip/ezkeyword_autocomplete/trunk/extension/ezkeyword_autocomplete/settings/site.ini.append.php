<?php /* #?ini charset="iso-8859-1"?

[SiteAccessSettings]
AnonymousAccessList[]=ajaxbackend/autocomplete_ezkeywords

[RoleSettings]
PolicyOmitList[]=ajaxbackend/autocomplete_ezkeywords

*/ ?>
