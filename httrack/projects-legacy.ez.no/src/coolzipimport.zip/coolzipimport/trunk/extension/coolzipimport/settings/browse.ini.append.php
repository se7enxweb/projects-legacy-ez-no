<?php /* #?ini charset="utf-8"?
[CoolZipImportPlace]
StartNode=content
SelectionType=single
ReturnType=NodeID
*/?>