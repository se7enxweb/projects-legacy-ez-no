Imports a zip filled with images into eZ Publish as a gallery.
DescriptionThis is a mass images import.
After our experiences with eZ WebDAV on MAC OS X , we made a production save and fast method to import a folder of images at once.
Install extension as usual.Clean cacheGo to:http://www.example.com/ezpublish-...n_site_admin/coolzipimport/importChoose .zipBrowse placewaitenjoy.Live: 
Sorry, nothing to see,  used in the extranet at

http://www.doerre-fotodesign.deCredits:http://www.coolscreen.de

Based on the oo extension
http://ez.no/community/contribs/import_export/openoffice_org_extensionContact:http://www.coolscreen.de/kontakt/Third party:PhpConcept Library - Zip Module: VincentOpenOffice.org extension: Bard=== More Information and Forum: ===http://ez.no/community/forum/exte...sentation_powerpoint_import_releasedhttp://ezpedia.org/wiki/en/ez/powerpoint_importScreenshotChangelog-- 1.0.0 initialComments