<?php /* #?ini charset="utf-8"?
# eZ publish configuration file for designs

[ExtensionSettings]
DesignExtensions[]=coolzipimport
*/?>

