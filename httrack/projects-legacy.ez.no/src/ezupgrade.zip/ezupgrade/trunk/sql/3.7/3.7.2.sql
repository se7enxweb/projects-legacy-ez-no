UPDATE ezsite_data SET value='3.7.2' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='5' WHERE name='ezpublish-release';
