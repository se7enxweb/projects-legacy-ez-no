UPDATE ezsite_data SET value='3.7.8' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='11' WHERE name='ezpublish-release';
