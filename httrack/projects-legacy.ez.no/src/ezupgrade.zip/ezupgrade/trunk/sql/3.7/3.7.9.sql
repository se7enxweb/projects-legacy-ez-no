UPDATE ezsite_data SET value='3.7.9' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='12' WHERE name='ezpublish-release';
