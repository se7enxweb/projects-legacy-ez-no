UPDATE ezsite_data SET value='3.7.3' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='6' WHERE name='ezpublish-release';
