UPDATE ezsite_data SET value='3.7.4' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='7' WHERE name='ezpublish-release';
