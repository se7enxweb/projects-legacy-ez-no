UPDATE ezsite_data SET value='3.5.11' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='17' WHERE name='ezpublish-release';
