UPDATE ezsite_data SET value='3.5.7' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='13' WHERE name='ezpublish-release';
