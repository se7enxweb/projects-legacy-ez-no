UPDATE ezsite_data SET value='3.5.9' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='15' WHERE name='ezpublish-release';
