UPDATE ezsite_data SET value='3.6.5' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='9' WHERE name='ezpublish-release';
