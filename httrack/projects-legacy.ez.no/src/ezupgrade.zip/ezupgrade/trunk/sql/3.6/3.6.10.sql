UPDATE ezsite_data SET value='3.6.10' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='14' WHERE name='ezpublish-release';
