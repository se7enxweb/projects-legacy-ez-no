UPDATE ezsite_data SET value='3.6.7' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='11' WHERE name='ezpublish-release';
