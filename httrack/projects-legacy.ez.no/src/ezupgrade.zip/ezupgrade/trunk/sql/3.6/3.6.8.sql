UPDATE ezsite_data SET value='3.6.8' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='12' WHERE name='ezpublish-release';
