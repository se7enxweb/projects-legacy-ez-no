<?php
class sessionCleanupInfo
{
    function info()
    {
        return array(
            'Name' => "<a href='http://projects.ez.no/session_cleanup'>Session Cleanup Cronjob</a>",
            'Version' => "1.0",
            'Copyright' => "Copyright (C) 2007, <a href='http://www.all2e.com/'>all2e GmbH</a>",
            'Author' => "Markus Bader",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>