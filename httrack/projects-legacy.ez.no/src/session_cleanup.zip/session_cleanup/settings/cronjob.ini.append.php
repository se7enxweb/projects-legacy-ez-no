<?php /*

[CronjobPart-session_cleanup]
Scripts[]
Scripts[]=session_cleanup.php

[CronjobSettings]
Scripts[]=session_cleanup.php
ExtensionDirectories[]=session_cleanup

*/ ?>
