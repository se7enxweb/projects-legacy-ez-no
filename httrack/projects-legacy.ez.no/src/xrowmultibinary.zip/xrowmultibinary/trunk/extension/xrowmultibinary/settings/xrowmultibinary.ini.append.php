<?php /* #?ini charset="utf-8"?

[Settings]
Runtimes=gears,flash,silverlight,browserplus

*/ ?>
