<?php /* #?ini charset="utf-8"?

[SSLZoneSettings] 
ModuleViewAccessMode[xrowmultibinary/*]=keep

[RoleSettings]
PolicyOmitList[]=xrowmultibinary/upload
PolicyOmitList[]=xrowmultibinary/download

[SiteAccessSettings]
AnonymousAccessList[]=xrowmultibinary/upload
AnonymousAccessList[]=xrowmultibinary/download
*/ ?>
