<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE" sourcelanguage="en">
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Max number of files for the upload</source>
        <translation>Maximale Anzahl an Dateien für den Upload</translation>
    </message>
</context>
<context>
    <name>extension/xrowmultibinary</name>
    <message>
        <source>Select files</source>
        <translation>Dateien auswählen</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Dateiname</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <source>Drag file here.</source>
        <translation>Datei hierher ziehen.</translation>
    </message>
    <message>
        <source>Drag files here.</source>
        <translation>Dateien hierher ziehen.</translation>
    </message>
    <message>
        <source>A file with this name is already exists.</source>
        <translation>Eine Datei mit diesem Namen existiert bereits.</translation>
    </message>
    <message>
        <source>You are allowed to upload only one file.</source>
        <translation>Sie dürfen nur eine Datei hochladen.</translation>
    </message>
    <message>
        <source>You are allowed to upload only %s files.</source>
        <translation>Sie dürfen nur %s Dateien hochladen.</translation>
    </message>
</context>
</TS>