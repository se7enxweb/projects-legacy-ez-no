<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=xrowmultibinary
AvailableDataTypes[]=xrowmultibinary

*/ ?>
