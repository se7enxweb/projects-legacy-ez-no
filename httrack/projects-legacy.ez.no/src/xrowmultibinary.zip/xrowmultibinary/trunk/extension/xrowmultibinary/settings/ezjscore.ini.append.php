<?php /*

[ezjscServer_xrowm]
Class=xrowMultiBinaryServerFunctions
File=extension/xrowmultibinary/classes/xrowmultibinaryserverfunctions.php


*/ ?>
