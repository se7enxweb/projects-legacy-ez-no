<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=xrowmultibinary
ModuleList[]=xrowmultibinary

*/ ?>
