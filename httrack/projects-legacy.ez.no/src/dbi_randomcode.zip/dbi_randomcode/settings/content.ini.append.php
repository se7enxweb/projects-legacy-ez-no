<?php /* #?ini charset="iso-8859-1"?

[DataTypeSettings]
ExtensionDirectories[]=dbi_randomcode
AvailableDataTypes[]=randomcode

*/ ?>