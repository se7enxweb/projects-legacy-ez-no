<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=sqliimport
ModuleList[]=sqliimport

*/ ?>