<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[sqliimportnavigationpart]=Import management

[TopAdminMenu]
Tabs[]=sqliimport

[Topmenu_sqliimport]
NavigationPartIdentifier=sqliimportnavigationpart
Name=Import management
Tooltip=Manage your imports
URL[]
URL[default]=sqliimport/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=false

# Tabs policy on admin interface in 4.3
PolicyList[]=sqliimport/manageimports

*/ ?>
