<?php
class all2evcardInfo
{
    /*!
     Constructor
    */
    function info()
    {
        return array( 'Name' => "vCard management",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) 2008 <a href='http://all2e.com'>all2e GmbH</a>",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}    

?>
