<?php /* #?ini charset="iso-8859-1"?

[VcardSettings]
DefaultCharset=ISO-8859-1

[employee]
FirstName=pre_name
LastName=last_name
Salutation=salutation
Title=position
Email=e_mail
Phone=phone
Fax=fax
Street=street
ZIP=zip
City=city
HouseNumber=house_number

*/ ?>