<?php /*

[ModuleSettings]
ExtensionRepositories[]=all2evcard

*/ ?>
