<?php

[UserSettings]
ExtensionDirectory[]=spnego
SingleSignOnHandlerArray[]=SPNEGO

?>