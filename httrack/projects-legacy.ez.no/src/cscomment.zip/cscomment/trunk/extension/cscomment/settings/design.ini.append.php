<? /*
[ExtensionSettings]
DesignExtensions[]=cscomment

[JavaScriptSettings]
JavaScriptList[]=jquery.min.js
JavaScriptList[]=cscomments.js

[StylesheetSettings]
CSSFileList[]=cscomments.css

*/ ?>