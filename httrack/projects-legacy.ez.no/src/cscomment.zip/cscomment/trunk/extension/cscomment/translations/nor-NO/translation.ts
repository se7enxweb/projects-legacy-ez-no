﻿<!DOCTYPE TS><TS>
<context>
    <name>cscomment/adminlist</name>
    <message>
        <source>Message</source>
        <translation>Beskjed</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-post</translation>
    </message> 
    <message>
        <source>Review comments</source>
        <translation>Omtal kommentarer</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Kommentarer</translation>
    </message>
</context>
<context>
    <name>cscomment/addcomment</name>
    <message>
        <source>Reply</source>
        <translation>Svar</translation>
    </message> 
    <message>
        <source>Incorrect captcha code!</source>
        <translation>Ukorrekt captcha kode!</translation>
    </message> 
    <message>
        <source>Incorrect e-mail!</source>
        <translation>Ukorrekt e-mail adresse!!</translation>
    </message> 
    <message>
        <source>Please enter comment text!</source>
        <translation>Vennligst skriv din kommentar her!</translation>
    </message>
    <message>
        <source>Incorrect name!</source>
        <translation>Ukorrekt navn!</translation>
    </message> 
    <message>
        <source>Node not found!</source>
        <translation>Node er ikke funnet!</translation>
    </message>  
</context>
<context>
    <name>cscomment/addreplytocoment</name>
    <message>
        <source>Incorrect name!</source>
        <translation>Ukorrekt navn!</translation>
    </message>  
    <message>
        <source>Please enter comment text!</source>
        <translation>Vennligst skriv din kommentar her!</translation>
    </message>
    <message>
        <source>Incorrect captcha code!</source>
        <translation>Ukorrekt captcha kode!</translation>
    </message> 
    <message>
        <source>Incorrect e-mail!</source>
        <translation>Ukorrekt e-post adresse!</translation>
    </message>  
</context>
<context>
    <name>cscomment/comment_stored</name>
    <message>
        <source>Comment was stored.</source>
        <translation>Kommentaren er lagret.</translation>
    </message>    
</context>
<context>
    <name>cscomment/showform</name>
    <message>
        <source>Send</source>
        <translation>Send</translation>
    </message>
    <message>
        <source>Code</source>
        <translation>Kode</translation>
    </message>
    <message>
        <source>Enter captcha</source>
        <translation>Skriv Captcha</translation>
    </message> 
    <message>
        <source>Click if you want to regenerate</source>
        <translation>Klikk vis du vil regenerere</translation>
    </message>   
</context>
<context>
    <name>cscomment/list</name>
    <message>
        <source>Reply</source>
        <translation>Svar</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Kommentarer</translation>
    </message> 
    <message>
        <source>Write comment</source>
        <translation>Skriv Kommentar</translation>
    </message> 
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message> 
    <message>
        <source>Email</source>
        <translation>E-post</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Click if you want to regenerate</source>
        <translation>Klikk vis du vil regenerere</translation>
    </message> 
    <message>
        <source>Enter captcha</source>
        <translation>Skriv Captcha</translation>
    </message> 
    <message>
        <source>Code</source>
        <translation>Kode</translation>
    </message> 
    <message>
        <source>Code</source>
        <translation>Kode</translation>
    </message> 
    <message>
        <source>Send</source>
        <translation>Send</translation>
    </message>    
</context>
</TS>
