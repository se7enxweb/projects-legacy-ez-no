<!DOCTYPE TS><TS>
<context>
    <name>cscomment/adminlist</name>
    <message>
        <source>Message</source>
        <translation>Žinutė</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Vardas</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>El. paštas</translation>
    </message> 
    <message>
        <source>Review comments</source>
        <translation>Peržiūrėti komentarus</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Komentarai</translation>
    </message>
</context>
<context>
    <name>cscomment/addcomment</name>
    <message>
        <source>Reply</source>
        <translation>Atsakyti</translation>
    </message> 
    <message>
        <source>Incorrect captcha code!</source>
        <translation>Nekorektiškas saugos kodas!</translation>
    </message> 
    <message>
        <source>Incorrect e-mail!</source>
        <translation>Nekorektiškas el. pašto adresas!</translation>
    </message> 
    <message>
        <source>Please enter comment text!</source>
        <translation>Neįvestas komentaro tekstas!</translation>
    </message>
    <message>
        <source>Incorrect name!</source>
        <translation>Nekorektiškas vardas!</translation>
    </message> 
    <message>
        <source>Node not found!</source>
        <translation>Mazgas nerastas!</translation>
    </message>  
</context>
<context>
    <name>cscomment/addreplytocoment</name>
    <message>
        <source>Incorrect name!</source>
        <translation>Nekorektiškas vardas!</translation>
    </message>  
    <message>
        <source>Please enter comment text!</source>
        <translation>Neįvestas komentaro tekstas!</translation>
    </message>
    <message>
        <source>Incorrect captcha code!</source>
        <translation>Nekorektiškas saugos kodas!</translation>
    </message> 
    <message>
        <source>Incorrect e-mail!</source>
        <translation>Nekorektiškas el. pašto adresas!</translation>
    </message>  
</context>
<context>
    <name>cscomment/comment_stored</name>
    <message>
        <source>Comment was stored.</source>
        <translation>Komentaras buvo išsaugotas.</translation>
    </message>    
</context>
<context>
    <name>cscomment/showform</name>
    <message>
        <source>Send</source>
        <translation>Siųsti</translation>
    </message>
    <message>
        <source>Code</source>
        <translation>Kodas</translation>
    </message>
    <message>
        <source>Enter captcha</source>
        <translation>Įveskite kodą į langelį apačioje</translation>
    </message> 
    <message>
        <source>Click if you want to regenerate</source>
        <translation>Paspausk norėdamas pergeneruoti</translation>
    </message>   
</context>
<context>
    <name>cscomment/list</name>
    <message>
        <source>Reply</source>
        <translation>Atsakyti</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Komentarai</translation>
    </message> 
    <message>
        <source>Write comment</source>
        <translation>Rašyti komentarą</translation>
    </message> 
    <message>
        <source>Name</source>
        <translation>Vardas</translation>
    </message> 
    <message>
        <source>Email</source>
        <translation>El. paštas</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentaras</translation>
    </message>
    <message>
        <source>Click if you want to regenerate</source>
        <translation>Paspausk norėdamas pergeneruoti</translation>
    </message> 
    <message>
        <source>Enter captcha</source>
        <translation>Įveskite kodą į langelį apačioje</translation>
    </message> 
    <message>
        <source>Code</source>
        <translation>Kodas</translation>
    </message> 
    <message>
        <source>Code</source>
        <translation>Kodas</translation>
    </message> 
    <message>
        <source>Send</source>
        <translation>Siųsti</translation>
    </message>    
</context>
</TS>
