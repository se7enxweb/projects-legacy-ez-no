<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=cscomment

[RegionalSettings]
TranslationExtensions[]=cscomment



*/ ?>