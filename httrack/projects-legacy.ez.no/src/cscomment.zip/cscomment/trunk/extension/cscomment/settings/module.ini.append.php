<?php /*

[ModuleSettings]
ExtensionRepositories[]=cscomment
ModuleList[]=comment

*/ ?>