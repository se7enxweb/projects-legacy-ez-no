<?php /* #?ini charset="iso-8859-1"?

[TemplateSettings]
ExtensionAutoloadPath[]=bpce_backupbdd

[RegionalSettings]
TranslationExtensions[]=bpce_backupbdd

*/
?>