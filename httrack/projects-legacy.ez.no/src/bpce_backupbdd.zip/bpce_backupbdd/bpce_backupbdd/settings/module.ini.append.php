<?php /*

[ModuleSettings]
ExtensionRepositories[]=bpce_backupbdd

ModuleList[]=backupbdd

*/ ?>