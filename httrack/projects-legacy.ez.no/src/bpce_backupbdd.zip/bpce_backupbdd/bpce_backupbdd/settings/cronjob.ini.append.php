<?php /*

[CronjobSettings]
ScriptDirectories[]=extension/bpce_backupbdd/cronjobs

[CronjobPart-backup_bdd]
Scripts[]=backup_bdd.php

*/
?>