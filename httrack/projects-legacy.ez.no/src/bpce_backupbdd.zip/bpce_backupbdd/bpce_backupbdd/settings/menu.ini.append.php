<?php /*

[NavigationPart]
Part[ezbackupbddpart]=backupbdd

[TopAdminMenu]
Tabs[]=backupbdd

[Topmenu_backupbdd]
NavigationPartIdentifier=ezbackupbddpart
Name=backupbdd 
URL[]
URL[default]=backupbdd/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>