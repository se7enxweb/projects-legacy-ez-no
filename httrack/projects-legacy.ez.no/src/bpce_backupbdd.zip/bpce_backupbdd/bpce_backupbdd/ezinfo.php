<?php

class bpce_backupbddInfo
{
    static function info()
    {
        return array( 'Name' => "bpce_backupbdd",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) 1999-2009 Alexandre SEBBANE",
                      'License' => "GNU General Public License v2.0"
                      );
    }
}
?>
