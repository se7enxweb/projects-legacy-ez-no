<?php /* #?ini charset="utf-8"?

[eZiCalCalendar]
ExtensionName=ezical
ClassName=eZiCalExtendedFilter
MethodName=createSqlParts
FileName=classes/ezicalextendedfilter.php


*/ ?>