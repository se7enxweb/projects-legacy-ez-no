<?php
//
// Created on: <01-Sep-2008 19:00:00 bf>
//
// SOFTWARE NAME: eZiCal
// SOFTWARE RELEASE: 0.1
// BUILD VERSION:
// COPYRIGHT NOTICE: Copyright (c) 2008 Guillaume Kulakowski and contributors
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//

$eZiCal = eZiCal::instance();
$nodeID = $eZiCal->getNodeID();
$cacheTime = intval( $eZiCal->eZiCalSettings['CacheTime'] );
//$cacheTime = 0;


if ( $cacheTime <= 0 )
{
    $iCalContent = $eZiCal->saveICS( $nodeID );
}
else
{
    $config = eZINI::instance('site.ini');
    $cacheDir = eZSys::cacheDirectory();
    $currentSiteAccessName = $GLOBALS['eZCurrentAccess']['name'];
    $cacheFilePath = $cacheDir . '/ezical/' . md5( $currentSiteAccessName . $nodeID ) . '.ics';

    // If cache directory does not exist, create it. Get permissions settings from site.ini
    if ( !is_dir( $cacheDir.'/ezical' ) )
    {
        $mode = $config->variable( 'FileSettings', 'TemporaryPermissions' );
        if ( !is_dir( $cacheDir ) )
        {
            mkdir( $cacheDir );
            chmod( $cacheDir, octdec( $mode ) );
        }
        mkdir( $cacheDir.'/ezical' );
        chmod( $cacheDir.'/ezical', octdec( $mode ) );
    }

    // VS-DBFILE
    require_once( 'kernel/classes/ezclusterfilehandler.php' );
    $cacheFile = eZClusterFileHandler::instance( $cacheFilePath );

    if ( !$cacheFile->exists() or ( time() - $cacheFile->mtime() > $cacheTime ) )
    {
        // Get current charset
        //include_once( 'lib/ezi18n/classes/eztextcodec.php' );
        $charset = eZTextCodec::internalCharset();
        $iCalContent = $eZiCal->saveICS( $nodeID );
        $cacheFile->storeContents( $iCalContent, 'icscache', 'ics' );
    }
    else
    {
        $iCalContent = $cacheFile->fetchContents();
    }
}


// Set header settings
//header( 'Content-Type: text/calendar; charset=' . $httpCharset );
header( 'Content-Type: text/plain; charset=' . $httpCharset );
header( 'Content-Length: '.strlen($iCalContent) );
header( 'X-Powered-By: eZ Publish and eZiCal' );

while ( @ob_end_clean() );

echo $iCalContent;

eZExecution::cleanExit();

?>