<?php
//
// Definition of eZiCalExtendedFilter class
//
// Created on: <13-sept-2008 12:14:34 bf>
//
// SOFTWARE NAME: eZiCal
// SOFTWARE RELEASE: 1.0
// BUILD VERSION:
// COPYRIGHT NOTICE: Copyright (c) 2008 Guillaume Kulakowski and contributors
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//


/*! \file eZiCalExtendedFilter.php
*/

/*!
  \class eZiCalExtendedFilter eZiCalExtendedFilter.php
  \brief
*/
class eZiCalExtendedFilter
{

    function CreateSqlParts( $params )
    {
        $result = array( 'tables' => '', 'joins'  => '', 'columns' => '' );

        /* Paramètres */
        if ( !isset($params['from_time']) || !isset($params['to_time']) )
        {
            return $result;
        }
        $fromTime = $params['from_time'];
        $toTime = $params['to_time'];


        $db = eZDB::instance();
        $eZiCal = eZiCal::instance();


        /* Attribut */
        $attributeBeginDate = $eZiCal->eventClass['EventClassID'].'/'.$eZiCal->eventClass['Dictionary']['DTSTART'];
        $attributeEndDate = $eZiCal->eventClass['EventClassID'].'/'.$eZiCal->eventClass['Dictionary']['DTEND'];
        $attributeFrequency = $eZiCal->eventClass['EventClassID'].'/'.$eZiCal->eventClass['Dictionary']['Frequency'];
        $attributeFrequencyEnd = $eZiCal->eventClass['EventClassID'].'/'.$eZiCal->eventClass['Dictionary']['FrequencyEnd'];

        $attributeBeginDateID = eZContentObjectTreeNode::classAttributeIDByIdentifier($attributeBeginDate);
        $attributeEndDateID = eZContentObjectTreeNode::classAttributeIDByIdentifier($attributeEndDate);
        $attributeFrequencyID = eZContentObjectTreeNode::classAttributeIDByIdentifier($attributeFrequency);
        $attributeFrequencyEndID = eZContentObjectTreeNode::classAttributeIDByIdentifier($attributeFrequencyEnd);


        /* Requêtes SQL */
        $arrayJoins = array();
        $arrayTables = array();
        $arrayCondition = array();
        $arrayTables[] = "ezcontentobject_attribute from_time";
        $arrayJoins[] = "( from_time.contentobject_id = ezcontentobject.id
                           AND from_time.contentclassattribute_id = $attributeBeginDateID
                           AND from_time.version = ezcontentobject_name.content_version )";
        $arrayTables[] = "ezcontentobject_attribute to_time";
        $arrayJoins[] = "( to_time.contentobject_id = ezcontentobject.id
                           AND to_time.contentclassattribute_id = $attributeEndDateID
                           AND to_time.version = ezcontentobject_name.content_version )";

        $arrayCondition[] = "( from_time.sort_key_int BETWEEN $fromTime AND $toTime
                               OR to_time.sort_key_int BETWEEN $fromTime AND $toTime )";

        if ( strtolower($attributeFrequency) != 'disabled' )
        {
            $arrayTables[] = "ezcontentobject_attribute frequency";
            $arrayJoins[] = "( frequency.contentobject_id = ezcontentobject.id
                               AND frequency.contentclassattribute_id = $attributeFrequencyID
                               AND frequency.version = ezcontentobject_name.content_version )";
            $arrayTables[] = "ezcontentobject_attribute freq_end";
            $arrayJoins[] = "( frequency.contentobject_id = ezcontentobject.id
                               AND freq_end.contentclassattribute_id = $attributeFrequencyEndID
                               AND freq_end.version = ezcontentobject_name.content_version )";

            $arrayCondition[] = "( frequency.sort_key_string != " . eZiCal::FREQUENCY_NONE_ID ."
                                   AND freq_end.sort_key_int BETWEEN $fromTime AND $toTime )";
            $arrayCondition[] = "( frequency.sort_key_string != " . eZiCal::FREQUENCY_NONE_ID ."
                                   AND ( freq_end.sort_key_int = 0 ) )";
        }

        $result['tables'] = ", " . implode( ', ', $arrayTables );
        $result['joins'] = implode( ' AND ', $arrayJoins ) . " AND (" . implode( ' OR ', $arrayCondition ) . ") AND ";;

        return $result;
    }
}

?>