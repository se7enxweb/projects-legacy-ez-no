<?php
//
// Definition of eZiCalExportObject class
//
// Created on: <01-Sep-2008 19:00:00 bf>
//
// SOFTWARE NAME: eZiCal
// SOFTWARE RELEASE: 0.1
// BUILD VERSION:
// COPYRIGHT NOTICE: Copyright (c) 2008 Guillaume Kulakowski and contributors
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//


/*! \file ezicalexportobject.php
*/

/*!
  \class eZiCalContentObject ezicalexportobject.php.php
  \brief Permet de définir un ezicalcontentobject de façon générale

\verbatim
La classe eZiCalContentObject n'est pas faite pour être instanciée directement.
Il faut passer par des objects tels que eZiCalContentObjectEvent.
La gestion des VTODO et VALERT est tout à fait possible à intégrer.
\endverbatim
 */
class eZiCalExportObject
{
    /*  Constantes propres à la version du format iCal */
    const ICALVERSION = '2.0';

    /* En relation avec l'objet eZ */
    protected $node;
    protected $dataMap;
    protected $tZone;



    /*!
     Constructeur de la classe. Va construire l'objet eZiCalContentObject
     à partir d'un eZContentObjectTreeNode

     \param $node eZContentObjectTreeNode
     */
    protected function __construct( $node )
    {
        $this->node = $node;
        $this->dataMap = $node->attribute( 'data_map' );
        $this->tZone = 0.0;
    }



    /*!
     Méthode __toString() pour gérer l'affichage d'un eZiCalContentObject

     \return string
     */
    protected function __toString()
    {
        return 'BEGIN:' . eZiCalContentObject::OBJECTNAME . "\n" .
        'END:' . eZiCalContentObject::OBJECTNAME . "\n";
    }



    /*!
     Récupération du PROID
 	 \return string
     */
    public static function PROID()
    {
        return "-//eZ Publish " . eZPublishSDK::VERSION_MAJOR . "//NONSGML eZiCal v" . eZiCal::VERSION . "//EN";
    }



    /*!
     Permet de déterminer la date iCal (DTSTART|DTEND)

     \param $type string (DTSTART|DTEND)
     \return string Date au format iCal
     */
    protected function getDate( $type )
    {
        $eZiCal = eZiCal::instance();

        $dateAttribute = $eZiCal->eventClass['Dictionary'][$type];
        $timeAttribute = $eZiCal->eventClass['Dictionary'][$type.'_Time'];
        $timestamp = $this->dataMap[$dateAttribute]->content()->attribute( 'timestamp' );
        $dateDataType = $this->dataMap[$dateAttribute]->DataTypeString;

        /*
         On gère le cas où la date est gérée par un ezdatetime
         mais aussi le cas où elle est gérée par un ezdate et un eztime
         */
        if ( strtolower($timeAttribute) == 'disabled' || $dateDataType == 'ezdatetime'  )
        {
            $icalDate = self::timestamp2ical( $timestamp, $this->tZone );
        }
        else
        {
            $time = $this->dataMap[$timeAttribute]->content()->attribute( 'time_of_day' );
            $timestamp = $timestamp + $time;
            $icalDate = eZiCal::timestamp2ical( $timestamp, $this->tZone );
        }

        if ( $this->isFullDay )
        {
            /* On coupe la fin de la chaine */
            $icalDate = substr( $icalDate, 0, -7 );
        }

        return $icalDate;
    }



    /*!
     Permet de déterminer si l'objet est sur un jour complet

     \return boolean
     */
    protected function getIsFullDay()
    {
        $eZiCal = eZiCal::instance();
        $attribute = $eZiCal->eventClass['Dictionary']['FullDay'];

        if ( strtolower($attribute) == 'disabled' )
        {
            return false;
        }

        return $this->dataMap[$attribute]->content();
    }



    /*!
     Nom de l'objet

     \return String
     */
    protected function getSummary()
    {
        return self::iCalText( $this->node->Name );
    }



    /*!
     Lieu de l'objet

     \return string
     */
    protected function getLocation()
    {
        $eZiCal = eZiCal::instance();
        $attribute = $eZiCal->eventClass['Dictionary']['LOCATION'];

        if ( strtolower($attribute) == 'disabled' )
        {
            return "";
        }

        return eZiCal::iCalText( $this->dataMap[$attribute]->content() );
    }



    /*!
     Catégories de l'objet

     \return array
     */
    protected function getCategories()
    {
        $eZiCal = eZiCal::instance();
        $attribute = $eZiCal->eventClass['Dictionary']['CATEGORIES'];

        if ( strtolower($attribute) == 'disabled' )
        {
            return array();
        }

        if ( $this->dataMap[$attribute]->DataTypeString == 'ezstring' )
        {
            print_r($this->dataMap[$attribute]->content());
            return explode( ',', trim($this->dataMap[$attribute]->content()) );
        }
        elseif( $this->dataMap[$attribute]->DataTypeString == 'ezkeyword' )
        {
           return $this->dataMap[$attribute]->content()->KeywordArray;
        }
    }



    /*!
     Description de l'objet

     \return string
     */
    protected function getDescription()
    {
        $eZiCal = eZiCal::instance();
        $attribute = $eZiCal->eventClass['Dictionary']['DESCRIPTION'];

        if ( strtolower($attribute) == 'disabled' )
        {
            return "";
        }

        return self::iCalText( $this->dataMap[$attribute]->content()->attribute('output')->outputText() );
    }



    /*!
     Status de l'objet (TENTATIVE | CONFIRMED | CANCELLED)

     \return string
     */
    protected function getStatus()
    {
        $eZiCal = eZiCal::instance();
        $attribute = $eZiCal->eventClass['Dictionary']['STATUS'];

        if ( strtolower($attribute) == 'disabled' )
        {
            /*
             \TODO Réfléchir à le renvoyer vide ou "CONFIRMED" par défaut
             */
            return "";
        }

        $statusID = 'STATUSID_' . $this->dataMap[$attribute]->content();
        return self::$statusID;
    }



    /*!
     Class de l'objet (PUBLIC | PRIVATE | CONFIDENTIAL)

     \return string
     */
    protected function getClass()
    {
        $eZiCal = eZiCal::instance();
        $attribute = $eZiCal->eventClass['Dictionary']['CLASS'];

        if ( strtolower($attribute) == 'disabled' )
        {
            /*
             \TODO Réfléchir à le renvoyer vide ou "PUBLIC" par défaut
             */
            return "";
        }

        $classID = 'CLASSID_' . $this->dataMap[$attribute]->content();
        return self::$classID;
    }



    /*!
     Détermination de la fréquence
     \return boolean
     */
    protected function getFrequency()
    {
        $eZiCal = eZiCal::instance();
        $attributeFrequency = $eZiCal->eventClass['Dictionary']['Frequency'];
        $frequency = $this->dataMap[$attributeFrequency]->content();

        if ( strtolower($attributeFrequency) == 'disabled' || $frequency[0] == eZiCal::FREQUENCY_NONE_ID )
        {
            $this->frequency = false;
            return false;
        }
        else
        {
            $this->frequency = true;
            $this->RRULE = "";

            $frequencyEnd = $this->dataMap[$eZiCal->eventClass['Dictionary']['FrequencyEnd']]->content()->attribute('timestamp');

            $FREQ = "";
            $BYDAY = "";
            $UNTIL = "";     // Date de fin
            $COUNT = "";     // Nb d'occurence

            switch ( $frequency[0] )
            {
                /* Jours ouvrés */
                case eZiCal::FREQUENCY_DAILY_OPEN_ID:
                    $FREQ = "WEEKLY";
                    $BYDAY = "MO,TU,WE,TH,FR";
                    break;

                /* Quotidien */
                case eZiCal::FREQUENCY_DAILY_ID:
                    $FREQ = "DAILY";
                    break;

                /* Hebdomadaire */
                case eZiCal::FREQUENCY_WEEKLY_ID:
                    $FREQ = "WEEKLY";
                    break;

                /* Bi-mensuel */
                case eZiCal::FREQUENCY_BIMONTHLY_ID:
                    $FREQ = "WEEKLY";
                    $INTERVAL = "2";
                    break;

                /* Mensuel */
                case eZiCal::FREQUENCY_MONTHLY_ID:
                    $FREQ = "MONTHLY";
                    break;

                /* Annuel */
                case eZiCal::FREQUENCY_ANNUAL_ID:
                    $FREQ = "ANNUAL";
                    break;
            }

            if ( $frequencyEnd > 0 )
            {
                $UNTIL = self::timestamp2ical( $frequencyEnd, $this->tZone );
            }


            /* Création */
            if ( !empty( $FREQ ) )
            {
                $this->RRULE .= "FREQ=$FREQ;";
            }
            if ( !empty( $BYDAY ) )
            {
                $this->RRULE .= "BYDAY=$BYDAY;";
            }
            if ( !empty( $UNTIL ) )
            {
                $this->RRULE .= "UNTIL=$UNTIL;";
            }

            return true;
        }
    }



	/*!
     Converti une date UNIX (timestamp) en date valide iCal

     \param $timestamp integer
     \param $tZone float
     \return Date au format iCal

     \TODO passage à eZDate ?
     */
    public static function timestamp2ical ( $timestamp=0, $tZone=0.0 )
    {
        $timestamp = $timestamp + ($tZone*3600);
        return date("Ymd\THis\Z", $timestamp);
    }



    /*!
     Opération sur les strings pour les rendre valides iCal

     \param string $str
     \TODO contrôler la longueur des lignes
     */
    public static function iCalText ( $str )
    {
        return trim( strip_tags( $str ) );
    }


}    // EOC

?>