 <?php
//
// Definition of eZiCalExportObjectVevent class
//
// Created on: <01-Sep-2008 19:00:00 bf>
//
// SOFTWARE NAME: eZiCal
// SOFTWARE RELEASE: 0.1
// BUILD VERSION:
// COPYRIGHT NOTICE: Copyright (c) 2008 Guillaume Kulakowski and contributors
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//


/*! \file ezicalexportobjectvevent.php
*/

/*!
  \class eZiCalExportObjectVevent ezicalcontentobjectevent.php
  \brief Permet de définir un eZiCalExportObject de type VEVENT.
*/
class eZiCalExportObjectVevent extends eZiCalExportObject
{
    const OBJECTNAME = 'VEVENT';

    /* Eléments de l'objets iCal */
    public $DTSTART = 0000000000;         // Timestamp
    public $DTEND = 0000000000;           // Timestamp
    public $SUMMARY = "";                 // String
    public $LOCATION = "";                // String
    public $CATEGORIES = array();         // Array
    public $STATUS = "";                  // String (TENTATIVE | CONFIRMED | CANCELLED)
    public $DESCRIPTION = "";             // String
    public $RRULE = "";                   // String
    public $CLASS = 0;                    // Integer

    /* Décrivent l'évènement mais ne font pas partie du format iCal */
    public $isFullDay = false;
    public $frequency = false;



    /*!
     Constructeur de la classe. Va construire l'objet eZiCalContentObjectEvent
     à partir d'un eZContentObjectTreeNode

     \param $node eZContentObjectTreeNode
     */
    public function __construct( $node )
    {
        parent::__construct( $node );

        /* gestion des dates */
        $this->isFullDay = $this->getIsFullDay();
        $this->DTSTART = $this->getDate( 'DTSTART' );
        $this->DTEND = $this->getDate( 'DTEND' );

        /* Gestion de la fréquence */
        $this->frequency = $this->getFrequency();

        /* Gestion des strings */
        $this->SUMMARY = $this->getSummary();
        $this->LOCATION = $this->getLocation();
        $this->DESCRIPTION = $this->getDescription();
        $this->STATUS = $this->getStatus();

        /* Gestion des tableaux */
        $this->CATEGORIES = $this->getCategories();
    }



    /*!
     Méthode __toString() pour gérer l'affichage d'un eZiCalContentObjectEvent

     \return string
     */
    public function __toString()
    {
        $lastModified = self::timestamp2ical( $this->node->contentObjectVersionObject()->attribute('modified'), $this->tZone );

        $toString = 'BEGIN:' . self::OBJECTNAME . "\n" .
        'CREATED:' . self::timestamp2ical( $this->node->contentObjectVersionObject()->attribute('created'), $this->tZone ) . "\n" .
        'LAST-MODIFIED:' . $lastModified . "\n" .
        'DTSTAMP:' . $lastModified . "\n" .
        'UID:' . $this->node->remoteID() . "\n" .
        'CLASS:' . $this->CLASS . "\n" .

        'SUMMARY:' . $this->SUMMARY . "\n" .
        'DTSTART:' . $this->DTSTART . "\n" .
        'DTEND:' . $this->DTEND . "\n";

        if ( $this->frequency )
        {
            $toString .= 'RRULE:' . $this->RRULE . "\n";
        }
        if ( !empty($this->LOCATION) )
        {
            $toString .= 'LOCATION:' . $this->LOCATION . "\n";
        }
        if ( is_array($this->CATEGORIES) && !empty($this->CATEGORIES) )
        {
            $toString .= 'CATEGORIES:' . implode( ',', $this->CATEGORIES ) . "\n";
        }
        if ( !empty($this->DESCRIPTION) )
        {
            $toString .= 'DESCRIPTION:' . $this->DESCRIPTION . "\n";
        }
        if ( !empty($this->STATUS) )
        {
            $toString .= 'STATUS:' . $this->STATUS . "\n";
        }

        $toString .= 'END:' . self::OBJECTNAME . "\n";

        return $toString;
    }

}   // EOC

?>