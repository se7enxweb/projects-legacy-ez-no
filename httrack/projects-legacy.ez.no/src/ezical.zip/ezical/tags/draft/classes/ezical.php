<?php
//
// Definition of eZiCal class
//
// Created on: <01-Sep-2008 19:00:00 bf>
//
// SOFTWARE NAME: eZiCal
// SOFTWARE RELEASE: 0.1
// BUILD VERSION:
// COPYRIGHT NOTICE: Copyright (c) 2008 Guillaume Kulakowski and contributors
// SOFTWARE LICENSE: GNU General Public License v2.0
// NOTICE: >
//   This program is free software; you can redistribute it and/or
//   modify it under the terms of version 2.0  of the GNU General
//   Public License as published by the Free Software Foundation.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of version 2.0 of the GNU General
//   Public License along with this program; if not, write to the Free
//   Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//   MA 02110-1301, USA.
//
//


/*! \file ezical.php
*/

/*!
  \class eZiCal ezical.php
  \brief Permet de formaliser le modèle iCal pour eZ.
 */
class eZiCal
{
    /* Version d'eZiCal */
    const VERSION = '0.1';

    /* Gestion du status */
    const STATUSID_0 = 'TENTATIVE';
    const STATUSID_1 = 'CONFIRMED';
    const STATUSID_3 = 'CANCELLED';

    /* Gestion des class*/
    const CLASSID_0 = 'PUBLIC';
    const CLASSID_1 = 'PRIVATE';
    const CLASSID_2 = 'CONFIDENTIAL';

    /* Constante de périodicité */
    const FREQUENCY_NONE_ID = 0;
    const FREQUENCY_DAILY_OPEN_ID = 1;
    const FREQUENCY_DAILY_ID = 2;
    const FREQUENCY_WEEKLY_ID = 3;
    const FREQUENCY_BIMONTHLY_ID = 4;
    const FREQUENCY_MONTHLY_ID = 5;
    const FREQUENCY_ANNUAL_ID = 6;


    public $eventClass = array();
    public $eZiCalSettings = array();



    /*!
     Constructeur d'eZiCal
     */
    private function __construct()
    {
        /* Récupération des paramètres */
        $ini = eZINI::instance('ezical.ini');
        $this->eventClass = $ini->variableMulti('EventClass', array(
                                                    'EventClassID'   => 'EventClassID',
                                                    'Dictionary'     => 'Dictionary',
                                                ) );
        $this->eZiCalSettings = $ini->variableMulti('ICalSettings', array(
                                                        'CacheTime'     => 'CacheTime',
                                                        'PathPrefix'     => 'PathPrefix',
                                                ) );
    }



    /*!
     Récupérer l'instance d'eZiCal

     \return
     */
    static function instance()
    {
        $impl = &$GLOBALS["eZiCalGlobalInstance"];
        $class = get_class( $impl );

        if ( $class != 'eZiCal')
        {
            $impl = new eZiCal();
        }
        return $impl;
    }



    /*!
     Fonction retournant le contenu du fichier ICS

     \return string
     \TODO Utiliser les paramètres limit/offset
     */
    public function saveICS( $nodeID )
    {
        /* On récupère les évènements */
        $attributeBeginDate = $this->eventClass['EventClassID'].'/'.$this->eventClass['Dictionary']['DTSTART'];
        $attributeEndDate = $this->eventClass['EventClassID'].'/'.$this->eventClass['Dictionary']['DTEND'];

        $events = eZFunctionHandler::execute('content','tree', array(
			'parent_node_id'        => $nodeID,
            'class_filter_type'     => 'include',
            'class_filter_array'    => array( $this->eventClass['EventClassID'] ),
            //'offset'                => 0,
            //'limit'                => 1000,
            /*'attribute_filter'  => array(
                'and',
                array( $attributeBeginDate, '>=', 0 ),
                array( $attributeEndDate, '<=', 9999999999 )
            ),*/
             'sort_by',                array( 'attribute', false, $attributeBeginDate )
        ) );

        /* Affichage */
        $ics = 'BEGIN:VCALENDAR' . "\n" .
        'VERSION:' . eZiCalExportObject::ICALVERSION . "\n" .
        'PRODID:' . eZiCalExportObject::PROID() . "\n";

        foreach ( $events as $e )
        {
            $eZiCalExportObjectVevent = new eZiCalExportObjectVevent( $e );
            $ics .= $eZiCalExportObjectVevent;
        }

        $ics .= 'END:VCALENDAR';

        return $ics;
    }



    /*!
     Fonction retournant le noeud courant pour l'exportation ICS

     \return integer
     */
    public function getNodeID()
    {
        $Module = &$GLOBALS['eZRequestedModule'];

        if ( array_key_exists(0, $Module->OriginalParameters) && is_int($Module->OriginalParameters[0]) )
        {
            $nodeID = $Module->OriginalParameters[0];
        }
        else
        {
            $uriString = '';

            if ( array_key_exists(0, $Module->OriginalParameters) )
            {
                $uriString = $Module->OriginalParameters[0];
            }

        	/* Prefixe */
            if ( $this->eZiCalSettings['PathPrefix'] != ''  )
            {
                $uriString = eZURLAliasML::cleanURL( $this->eZiCalSettings['PathPrefix'] ) . $uriString;
            }

            eZURLAliasML::cleanURL($uriString);

            if ( empty( $uriString ) )
            {
                $ini = eZINI::instance('site.ini');
                $uri = eZURI::instance( $ini->variable( 'SiteSettings', 'IndexPage') );
                $url = $uri->elements();
                $url = eZURLAliasML::urlToAction( $url );
                $nodeID = eZURLAliasML::nodeIDFromAction( $url );
            }
            else
            {
               $uri = eZURI::instance($uriString);
               eZURLAliasML::translate($uri);
               $url = $uri->elements();
               $url = eZURLAliasML::urlToAction( $url );
               $nodeID = eZURLAliasML::nodeIDFromAction( $url );
            }
        }

        return $nodeID;
    }

}    //EOC

?>