<?php
class all2e1pixeloutmp3flashplayerInfo
{
    /*!
     Constructor
    */
	function info()
    {
        return array( 'Name' => "1Pixelout MP3 Flash Player",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) 2008 <a href='http://all2e.com'>all2e GmbH</a>",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}    

?>
