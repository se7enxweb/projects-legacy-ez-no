<?php /*

[ExtensionSettings]
DesignExtensions[]=all2e1pixeloutmp3flashplayer

[JavaScriptSettings]
JavaScriptList[]=audio-player.js

*/ ?>
