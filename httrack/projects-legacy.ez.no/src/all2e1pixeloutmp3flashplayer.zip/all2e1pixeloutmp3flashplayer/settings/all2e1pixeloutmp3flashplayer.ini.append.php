<?php /*

[FunctionalOptions]
height=24
width=290

# The player will automatically open and start to play the track
autostart=no

# The track will be looped indefinitely
loop=no

[DesignSettings]
# colour options
# Please just use hexadecimal values
bg=ffffff
leftbg=333333
rightbg=333333
rightbghover=666666
lefticon=aaaaaa
righticon=aaaaaa
righticonhover=333333
text=000000
slider=555555
loader=555555
track=000000
border=ffffff

*/ ?>