<?php /* #?ini charset="utf-8"?

[RegionalSettings]
Locale=fre-FR
ContentObjectLocale=fre-FR
TextTranslation=enabled
TranslationCache=enabled
TranslationExtensions[]=novennotification

[ContentSettings]
TranslationList=fre-FR

*/ ?>
