<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[novennotificationnavigationpart]=Noven: users notification settings

[TopAdminMenu]
Tabs[]=novennotification

[Topmenu_novennotification]
NavigationPartIdentifier=novennotificationnavigationpart
Name=Users notification settings
Tooltip=Cette extension affiche les paramètres de notification des utilisateurs
URL[]
URL[default]=novennotification/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=false

*/ ?>
