<!DOCTYPE TS><TS>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Noven: users notification settings</source>
        <translation>Paramètres de notification des utilisateurs</translation>
    </message>
</context>
<context>
    <name>extension/novennotification</name>
    <message>
        <source>Users notification settings</source>
        <translation>Paramètres de notification des utilisateurs</translation>
    </message>
</context>
<context>
    <name>extension/novennotification/list</name>
    <message>
        <source>Select the user group</source>
        <translation>Sélectionnez le groupe d'utilisateurs</translation>
    </message>
    <message>
        <source>Please select the group to display</source>
        <translation>Veuillez sélectionner le groupe à afficher</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Sélectionner</translation>
    </message>
    <message>
        <source>Users for group %group</source>
        <translation>Utilisateurs du groupe %group</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Identifiant</translation>
    </message>
    <message>
        <source>Email address</source>
        <translation>Adresse email</translation>
    </message>
    <message>
        <source>View notification user</source>
        <translation>Afficher les notifications de l'utilisateur</translation>
    </message>
</context>
<context>
    <name>extension/novennotification/view</name>
    <message>
        <source>User notification</source>
        <translation>Notifications de l'utilisateur</translation>
    </message>
    <message>
        <source>No notification for this user</source>
        <translation>Aucune notification pour cet utilisateur</translation>
    </message>
</context>
</TS>
