<?php /*

[ExtensionSettings]
DesignExtensions[]=dbi_bliptv

*/ ?>

