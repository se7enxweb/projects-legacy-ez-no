<?php /*

[CustomTagSettings]
AvailableCustomTags[]=bliptv
IsInline[bliptv]=true

[bliptv]
CustomAttributes[]=movie_id
CustomAttributes[]=width
CustomAttributes[]=height
CustomAttributes[]=allowscriptaccess
CustomAttributes[]=allowfullscreen
CustomAttributesDefaults[movie_id]=http://blip.tv/play/(Movie_ID)
CustomAttributesDefaults[width]=480
CustomAttributesDefaults[height]=352
CustomAttributesDefaults[allowscriptaccess]=always
CustomAttributesDefaults[allowfullscreen]=true

*/ ?>
