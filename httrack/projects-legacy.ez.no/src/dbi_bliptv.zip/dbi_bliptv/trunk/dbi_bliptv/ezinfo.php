<?php

class dbi_bliptvInfo
{
    static function info()
    {
        return array( 'Name' => "DBI Blip.tv custom tag video extension",
                      'Version' => "1.0.0",
                      'Copyright' => "DB Informatics",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>
