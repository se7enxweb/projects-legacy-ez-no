<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=facebook_connect

*/ ?>