<?php /* #?ini charset="utf-8"?

[RoleSettings]
#PolicyOmitList[]=facebook/login
#PolicyOmitList[]=facebook/connect

# Copy to siteaccess site.ini.append.php and uncomment to activate
#[UserSettings]
#SingleSignOnHandlerArray[]=Facebook
#ExtensionDirectory[]=facebook_connect

*/ ?>