<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array(
    'script' => 'extension/sortobjectsoperators/autoloads/sortobjectstemplateoperators.php',
    'class' => 'SortObjectsTemplateOperators',
    'operator_names' => array(
        'get_objects_from_nodes',
        'get_sorted_objects',
        'get_unique_sorted_objects',
    )
);

?>