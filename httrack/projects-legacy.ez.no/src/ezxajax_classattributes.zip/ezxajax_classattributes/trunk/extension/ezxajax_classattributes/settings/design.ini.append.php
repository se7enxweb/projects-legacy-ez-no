<?php /*

[ExtensionSettings]
DesignExtensions[]=ezxajax_classattributes

[JavaScriptSettings]
JavaScriptList[]=ezxajax_classattributes.js

*/ ?>