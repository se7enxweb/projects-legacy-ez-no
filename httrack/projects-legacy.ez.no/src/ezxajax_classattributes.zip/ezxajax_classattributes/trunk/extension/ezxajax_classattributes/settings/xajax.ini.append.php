<?php /*

[ExtensionSettings]
ExtensionDirectories[]=ezxajax_classattributes

AvailableFunctions[addClassAttribute]=classattributes
AvailableFunctions[moveClassAttribute]=classattributes

*/ ?>