<?php /*

[ExtensionSettings]
DesignExtensions[]=xajax_classattributes

[JavaScriptSettings]
JavaScriptList[]=xajax_classattributes.js

*/ ?>