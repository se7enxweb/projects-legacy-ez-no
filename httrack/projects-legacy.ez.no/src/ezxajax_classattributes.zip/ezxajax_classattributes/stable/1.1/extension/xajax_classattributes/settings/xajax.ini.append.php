<?php /*

[ExtensionSettings]
ExtensionDirectories[]=xajax_classattributes

AvailableFunctions[addClassAttribute]=classattributes
AvailableFunctions[moveClassAttribute]=classattributes

*/ ?>