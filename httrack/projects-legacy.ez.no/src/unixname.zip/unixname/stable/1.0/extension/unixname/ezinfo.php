<?php
class unixnameInfo
{
    function info()
    {
        return array(
            'Name' => "UNIX name",
            'Version' => "0.1",
            'Copyright' => "Copyright (C) 2006-2007 SCK-CEN, Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>