<?php
class unixnameInfo
{
    static function info()
    {
        return array(
            'Name' => '<a href="http://projects.ez.no/unixname">UNIX name</a>',
            'Version' => "2.x",
            'Copyright' => "Copyright (C) 2006-2007 SCK-CEN, 2008 Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>