<?php
class ezapacheauthInfo
{
    static function info()
    {
        return array( 'Name' => "<a href=\"http://projects.ez.no/ezapacheauth\">ezapacheauth</a>",
                      'Version' => "0.1",
                      'Copyright' => "Copyright (C) 2010 Gaetano Giunta",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>