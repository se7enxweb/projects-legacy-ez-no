<?php /*

[RoleSettings]
PolicyOmitList[]=devtools/classes

*/ ?>
