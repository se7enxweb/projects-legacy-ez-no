<?php /* #?ini charset="utf-8"?

[ezjscServer]
FunctionList[]=ezstarrating_rate
FunctionList[]=ezstarrating_user_has_rated

[ezjscServer_ezstarrating]
# Url to test this server function(rate):
# <root>/ezjscore/call/ezstarrating::rate::<contentobjectattribute_id>::<version>::<rating>
Class=ezsrServerFunctions
Functions[]=ezstarrating
PermissionPrFunction=enabled
File=extension/ezstarrating/classes/ezsrserverfunctions.php

*/ ?>