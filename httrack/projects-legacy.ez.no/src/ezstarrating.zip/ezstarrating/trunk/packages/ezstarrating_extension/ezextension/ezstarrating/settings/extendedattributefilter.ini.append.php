<?php /* #?ini charset="utf-8"?


[ezsrRatingFilter]
ExtensionName=ezstarrating
ClassName=ezsrRatingFilter
MethodName=createSqlParts
FileName=classes/ezsrratingfilter.php

*/ ?>