<!DOCTYPE TS><TS>
<context>
    <name>extension/ezstarrating/datatype</name>
    <message>
        <source>Star Rating</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currently %current_rating out of 5 Stars.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate %rating stars out of 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rating: %current_rating/5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%rating_count votes cast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thank you for rating!</source>
        <comment>When rating</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have already rated this page, you can only rate it once!</source>
        <comment>When rating</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your rating has been changed, thanks for rating</source>
        <comment>When rating</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>