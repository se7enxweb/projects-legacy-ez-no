<?php

// Operator autoloading

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] = array('script' =>  'extension/all2eqrcode/autoloads/all2eQRCodeOperators.php',
                                   'class' => 'all2eQRCodeOperators',
                                   'operator_names' => array( 'qrcode' ) );

?>
