<?php /* #?ini charset="utf-8"?

[CustomTagSettings]
AvailableCustomTags[]=qrcode
IsInline[qrcode]=true

[qrcode]
CustomAttributes[]
# type can be one of the following: url,sms,email,tel
CustomAttributes[]=type
# int-value for the width
CustomAttributes[]=width
# int-value for the height
CustomAttributes[]=height
*/ ?>
