<?php /*

[ModuleSettings]
ExtensionRepositories[]=all2eqrcode

ModuleList[]=qrcode

*/ ?>
