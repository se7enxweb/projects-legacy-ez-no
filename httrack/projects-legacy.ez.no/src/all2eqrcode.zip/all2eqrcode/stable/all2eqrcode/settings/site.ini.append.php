<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=all2eqrcode

[SiteAccessSettings]
AnonymousAccessList[]=qrcode/encode


*/ ?>
