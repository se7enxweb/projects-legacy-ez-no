<?php /* #?ini charset="utf-8"?

[Teaser]
Fuzzyness=5
Length=100
AddText=...
AddTextBeforeTagArray[]
AddTextBeforeTagArray[]=p
AddTextBeforeTagArray[]=div
KeepTagsArray[]
KeepTagsArray[]=a
KeepTagsArray[]=br
KeepTagsArray[]=img
KeepTagsArray[]=p
KeepTagsArray[]=strong
KeepTagsArray[]=em
KeepTagsArray[]=span
KeepAttributesArray[]
KeepAttributesArray[*]=class;style;title
KeepAttributesArray[a]=href;target
KeepAttributesArray[img]=src;alt
Tags2SpaceArray[]
Tags2SpaceArray[]=p
Tags2SpaceArray[]=br
Tags2SpaceArray[]=div
Tags2SpaceArray[]=img

*/ ?>