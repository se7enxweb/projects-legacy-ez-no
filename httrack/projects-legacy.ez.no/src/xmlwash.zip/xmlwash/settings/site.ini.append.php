[TemplateSettings]
ExtensionAutoloadPath[]=xmlwash

