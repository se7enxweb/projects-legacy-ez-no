[ExtensionSettings]
DesignExtensions[]=xmlwash

