<?php /*

[ExtensionSettings]
DesignExtensions[]=xajax_roleedit

[JavaScriptSettings]
JavaScriptList[]=xajax_roleedit.js

*/ ?>