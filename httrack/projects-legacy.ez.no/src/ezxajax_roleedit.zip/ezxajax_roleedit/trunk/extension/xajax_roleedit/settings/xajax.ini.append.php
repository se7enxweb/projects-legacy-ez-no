<?php /*

[ExtensionSettings]
ExtensionDirectories[]=xajax_roleedit

AvailableFunctions[moduleFunctions]=roleedit

*/ ?>