<?php /*

[ExtensionSettings]
DesignExtensions[]=ezxajax_roleedit

[JavaScriptSettings]
JavaScriptList[]=xajax_roleedit.js

*/ ?>