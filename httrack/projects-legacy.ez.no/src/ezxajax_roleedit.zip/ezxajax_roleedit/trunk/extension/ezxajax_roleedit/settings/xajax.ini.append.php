<?php /*

[ExtensionSettings]
ExtensionDirectories[]=ezxajax_roleedit

AvailableFunctions[moduleFunctions]=roleedit

*/ ?>