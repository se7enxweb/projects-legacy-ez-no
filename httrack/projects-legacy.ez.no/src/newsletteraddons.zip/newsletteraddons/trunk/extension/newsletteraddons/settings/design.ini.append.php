[ExtensionSettings]
DesignExtensions[]=newsletteraddons
