[ModuleSettings]
ExtensionRepositories[]=newsletteraddons