[TemplateSettings]
ExtensionAutoloadPath[]=newsletteraddons

[RoleSettings]
PolicyOmitList[]=newsletteraddons/unregister_subscription
PolicyOmitList[]=newsletteraddons/register_subscription
PolicyOmitList[]=newsletteraddons/subscription