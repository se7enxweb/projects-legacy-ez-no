<!DOCTYPE TS><TS>
<context>
    <name>design/eznewsletter/newsletter_preview</name>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Return to last view.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy this item to the same location</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/newletteraddons</name>
    <message>
        <source>unsubscribed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>subscribed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unsubscribed by admin</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>eznewsletter</name>
    <message>
        <source>Remove subscription</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>eznewsletteraddons</name>
    <message>
        <source>Are you sure you want to remove the subscription for the newsletter &quot;%name&quot;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your subscription for the newsletter &quot;%name&quot; has been successfully removed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ezxnewsletter</name>
    <message>
        <source>Register subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Firstname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Firstname of the subscriber.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name of the subscriber.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mobile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mobile Nr. of the subscriber.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email of the subscriber.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OutputFormat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to subscription.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel, and discard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back to the newsletter overview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thank you for registering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thank you for registering to %name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage Subscriptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your subscriptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscribed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No subscriptions available</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>newsletterlist</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>newsletteraddon/event</name>
    <message>
        <source>Newsletter import event</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>newsletteraddons</name>
    <message>
        <source>Remove subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your subscription removal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
