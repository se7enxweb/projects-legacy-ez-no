[DataTypeSettings]
ExtensionDirectories[]=newsletteraddons
AvailableDataTypes[]=newsletterlist
