<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=openid

#[RegionalSettings]
#TranslationExtensions[]=openid

[RoleSettings]
PolicyOmitList[]=openid

[SiteAccessSettings]
AnonymousAccessList[]=openid/register
AnonymousAccessList[]=openid/login
AnonymousAccessList[]=openid/complete

*/ ?>
