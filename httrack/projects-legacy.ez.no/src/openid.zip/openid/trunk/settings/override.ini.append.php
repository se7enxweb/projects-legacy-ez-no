<?php /* #?ini charset="utf-8"?

[login]
Source=user/login.tpl
MatchFile=user/login.tpl
Subdir=templates

*/ ?>
