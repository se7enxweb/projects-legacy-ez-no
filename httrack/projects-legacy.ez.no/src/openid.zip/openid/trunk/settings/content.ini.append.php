<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
#ExtensionDirectories[]=openid
#AvailableDataTypes[]=openid

*/ ?>
