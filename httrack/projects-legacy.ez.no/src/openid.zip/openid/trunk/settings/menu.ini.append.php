<?php /* #?ini charset="iso-8859-1"?
[NavigationPart]
Part[ezopenidnavigationpart]=openid

[TopAdminMenu]
Tabs[]=openid

[Topmenu_openid]
NavigationPartIdentifier=ezopenidnavigationpart
Name=OpenID
Tooltip=Registered OpenID Identities
URL[]
URL[default]=openid/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>
