<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=openid

[StylesheetSettings]
CSSFileList[]=openid.css

*/ ?>

