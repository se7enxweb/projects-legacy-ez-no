<?php /*
#
# $Id: module.ini.append.php 8 2009-10-23 20:55:05Z dpobel $
# $HeadURL: http://svn.projects.ez.no/ezfeedparse/trunk/extension/ezfeedparse/settings/module.ini.append.php $
#

[ModuleSettings]
ExtensionRepositories[]=ezfeedparse
ModuleList[]=feed

*/ ?>
