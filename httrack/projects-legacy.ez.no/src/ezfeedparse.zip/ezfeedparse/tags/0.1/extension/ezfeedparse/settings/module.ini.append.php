<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezfeedparse
ModuleList[]=feed

*/ ?>
