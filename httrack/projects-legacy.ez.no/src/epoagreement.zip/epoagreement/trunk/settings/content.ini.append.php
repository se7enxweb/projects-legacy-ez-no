<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=epoagreement
AvailableDataTypes[]=epoagreementcheckbox
*/ ?>