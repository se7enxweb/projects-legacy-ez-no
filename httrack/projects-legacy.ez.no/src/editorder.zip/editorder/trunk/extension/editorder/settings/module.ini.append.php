<?php /* #?ini charset="utf-8"?
[ModuleSettings]
ExtensionRepositories[]=editorder
ModuleList[]=editorder
*/ ?>