<?php /* #?ini charset="utf-8"?
[UserGroups]
ReceptionistsObjectID=59
*/ ?>