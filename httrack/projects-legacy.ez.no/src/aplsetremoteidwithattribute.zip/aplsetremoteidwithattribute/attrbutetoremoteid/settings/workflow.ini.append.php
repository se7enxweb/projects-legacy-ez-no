<?php /*

[EventSettings]
ExtensionDirectories[]=attributetoremoteid
AvailableEventTypes[]=event_attributetoremoteid

*/ ?>