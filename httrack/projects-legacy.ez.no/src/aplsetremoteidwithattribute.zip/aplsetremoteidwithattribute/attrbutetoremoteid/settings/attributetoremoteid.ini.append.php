<?php /*

[AttributeToRemoteIDSettings]

# Name the block AttributeToRemoteIDSettings_ + classID   numeric

[AttributeToRemoteIDSettings_43]
ContentClassAttributeIdentifier=product_number



*/ ?>
