[ModuleSettings]
ExtensionRepositories[]=xrowecommerce
ModuleList[]=xrowecommerce
ModuleList[]=customersearch
ModuleList[]=orderedit