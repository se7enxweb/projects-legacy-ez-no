<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=ezoption2
AvailableDataTypes[]=ezoption2

*/ ?>