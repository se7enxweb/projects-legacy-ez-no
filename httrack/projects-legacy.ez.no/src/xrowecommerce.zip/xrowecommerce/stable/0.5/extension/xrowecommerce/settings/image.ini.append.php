<?php /* #?ini charset="utf-8"?

[AliasSettings]
AliasList[]=product_full
AliasList[]=product_line

[product_full]
Reference=
Filters[]
Filters[]=geometry/scaledownonly=400;300

[product_line]
Reference=
Filters[]
Filters[]=geometry/scale=125;94

*/ ?>