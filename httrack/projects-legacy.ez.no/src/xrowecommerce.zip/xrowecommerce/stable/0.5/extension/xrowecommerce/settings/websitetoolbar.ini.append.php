
[WebsiteToolbarSettings]
AvailableForClasses[]=xrow_product
AvailableForClasses[]=xrow_product_category

ContentClassContainers[]=xrow_product
ContentClassContainers[]=xrow_product_category

ODFDisplayClasses[]=xrow_product
ODFDisplayClasses[]=xrow_product_category