<?php /* #?ini charset="utf-8"?

[xrow_client]
MaxParents=1
ClearCacheMethod[]
ClearCacheMethod[]=object
ClearCacheMethod[]=parent
ClearCacheMethod[]=relating

*/ ?>