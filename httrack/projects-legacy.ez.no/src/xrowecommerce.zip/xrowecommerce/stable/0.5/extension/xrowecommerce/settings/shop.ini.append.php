<?php /* #?ini charset="utf-8"?

[VATSettings]
ExtensionDirectories[]=xrowecommerce
Handler=xrowecommerce
RequireUserCountry=false
DynamicVatTypeName=E-Commerce

*/ ?>