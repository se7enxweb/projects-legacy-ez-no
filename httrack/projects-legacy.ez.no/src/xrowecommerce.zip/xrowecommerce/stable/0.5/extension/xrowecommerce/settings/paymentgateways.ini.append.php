[GatewaysSettings]
AvailableGateways[]=xrowinvoice
AvailableGateways[]=xrowcashondelivery
AvailableGateways[]=xrowprepayment
GatewaysDirectories[]=extension/xrowecommerce/classes/gateways