<?php /* #?ini charset="utf-8"?
# Please use an override instead

#[MerchantLocations]
#Locations[]=USA
#Locations[]=GER
#USA[]=CT
#USA[]=NY

*/ ?>