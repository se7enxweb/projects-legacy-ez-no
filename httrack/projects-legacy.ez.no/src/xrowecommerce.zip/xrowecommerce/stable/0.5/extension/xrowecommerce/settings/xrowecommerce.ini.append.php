<?php /* #?ini charset="utf-8"?
[Settings]
Captcha=enabled
Coupon=enabled
#States of fields can be disabled, enabled, not_required
Captcha=disabled
Coupon=disabled
Catalogueorder=disabled
CompanyName=disabled
CompanyAdditional=disabled
MI=not_required
State=not_required
TaxID=disabled
Fax=enabled
CountryWithStatesList[]
#CountryWithStatesList[]=USA
#CountryWithStatesList[]=MEX
#CountryWithStatesList[]=CAN
DescriptionLength=60
ShopUserClassList[]=client
# Please use an override instead

#[MerchantLocations]
#Locations[]=USA
#Locations[]=GER
#USA[]=CT
#USA[]=NY

*/ ?>
