<?php /* #?ini charset="utf8"?

[xrow_shipping_state]
Source=content/datatype/edit/ezstring.tpl
MatchFile=stateprovince.tpl
Subdir=templates
#Match[class_identifier]=xrow_client
#Match[attribute_identifier]=s_state

[xrow_state]
Source=content/datatype/edit/ezstring.tpl
MatchFile=stateprovince.tpl
Subdir=templates
#Match[class_identifier]=xrow_client
#Match[attribute_identifier]=state

*/ ?>