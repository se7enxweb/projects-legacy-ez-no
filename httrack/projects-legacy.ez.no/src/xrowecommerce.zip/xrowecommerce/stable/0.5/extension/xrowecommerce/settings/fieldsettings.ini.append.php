<?php /* #?ini charset="utf-8"?

[DisplayFieldSettings]
DisplayCompanyName=disabled
DisplayCompanyForm=disabled
DisplayTaxId=disabled
DisplayFax=disabled

*/ ?>