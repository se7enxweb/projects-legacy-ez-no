<?php /* #?ini charset="utf-8"?
# eZ publish configuration file for modules

[ModuleSettings]
ExtensionRepositories[]=ezoption2
ModuleList[]=variationupload

*/ ?>