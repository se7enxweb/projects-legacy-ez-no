<?php

class xrowPaymentErrorException extends ezcBaseException
{

}

?>