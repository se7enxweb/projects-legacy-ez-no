<?php /* #?ini charset="utf-8"?

[xrowProductVariationTemplateBrowse]
StartNode=media
SelectionType=single
ReturnType=NodeID
TopLevelNodes[]
TopLevelNodes[]=content
TopLevelNodes[]=media

*/ ?>