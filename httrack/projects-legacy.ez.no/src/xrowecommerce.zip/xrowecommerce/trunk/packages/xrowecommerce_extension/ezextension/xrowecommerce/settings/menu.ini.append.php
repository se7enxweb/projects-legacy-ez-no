<?php /* #?ini charset="utf-8"?

[Leftmenu_shop]
LinkNames[tin]=Tax identification
LinkNames[taxes]=Order statistics
LinkNames[product]=Products with zero weight
LinkNames[listitems]=List subscriptions
LinkNames[forecast]=Recurring order forecast
LinkNames[history]=Recurring order history
LinkNames[attributelist]=Product attributes
LinkNames[templatelist]=Product templates
LinkNames[priceimport]=Price import
LinkNames[priceexport]=Price export
Links[tin]=xrowecommerce/tin
Links[taxes]=orderedit/taxes
Links[product]=orderedit/product
Links[listitems]=recurringorders/listitems
Links[forecast]=recurringorders/forecast
Links[history]=recurringorders/history
Links[attributelist]=productvariation/attributelist
Links[templatelist]=productvariation/templatelist
Links[priceimport]=xrowecommerce/priceimport
Links[priceexport]=xrowecommerce/priceexport

*/ ?>