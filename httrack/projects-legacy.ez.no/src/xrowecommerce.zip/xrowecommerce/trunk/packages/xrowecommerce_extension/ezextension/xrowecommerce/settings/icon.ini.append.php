<?php /* #?ini charset="utf-8"?

[ClassIcons]
ClassMap[xrow_product_category]=filesystems/folder.png
ClassMap[xrow_product]=apps/package.png
ClassMap[client]=actions/identity.png
ClassMap[coupon]=mimetypes/tar.png
ClassMap[xrow_manufacturer]=mimetypes/readme.png

*/ ?>