<?php
class ups_price
{
    var $status;
    var $description;
    var $costs;
    var $shipping_type;
    var $currency_unit;
} // CLASS UPS_PRICE
?>