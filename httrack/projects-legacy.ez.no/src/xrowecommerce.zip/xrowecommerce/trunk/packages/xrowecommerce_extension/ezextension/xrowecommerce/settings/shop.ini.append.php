<?php /* #?ini charset="utf-8"?

[VATSettings]
ExtensionDirectories[]=xrowecommerce
Handler=xrowECommerce
RequireUserCountry=false
DynamicVatTypeName=xrow E-Commerce Dynamic Tax
UserCountryAttribute=country

#[CurrencySettings]
#PreferredCurrency=EUR
# Set your default currency here

*/ ?>