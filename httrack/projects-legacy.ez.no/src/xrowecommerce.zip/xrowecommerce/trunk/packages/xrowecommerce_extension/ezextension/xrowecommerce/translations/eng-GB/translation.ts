<!DOCTYPE TS><TS>
<context>
    <name>design/admin/content/edit</name>
    <message>
        <source>Edit &lt;%object_name&gt; [%class_name]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translating content from %from_lang to %to_lang</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Publish the contents of the draft that is being edited. The draft will thus become the published version of the object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store the contents of the draft that is being edited and continue editing. Use this button to periodically save your work while editing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to discard the draft?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard the draft that is being edited. This will also remove the translations that belong to the draft (if any).</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/parts/shop/menu</name>
    <message>
        <source>Shop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Archive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currencies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferred currency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products overview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Google Analytics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payments Pending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zero weight prods</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recurring order forecast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recurring order history</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/accounthandlers/html/ez</name>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Company name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form of enterprise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zip Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Authorize.net : Transaction ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Card Holder&apos;s Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last 4 Digits of Card Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Card Expiration Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Card Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Refund Order</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/basket</name>
    <message>
        <source>Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order total</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderlist</name>
    <message>
        <source>Products with zero weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orderitem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store shippingcosts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orders [%count]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select order for removal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>( removed )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The order list is empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Archive selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Archive selected orders.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified any of the fields above.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order statistic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderstatistics</name>
    <message>
        <source>Select the year for which you wish to view statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the start month for which you wish to view statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the start day for which you wish to view statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the year till which you wish to view statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the stop month for which you wish to view statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update the list using the values specified by the menus on the left.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product statistics [%count]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Totals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products (ex. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products (inc. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;nbsp;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The list is empty.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderview</name>
    <message>
        <source>Contentobject_ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order #%order_id [%order_status]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove this order.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status history [%status_count]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Person</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the person which modified the status of the order. Click to view the user information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/base</name>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to Automatic Delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check out</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowecommerce</name>
    <message>
        <source>Confirm E-mail</source>
        <translation>Confirm E-mail</translation>
    </message>
    <message>
        <source>Shopping Cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following items were removed from your cart, because the products were changed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax is unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax percentage is not yet known for some of the items being purchased.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This probably means that some information about you is not yet available and will be obtained during checkout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attempted to add object without price to cart.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your payment was aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal Ex. Tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have no products in your cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal Ex. TAX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal of items ex. Tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order Reciept #%order_id </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TAX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal of items Ex. Taxt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>starting at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>starting at </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>read more</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attempted to add object without price to basket.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1. Cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2. Billing, Shipping and Coupons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3. Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4. Payment info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5. Order completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6. Review reciept</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hazardous item(s) found in your cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dear Customer,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>We&apos;ve removed the following hazardous items from your shopping cart since we are NOT allowed to ship these items to your destination. For further questions please contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lbs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validation error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input did not validate, all fields marked with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>must be filled in.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter your billing address exactly as it appears on your credit card statement.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a payment method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please select your desired payment method below.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/product</name>
    <message>
        <source>Add to Shopping Cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>People who bought this also bought</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Basket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to cart</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/shop/basket</name>
    <message>
        <source>Estimated Tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estimated Shipping and Handling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lbs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/shop</name>
    <message>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Company</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form of enterprise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TaxID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delivery &amp; Shipping Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zip code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billing Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1. Cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2. Billing, Shipping and Coupons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3. Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4. Payment info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5. Order completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lbs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal Ex. TAX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/user</name>
    <message>
        <source>Username</source>
        <comment>User name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billing Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Required field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Company name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>City / Town</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State / Province</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zip / Postcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter your coupon code exactly as it appears on your promotion.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coupon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My billing and shipping addresses are identical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Verification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Already Registered?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter your username or email address and password below to sign-in.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forgot Password?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forgot your password?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Customer?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create an account to save your shipping and billing information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sign Up</source>
        <comment>Button</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter your billing address exactly as it appears on your credit card statement.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form of company</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping Information</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/workflow</name>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/edit</name>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype/view</name>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowecommerce</name>
    <message>
        <source>Quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SKU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extended price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal Ex. Tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order total</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowecommerce</name>
    <message>
        <source>Fraud detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please contact customer support. We are blocking your ordering attempts for the next 24 hours.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowecommerce</name>
    <message>
        <source>Enter account information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer order view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orderedit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orderitem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zero weight prods</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax listing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowecommerce</name>
    <message>
        <source>Inventory Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>xrow Ecommerce Payment Gateway</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
