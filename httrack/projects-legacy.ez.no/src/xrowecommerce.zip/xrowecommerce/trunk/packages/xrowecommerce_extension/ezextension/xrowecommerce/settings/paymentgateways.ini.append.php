<?php /* #?ini charset="utf-8"?

[GatewaysSettings]
AvailableGateways[]=xrowInvoice
AvailableGateways[]=xrowCashOnDelivery
AvailableGateways[]=xrowAdvancepayment

#[CashOnDeliverySettings]
#Costs=0

*/ ?>