<?php /* #?ini charset="utf-8"?

[CouponSettings]
Description=Coupon

*/ ?>