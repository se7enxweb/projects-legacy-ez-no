<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=xrowecommerce
ModuleList[]=xrowecommerce
ModuleList[]=recurringorders
ModuleList[]=customersearch
ModuleList[]=orderedit
ModuleList[]=productvariation
ModuleList[]=order
ModuleList[]=shipping
ModuleList[]=variationupload

*/ ?>