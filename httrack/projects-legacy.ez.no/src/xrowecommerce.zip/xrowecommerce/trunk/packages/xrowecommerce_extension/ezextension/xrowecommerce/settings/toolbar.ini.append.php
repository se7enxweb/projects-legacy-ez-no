<?php /* #?ini charset="utf-8"?

[Tool]
AvailableToolArray[]=poll
AvailableToolArray[]=popular_tags

[Tool_poll]
parent_node=2

[Tool_poll_description]
parent_node=Item source

[Tool_popular_tags]
parent_node=2
limit=10

[Tool_popular_tags_description]
parent_node=Item source
limit=Limit

*/ ?>