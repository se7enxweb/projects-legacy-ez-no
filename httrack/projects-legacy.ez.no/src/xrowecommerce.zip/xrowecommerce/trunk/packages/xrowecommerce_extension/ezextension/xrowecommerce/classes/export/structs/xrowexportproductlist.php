<?php
class xrowExportProductList extends ArrayObject
{
	public function append( xrowExportProduct $value ) {
		parent::append( $value );
	}
}