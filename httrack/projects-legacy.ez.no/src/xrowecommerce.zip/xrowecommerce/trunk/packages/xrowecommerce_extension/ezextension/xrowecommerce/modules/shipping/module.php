<?php
$Module = array( "name" => "Shipping" );
$ViewList = array();
$FunctionList = array();
$FunctionList['read'] = array();
?>