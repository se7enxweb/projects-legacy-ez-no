<?php

/**
 *
 */
interface xrowExportProductPlugin
{
    public function export( xrowExportProductList $list );
}

?>