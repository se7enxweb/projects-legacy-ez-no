<?php /* #?ini charset="utf-8"?

[RoleSettings]
PolicyOmitList[]=xrowecommerce/register
PolicyOmitList[]=xrowecommerce/directorder
PolicyOmitList[]=xrowecommerce/json

[TemplateSettings]
ExtensionAutoloadPath[]=xrowecommerce

[RegionalSettings]
TranslationExtensions[]=xrowecommerce

[Cache]
CacheItems[]=geonames

[Cache_geonames]
name=geonames cache
id=xrowecommerce
path=geonames

#This setting lets ezpublish use the user class "client" as default user
#[UserSettings]
#AnonymousUserID=
#DefaultUserPlacement=
#UserClassID=

*/ ?>
