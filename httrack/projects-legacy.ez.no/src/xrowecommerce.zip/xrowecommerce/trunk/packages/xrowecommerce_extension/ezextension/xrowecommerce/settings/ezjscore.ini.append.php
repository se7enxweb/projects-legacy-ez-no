<?php /* #?ini charset="utf-8"?

[ezjscServer]
FunctionList[]=xrowecommerce

[ezjscServer_xrowecommerce]
Class=xrowECommerceJSON

*/ ?>