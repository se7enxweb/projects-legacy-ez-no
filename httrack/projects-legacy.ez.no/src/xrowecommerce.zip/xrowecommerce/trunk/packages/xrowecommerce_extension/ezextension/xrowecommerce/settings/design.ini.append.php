<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=xrowecommerce

[JavaScriptSettings]
FrontendJavaScriptList[]=ezjsc::jquery
FrontendJavaScriptList[]=ezjsc::jqueryio
FrontendJavaScriptList[]=ezjsc::yui3
FrontendJavaScriptList[]=ezjsc::yui3io
FrontendJavaScriptList[]=xrowecommerce.js
FrontendJavaScriptList[]=xrowproductvariation.js

BackendJavaScriptList[]=ezjsc::yui3
BackendJavaScriptList[]=ezjsc::yui3io
BackendJavaScriptList[]=xrowproductvariation.js
BackendJavaScriptList[]=xrowecommerce.js
BackendJavaScriptList[]=xrowecommerce_backend.js

[StylesheetSettings]
BackendCSSFileList[]=xrowproductvariation.css
BackendCSSFileList[]=backend.css
FrontendCSSFileList[]=frontend.css

*/ ?>