<?php /* #?ini charset="utf-8"?

[HandlerSettings]
ExtensionRepositories[]=xrowecommerce

[ConfirmOrderSettings]
Handler=xrowecommerce

[AccountSettings]
Handler=xrowecommerce

*/ ?>