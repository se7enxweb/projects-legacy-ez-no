<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ScriptDirectories[]=extension/xrowecommerce/cronjobs

[CronjobPart-recurringorders]
Scripts[]=recurringorders.php

[CronjobPart-productexport]
Scripts[]=productexport.php

[CronjobPart-feedbackmail]
Scripts[]=feedbackmail.php

[CronjobPart-priceexport]
Scripts[]=priceexport.php

[CronjobPart-priceimport]
Scripts[]=priceimport.php

*/ ?>