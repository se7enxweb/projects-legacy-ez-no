<?php /* #?ini charset="utf-8"?

[ViewSettings]
GroupedInput[]=xrowproductvariation
GroupedInput[]=ezcreditcard
GroupedInput[]=xrowbillingcycle

[EditSettings]
GroupedInput[]=xrowproductvariation
#GroupedInput[]=ezcoupon
GroupedInput[]=ezcreditcard
GroupedInput[]=xrowbillingcycle

[CollectionSettings]
GroupedInput[]=ezcreditcard
GroupedInput[]=xrowbillingcycle

*/ ?>
