<?php /* #?ini charset="iso-8859-1"?

[OrderSettings]
# showFooter=true|false
# enables or disables the footer
showFooter=true

#[InvoiceSettings]
#CompanyLogo=/extension/order/design/standard/images/invoice/logo.png
#CompanyName=Your Company
#CompanyAddress= XX Street
#CompanyAddress2=Sampletown 66
#CompanyCountry=Neutral Country
#CompanyPhone=123-123-123-1
#CompanyWebsite=www.example.com

*/ ?>