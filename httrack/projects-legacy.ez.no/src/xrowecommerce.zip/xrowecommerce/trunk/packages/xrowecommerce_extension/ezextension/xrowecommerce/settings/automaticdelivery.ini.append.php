<?php /* #?ini charset="utf-8"?

[AutomaticDeliverySettings]
AutomaticDelivery=enabled

*/ ?>