<?php
class xrowShippingGatewayException extends Exception {}
?>