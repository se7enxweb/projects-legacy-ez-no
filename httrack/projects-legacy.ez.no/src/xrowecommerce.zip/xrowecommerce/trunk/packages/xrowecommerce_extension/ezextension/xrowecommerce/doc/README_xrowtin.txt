Convert a ezstring to a xrowtin


UPDATE ezcontentclass_attribute set data_type_string = 'xrowtin' WHERE id = 687;

UPDATE ezcontentobject_attribute set data_type_string = 'xrowtin', data_int = '0' WHERE contentclassattribute_id = 687;