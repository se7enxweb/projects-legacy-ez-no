<?php 
/**
 * Defines a callable Josn interface via YUI 
 * 
 * 
YUI({combine: true, timeout: 10000}).use("node", "io", "json-parse",function (Y) {


};
 * 
 */
interface eZJSON {};

?>