<!DOCTYPE TS><TS>
<context>
    <name>content/datatype/edit/xrowbillingcycle</name>
    <message>
        <source>Quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Period</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/class/edit_language</name>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/class/select_language</name>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/parts/shop/menu</name>
    <message>
        <source>Order statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recurring order forecast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recurring order history</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax identification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List subscriptions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/section/edit</name>
    <message>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/customerlist</name>
    <message>
        <source>Forecast [%forecast]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The forecast list is empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages [%history]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collection ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The message list is empty.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/discountgroupmembershipview</name>
    <message>
        <source>Total recurring forecast on revenue</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderlist</name>
    <message>
        <source>Products with zero weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orderitem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store shippingcosts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orders [%count]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select order for removal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>( removed )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The order list is empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Archive selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Archive selected orders.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified any of the fields above.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order statistic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unpaid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>paid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected orders.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print invoice and packaging slip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print shipping plan</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderstatistics</name>
    <message>
        <source>Select the year for which you wish to view statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the start month for which you wish to view statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the start day for which you wish to view statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the year till which you wish to view statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the stop month for which you wish to view statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update the list using the values specified by the menus on the left.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product statistics [%count]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Totals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products (ex. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products (inc. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;nbsp;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The list is empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderview</name>
    <message>
        <source>Contentobject_ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order #%order_id [%order_status]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price ex. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price inc. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Price ex. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Price inc. VAT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal of items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove this order.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status history [%status_count]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Person</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the person which modified the status of the order. Click to view the user information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Packing slip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invoice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next Day Service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2nd Day Service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPS Ground (USA only)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPS Next Business Day Air (USA only)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPS 2nd Business Day Air (USA only)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>USPS Express Mail International (EMS)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>USPS Global Express Guaranteed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Company</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/workflow/eventtype/edit</name>
    <message>
        <source>Node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add objects</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfo/form</name>
    <message>
        <source>Homepage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/collectedinfo/poll</name>
    <message>
        <source>%count total votes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/article</name>
    <message>
        <source>Tip a friend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Related products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product reviews</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/forum</name>
    <message>
        <source>Create your review</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/poll</name>
    <message>
        <source>Vote</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/full/product</name>
    <message>
        <source>Add to wish list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/edit</name>
    <message>
        <source>My notification settings.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Select which nodes from which classes can be selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>using payment gateway</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multiple choice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select which countries by default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unchecked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checked</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CSV File for import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Percent (basket)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flat (basket)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Free Shipping and Handling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current stored card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bank code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove debit card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>expires</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove credit card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Card type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name on card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Credit card number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Security Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name of account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select option for removal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select price for removal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected prices.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price list is empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set custom price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set custom price.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove custom price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are no available currencies.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are no options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add a new option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No card stored.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not specified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/ezoe</name>
    <message>
        <source>Upload new</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload local file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload is in progress, it may take a few seconds...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/shop</name>
    <message>
        <source>Order history</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total inc. TAX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The information above is from your last order.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/workflow</name>
    <message>
        <source>Aftersale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No coupon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coupon validation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Have coupon</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/workflow/eventtype</name>
    <message>
        <source>Node which includes shelf warmer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No objects selected.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/harley</name>
    <message>
        <source>Your Purchase Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancellation Policy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right of Revocation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You may declare the revocation of your contractual statement in text form (e.g. letter, email) or by returning the merchandise within two weeks. The revocation does not have to contain any explanation. The revocation period commences the day following the receipt of merchandise and this revocation instruction in text form. The time-limit shall be deemed to be observed by the timely dispatch of the declaration of revocation or the returning of the shipment.The revocation is to be addressed to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Consequences of Revocation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In case of a valid revocation, all mutually received performances as well as emoluments taken (e.g. interest), if applicable, are to be restituted by either side. If you are unable or partially unable to restitute the merchandise to us or can only restitute it in a deteriorated condition, you have to insofar compensate for its value where applicable. This does not apply if the deterioration is exclusively due to examining the merchandise ? as for instance in a retail store ? or putting the merchandise to its intended use. Things that can be shipped by parcel are to be returned on our risk. Things that cannot be shipped by parcel will be picked up. You are obliged to bear the costs of the return shipment, if the merchandise delivered corresponds to the merchandise ordered, and if the price of the merchandise to be sent back does not exceed an amount of forty euros or if, where the price is higher, you have at the date of the revocation not yet rendered consideration or given a part payment. In all other cases, the returning of the shipment for you is free of charge. All reimbursement obligations must be fulfilled within 30 days of the declaration of revocation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hello</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>many thanks for ordering at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you have any questions concerning your customer account or your order,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>please send an email to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>or call us by phone on </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Below you can find your order confirmation, thank you!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SKU</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/harley/email</name>
    <message>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/recurringorders</name>
    <message>
        <source>Subscriptions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowecommerce</name>
    <message>
        <source>Fraud detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please contact customer support. We are blocking your ordering attempts for the next 24 hours.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal Ex. Tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estimated Tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <comment>User name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have no items in your shopping cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billing, Shipping and Coupons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billing and Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reciept</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sorry, there are no items left in your cart.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a payment method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please select your desired payment method below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SKU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extended price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>starting at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to Automatic Delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Company</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Company additional information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zip code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Already a user?</source>
        <comment>User name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login</source>
        <comment>Button</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billing Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Required field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Company name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State / Province</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coupon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter your coupon code exactly as it appears on your promotion.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My billing and shipping addresses are identical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Verification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Already Registered?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter your username or email address and password below to sign-in.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A valid username and password is required to login.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Access not allowed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are not allowed to access %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forgot Password?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forgot your password?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Customer?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create an account to save your shipping and billing information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sign Up</source>
        <comment>Button</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter your billing address exactly as it appears on your credit card statement.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form of company</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>City / Town</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zip / Postcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No image available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to Shopping Cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>People who bought this also bought</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Basket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shopping Cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following items were removed from your cart, because the products were changed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax is unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax percentage is not yet known for some of the items being purchased.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This probably means that some information about you is not yet available and will be obtained during checkout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attempted to add object without price to basket.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your payment was aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hazardous item(s) found in your cart.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dear Customer,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>We&apos;ve removed the following hazardous items from your shopping cart since we are not allowed to ship these items to your destination. For further questions please contact %companyname%.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal ex. tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lbs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validation errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A click on the image enlarges the image in a popup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checkout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this button to remove items from your shopping cart.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your cart is empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select the product-categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>on the left to view and order products.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Option:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LBS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products that match the following properties are listed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no weight attribute in the variations and no general weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no general weight and zero weight in the variations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gratulation. No products left anymore.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multiple occurencies!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search for customer in the system via e-mail address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit shippingcosts with this order number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail address or Order No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A log of this change will be saved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A wise decision!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected period is from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>till</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>and includes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (inc Tax)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (ex Tax)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Shipping/handling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sorry, no order in the selected Month to show.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Although your Login User Name must be kept the same, you can update your Email Address and/or change your Password by entering new information in the appropriate field.  When complete, click the &quot;Update&quot; button at the bottom of the page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Credit card Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your credit card information is needed, if you want to make use of our recurring order option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add your selections to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatic Delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This product is available for</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To add this product to your Automatic Delivery you have to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What is Automatic Delivery?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By placing your initial Automatic Delivery order and setting up an Automatic Delivery schedule, you authorize us to charge the same credit card for future Automatic Delivery orders until you cancel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Since the accuracy of your credit card, shipping and billing information is vital to Automatic Delivery, please promptly submit changes through the my account section.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Article Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipped to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Card Holder&apos;s Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last 4 Digits of Card Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Card Expiration Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Original description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Original price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This table contains the specific product images, product id&apos;s, product names and links to the full view of the product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter your email address, login and password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use eZ Publish roles and policies for payment method selection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional Orderinformation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Partial delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unkown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue Shopping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty Cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <comment>Username</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accept the terms and conditions to continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No partial delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to use any of the available payment methods.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your notes on order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I have read the %linkstart%general terms and conditions%linkend% and accept them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print order receipt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue shopping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show the terms and conditions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start price export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start the price export.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total lines in file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prices updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Same price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SKU not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price was not a valid number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New price created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New sliding price (not imported)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>These SKUs were not found, prices couldn&apos;t be imported:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start price import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start the price import.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product not found. Please correct the SKU.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unconfirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billing &amp; shipping address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this button to empty your shopping cart.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this button to update your shopping cart.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this button to place your order.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estimated shipping and handling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order receipt #%order_id </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apartment, suite, unit, building, floor, etc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Street address, P.O. box, company name, c/o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billing Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use our Automatic Delivery service to have this item sent to you as often as you like. You&apos;ll get priority on our inventory and save time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <comment>Save Button</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tax identification numbers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Package</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name of package</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One step back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Net Sale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There is no order in the selection for this period.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What is a Security Code?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Card Security Code is located on the back of MasterCard, Visa and Discover credit or debit cards and is typically a separate group of 3 digits to the right of the signature strip.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>On American Express cards, the Card Security Code is a printed (NOT embossed) group of four digits on the front towards the right.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause Automatic Delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you are away and you wish to not receive your orders please check this box. We will also pause your Automatic Delivery, if we notice problems with your order request.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Important Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Items with the same &quot;Next order&quot; date will be combined on the same order.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price per item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All prices exclude tax, shipping and handling. Those will be added to your order once a new order is created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View All Tags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping Gateway</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The shipping gateway can`t process your data. Please contact support.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The shipping gateway provider has a problem. Please try again or contact support.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Take a look at our</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Double click on above image to view full picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>view products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>view product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Basket items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are no reviews yet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You need to be logged in to create reviews. You can do so %login_link_start%here%login_link_end%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer Reviews</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate this review:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create your review</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>We&apos;ve found the following hazardous items from your shopping cart since we are not allowed to ship these items to your destination. For further questions please contact us.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter different shipping address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Account:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Personal Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change my billing and shipping address or your credit card information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change my billing and shipping address or creditcard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change my password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shop Features</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View my recent and current orders.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My orders.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View my recurring orders.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My recurring orders.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit or view my wishlist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My wishlist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit or view your notification settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please select your product below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regular Retail Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Our Thank You Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to my order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No. Thanks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private Person</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private person</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscribe to newsletter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mr.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mrs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Guest Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>When you want to proceed your purchase as a guest please type in your name and email adress here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checkout as guest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You want to register as a new customer? Then type in your data and proceed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register &amp; Proceed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You already are a customer? Then login here with your account data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login &amp; Proceed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowecommerce/directorder</name>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete this row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add online order from catalogue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add your desired products to the shopping cart.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SKU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add rows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to shopping cart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add products to shopping cart</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowecommerce/productvariation</name>
    <message>
        <source>Product template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You try to change the template. Please confirm this action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete attribute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Column headline configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show column config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide column config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No product variations entered.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit product variation attribute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose datatype</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No datatype was selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store datatype</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit datatype - error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit datatype</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a name for the attribute.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a valid identifier for the attribute.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This identifier is already in use. Enter another one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product attribute setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit the &lt;%attribute_name&gt; attribute.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are no attributes available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this menu to select the language you to want use then click the &quot;New attribute&quot; button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New attribute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new attribute.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the language you want to edit the attribute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Column name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Column description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show on frontend:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to search:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a valid number or leave the field empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input required:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sliding price:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start point:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nothing selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All classes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Needs translation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unique SKU required:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You try to delete this attribute from the product template. Please confirm this action by clicking the OK button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit product template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit template - error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One or more errors occured. Please correct them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter some attributes in the setup, before you create the template.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No attributes added for this template.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Available attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use the select box and the button below to add attributes to this product template.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add attribute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default sort order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No sorting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product template setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit the &lt;%template_name&gt; product template.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are no product templates available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this menu to select the language you to want use then click the &quot;New product template&quot; button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New product template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new product template.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a valid number.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter valid prices. Wrong prices are marked with a red *</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a price for 1 item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please correct the amount marked with a red *</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SKU already in use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show in select box:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You need to select a datatype for the attribute.
      It&apos;s not possible to change this afterwards.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a valid date.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowexommerce</name>
    <message>
        <source>Product review</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowtin</name>
    <message>
        <source>not validated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>validated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>validated by administration</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>standard/datatype/ezcreditcard</name>
    <message>
        <source>Not used</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
