<!DOCTYPE TS><TS>
<context>
    <name>extension/xrowcomdirect</name>
    <message>
        <source>Validation error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter your credit card details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>i</source>
        <comment>i for information</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter your cash card details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Card Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expiry Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The card with 3 digits security code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The card security code consists of a series of 3 digits on the back of your credit card.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Credit Card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Direct Debit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Card Holder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Credit Card Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Security Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This code constitutes an important security feature which should prevent the use of faked or stolen credit cards. It is not stored on our servers, and its request is for increased safety of our customers only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One step back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter your bank account details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Holder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bank Code</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowcomdirect/errors</name>
    <message>
        <source>Not able to process at present. Try again later or select a different method of payment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not able to process at present. Select a different method of payment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Credit card was not approved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The expiry date is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The card issuer is temporarily not reachable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not able to process at present.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The transaction is not completed successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The card number is incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The expiry date is incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The security code is incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The first part or length of the card number is incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The check sum of the card number is incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The card has expired.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The bank code is incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The account number is incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The name of account holder is incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The bank code is unknown.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The account number does not correspond to the bank code.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
