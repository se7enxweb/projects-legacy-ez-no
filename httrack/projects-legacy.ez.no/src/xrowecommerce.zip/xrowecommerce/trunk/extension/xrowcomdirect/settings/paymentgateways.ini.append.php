[GatewaysSettings]
AvailableGateways[]=xrowComdirectCC
AvailableGateways[]=xrowComdirectEC