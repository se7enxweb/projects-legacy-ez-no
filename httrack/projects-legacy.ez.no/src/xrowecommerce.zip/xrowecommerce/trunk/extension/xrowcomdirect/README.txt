Comdirect / Coposweb gateway for eZ Publish

The merchant interface can be found under http://www.coposweb.de/.

xrowcomdirect.ini.[ServerSettings].Username and xrowcomdirect.ini.[ServerSettings].Password are the same 
login deteils as your merchant account.
