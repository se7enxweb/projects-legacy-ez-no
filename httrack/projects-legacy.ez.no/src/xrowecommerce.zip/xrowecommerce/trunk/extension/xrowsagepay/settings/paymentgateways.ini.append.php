<?php /* #?ini charset="utf-8"?

[GatewaysSettings]
AvailableGateways[]=xrowSagePay

#[CashOnDeliverySettings]
#Costs=0

*/ ?>