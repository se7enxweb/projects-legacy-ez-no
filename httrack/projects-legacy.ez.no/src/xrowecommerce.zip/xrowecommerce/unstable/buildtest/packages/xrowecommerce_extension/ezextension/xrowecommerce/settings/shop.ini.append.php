<?php /* #?ini charset="utf-8"?

[VATSettings]
ExtensionDirectories[]=xrowecommerce
Handler=xrowecommerce
RequireUserCountry=false
DynamicVatTypeName=xrow E-Commerce Dynamic Tax

#[CurrencySettings]
#PreferredCurrency=EUR
# Set your default currency here

*/ ?>