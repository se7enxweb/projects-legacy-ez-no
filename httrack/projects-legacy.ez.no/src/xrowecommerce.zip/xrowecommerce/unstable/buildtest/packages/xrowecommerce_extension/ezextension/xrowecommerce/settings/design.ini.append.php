<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=xrowecommerce
DesignExtensions[]=order

[JavaScriptSettings]
JavaScriptList[]=xrowproductvariation.js
JavaScriptList[]=xrowecommerce.js

#JavaScriptList[]=insertmedia.js
#JavaScriptList[]=../lib/yui/2.7.0/build/yahoo-dom-event/yahoo-dom-event.js
#JavaScriptList[]=../lib/yui/2.7.0/build/calendar/calendar-min.js
#JavaScriptList[]=../lib/yui/2.7.0/build/yahoo/yahoo-min.js
#JavaScriptList[]=../lib/yui/3.0/build/yui/yui-min.js
#JavaScriptList[]=../lib/yui/2.7.0/build/event/event-min.js
#JavaScriptList[]=../lib/yui/2.7.0/build/dom/dom-min.js
#JavaScriptList[]=../lib/yui/2.7.0/build/container/container-min.js
#JavaScriptList[]=../lib/yui/2.7.0/build/calendar/calendar-min.js
#JavaScriptList[]=../lib/yui/2.7.0/build/dragdrop/dragdrop-min.js
#JavaScriptList[]=../lib/yui/2.7.0/build/logger/logger-min.js


[StylesheetSettings]
CSSFileList[]=xrowproductvariation.css
CSSFileList[]=backend.css
CSSFileList[]=../lib/yui/2.7.0/build/calendar/assets/calendar.css
CSSFileList[]=../lib/yui/2.7.0/build/calendar/assets/skins/sam/calendar-skin.css

*/ ?>