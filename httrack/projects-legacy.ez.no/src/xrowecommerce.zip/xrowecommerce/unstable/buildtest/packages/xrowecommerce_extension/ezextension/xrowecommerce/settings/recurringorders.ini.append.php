<?php /* #?ini charset="iso-8859-1"?

[RecurringOrderSettings]
DisabledCycles[]

InstalledCardArray[]
InstalledCardsArray[1]=MasterCard
InstalledCardsArray[2]=Visa
InstalledCardsArray[3]=Amex


*/ ?>