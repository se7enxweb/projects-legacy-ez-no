[Settings]
ShippingGateways[]=UPS
ShippingGateways[]=USPS
ShippingGateways[]=fixedprice

# List of Products that do not have shipping costs
FreeShippingProducts[]
# Switch to enable or disable Handling
HandlingFee=enabled
# Amount added to the cart
HandlingFeeAmount=2.00
# Name displayed
HandlingFeeName=Handling
# Defines if the handling fee should be included or not
HandlingFeeInclude=disabled
FreeShippingitemReduce=9.00

[FixedPrice]
Amount=6