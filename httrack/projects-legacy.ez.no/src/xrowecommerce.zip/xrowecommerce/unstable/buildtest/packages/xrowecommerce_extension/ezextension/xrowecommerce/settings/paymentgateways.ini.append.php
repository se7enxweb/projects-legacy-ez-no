[GatewaysSettings]
AvailableGateways[]=xrowInvoice
AvailableGateways[]=xrowCashOnDelivery
AvailableGateways[]=xrowAdvancepayment