[CouponSettings]
Description=Coupon