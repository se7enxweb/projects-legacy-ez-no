<?php
$Module = array( "name" => "Shipping" );
$FunctionList = array();
$FunctionList['read'] = array();
?>