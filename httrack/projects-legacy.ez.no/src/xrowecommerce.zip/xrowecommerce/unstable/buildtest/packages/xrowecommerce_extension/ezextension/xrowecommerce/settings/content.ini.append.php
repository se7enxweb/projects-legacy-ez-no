<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=xrowecommerce
AvailableDataTypes[]=xrowtin
AvailableDataTypes[]=xrowproductvariation
AvailableDataTypes[]=ezcoupon
AvailableDataTypes[]=ezcreditcard
AvailableDataTypes[]=xrowbillingcycle
AvailableDataTypes[]=ezoption2

*/ ?>