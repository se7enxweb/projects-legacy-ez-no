<?php /* #?ini charset="utf-8"?

[Account]
Userid=mycompany
Password=somepassword
AccessLicenseNumber=0ABCD0ABCD
ShipperNumber=123456

[Connection]
URL=https://www.ups.com/ups.app/xml/Rate
HEADER=0
POST=1
RETURNTRANSFER=1
SSL_VERIFYPEER=false

[Services]
Service_code[]=01:UPS Next Day Air
Service_code[]=02:UPS 2nd Day Air
Service_code[]=03:UPS Ground
Service_code[]=07:UPS Worldwide Express

[ShipperSettings]
City=New York City
Zip=10019
State=NY
Country=US


*/ ?>
