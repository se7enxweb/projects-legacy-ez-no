<?php /* #?ini charset="utf-8"?

[Account]
Userid=1234567890

[Connection]
#URL=http://testing.shippingapis.com/ShippingAPITest.dll
#URL=https://secure.shippingapis.com/ShippingAPITest.dll
URL=http://production.ShippingAPIs.com/ShippingAPI.dll
HEADER=0
POST=1
RETURNTRANSFER=1
SSL_VERIFYPEER=false

[ShipperSettings]
City=New York City
Zip=10019
State=NY
Country=USA

*/ ?>