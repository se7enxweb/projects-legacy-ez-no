<?php
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/rssfeedoperator/autoloads/ezrssfeedoperator.php',
                                    'class' => 'eZRSSFeedOperator',
                                    'operator_names' => array( 'rssfeed' ) );
?>