<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=rssfeedoperator

*/ ?>
