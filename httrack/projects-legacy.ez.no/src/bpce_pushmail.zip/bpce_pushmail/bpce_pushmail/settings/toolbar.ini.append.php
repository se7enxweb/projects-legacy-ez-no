<?php /* #?ini charset="utf-8"?

[Toolbar_admin_right]
Tool[]=admin_bpce_pushmail

*/
?>