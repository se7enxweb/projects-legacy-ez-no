<?php /*

[CustomTemplateSettings]
CustomTemplateList[]=bpce_pushmail

IncludeInView[bpce_pushmail]=full

*/ ?>
