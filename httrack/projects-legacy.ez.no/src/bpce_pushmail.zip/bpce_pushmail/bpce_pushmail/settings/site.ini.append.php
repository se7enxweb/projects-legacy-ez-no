<?php
/*

[RegionalSettings]
TranslationExtensions[]=bpce_pushmail

*/
?>
