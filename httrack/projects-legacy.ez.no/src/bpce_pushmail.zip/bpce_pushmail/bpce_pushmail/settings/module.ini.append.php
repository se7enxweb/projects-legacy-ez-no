<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=bpce_pushmail
ModuleList[]=pushmail

*/ ?>