<?php /* #?ini charset="utf-8"?

[mail]
PageLayout=pagelayout_mail.tpl
UseFullUrl=true

*/ ?>