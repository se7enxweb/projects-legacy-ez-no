<?php /* #?ini charset="utf-8"?

[article_mail]
Source=node/view/mail.tpl
MatchFile=mail/article.tpl
Subdir=templates
Match[class_identifier]=article

[folder_mail]
Source=node/view/mail.tpl
MatchFile=mail/folder.tpl
Subdir=templates
Match[class_identifier]=folder

?>