<?php

class bpce_pushmailInfo
{
    static function info()
    {
        return array( 'Name' => "bpce_pushmail",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) 1999-2009 BPCE",
                      'License' => "GNU General Public License v2.0"
                      );
    }
}
?>
