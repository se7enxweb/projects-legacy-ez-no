[RemotepackagesSettings]
ServerID=Myserver
Repositories[myrepository]=var/storage/packages
Repositories[myrepository2]=var/storage/packages
