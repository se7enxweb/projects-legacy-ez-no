[RepositorySettings]
LocalRepositoryID=myserver
LocalRepositoryPath=extension/xrowsitebuilder/packages
Repositories[]
Repositories[3.9.1]=http://pubsvn.ez.no/packages/ezpublish/php5/3.9/3.9.1
Repositories[3.9.2]=http://pubsvn.ez.no/packages/ezpublish/php5/3.9/3.9.2
Repositories[sitebuilder]=http://sitebuilder.example.com/remotepackages/server