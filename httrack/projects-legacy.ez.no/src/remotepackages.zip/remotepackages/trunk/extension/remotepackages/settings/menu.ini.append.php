<?php /*

[NavigationPart]
Part[ezremotepackagesnavigationpart]=Remotepackages

[TopAdminMenu]
Tabs[]=harmonia

[Topmenu_harmonia]
NavigationPartIdentifier=ezremotepackagesnavigationpart
Name=Remote Packages
Tooltip=Package management add-on
URL[]
URL[default]=remotepackages/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=false

*/ ?>