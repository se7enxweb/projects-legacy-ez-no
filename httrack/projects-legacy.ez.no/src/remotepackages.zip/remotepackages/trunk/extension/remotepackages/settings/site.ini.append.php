[RoleSettings]
PolicyOmitList[]=remotepackages/server