<?php /*

[ExtensionSettings]
DesignExtensions[]=remotepackages

[StylesheetSettings]
CSSFileList[]=remotepackages.css

*/ ?>