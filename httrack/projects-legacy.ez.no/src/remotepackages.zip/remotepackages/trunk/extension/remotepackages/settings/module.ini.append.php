<?php /*

[ModuleSettings]
ExtensionRepositories[]=remotepackages

*/ ?>