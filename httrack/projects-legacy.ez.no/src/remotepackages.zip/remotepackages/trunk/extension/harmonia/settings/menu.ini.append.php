<?php /*

[NavigationPart]
Part[ezharmonianavigationpart]=Harmonia

[TopAdminMenu]
Tabs[]=harmonia

[Topmenu_harmonia]
NavigationPartIdentifier=ezharmonianavigationpart
Name=Harmonia
Tooltip=Harmonia package management add-on
URL[]
URL[default]=harmonia/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=false

*/ ?>