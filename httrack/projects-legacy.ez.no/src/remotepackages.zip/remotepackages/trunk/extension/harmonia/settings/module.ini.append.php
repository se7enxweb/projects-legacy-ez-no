<?php /*

[ModuleSettings]
ExtensionRepositories[]=harmonia
ModuleList[]=harmonia

*/ ?>