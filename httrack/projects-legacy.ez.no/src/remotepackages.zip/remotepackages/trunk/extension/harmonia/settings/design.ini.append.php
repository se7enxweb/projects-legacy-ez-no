<?php /*

[ExtensionSettings]
DesignExtensions[]=harmonia

[StylesheetSettings]
CSSFileList[]=harmonia.css

*/ ?>