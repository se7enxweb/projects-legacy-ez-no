<?php /* #?ini charset="iso-8859-1"?

[EventSettings]
ExtensionDirectories[]=autorss
AvailableEventTypes[]=event_autorss

*/ ?>