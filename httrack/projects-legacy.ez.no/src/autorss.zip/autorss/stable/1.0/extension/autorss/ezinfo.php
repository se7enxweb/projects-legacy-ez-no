<?php

class autorssInfo
{
    function info()
    {
        return array(
            'Name' => '<a href="http://projects.ez.no/autorss">Auto RSS</a>',
            'Version' => "1.x",
            'Copyright' => "Copyright (C) 2007-2008 Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}

?>