<?php /*

[DFPSettings]
#
# Google Publish ID
#
publisherID=ca-pub-0938200828346017

#
# Javascript framework
#
# JSFRamework=mootools
JSFRamework=jQuery

# If one of the following pattern matches the eZGlobalRequestURI, displaying ads will be skipped
#
# The following example will skip ads in all urls beginning with "/Users/..."  
#
#excludePattern[]
#excludePattern[]=/^\/Users./
excludePattern[]

[Styles]
#
# Implements additional styles for the fill-slot's div
# Example:
# Blockview[cssstyleattribute]=value
#

skyscraper[width]=266px
skyscraper[text-align]=center

wide_skyscraper[width]=266px
wide_skyscraper[text-align]=center

square[width]=268px
square[text-align]=center

rectangle_3_1[width]=468px
rectangle_3_1[text-align]=center

medium_rectangle[width]=468px
medium_rectangle[text-align]=center

leaderboard[width]=720px
leaderboard[text-align]=center


*/
?>