<?php /*

[ExtensionSettings]
DesignExtensions[]=all2edfp

[JavaScriptSettings]
JavaScriptList[]=ezjsc::jquery

*/
?>