<?php /* #?ini charset="utf-8"?

[block_all2edfp_square]
Source=block/view/view.tpl
MatchFile=block/all2edfp_square.tpl
Subdir=templates
Match[type]=all2edfp
Match[view]=square

[block_all2edfp]
Source=block/view/view.tpl
MatchFile=block/all2edfp.tpl
Subdir=templates
Match[type]=all2edfp



*/
?>