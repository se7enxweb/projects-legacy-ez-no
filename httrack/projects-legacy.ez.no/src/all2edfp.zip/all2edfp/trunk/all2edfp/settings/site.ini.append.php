<?php /*

[ExtensionSettings]
DesignExtensions[]=all2edfp

[RoleSettings]
PolicyOmitList[]=all2edfp

[TemplateSettings]
ExtensionAutoloadPath[]=all2edfp

*/
?>