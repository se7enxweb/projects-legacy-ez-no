<?php /*

[ExtensionSettings]
DesignExtensions[]=all2edfp

*/
?>
