<?php /*

#[SiteAccessSettings]
#AnonymousAccessList[]=projectexport/export

#[RoleSettings]
#PolicyOmitList=projectexport/export

*/ ?>
