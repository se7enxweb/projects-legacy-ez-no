<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=ezprojects_export
ModuleList[]=projectexport

*/ ?>
