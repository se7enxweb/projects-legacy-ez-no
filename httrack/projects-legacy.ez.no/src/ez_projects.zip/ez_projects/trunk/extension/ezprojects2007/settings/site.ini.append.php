<?php
/*
[TemplateSettings]
ExtensionAutoloadPath[]=ezprojects2007

[MediaClassSettings]
ImageClassID[]=17
*/
?>
