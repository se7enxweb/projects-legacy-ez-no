<?php
/*

[CustomTagSettings]
AvailableCustomTags[]
AvailableCustomTags[]=infobox
AvailableCustomTags[]=partner-button
AvailableCustomTags[]=reference-button
AvailableCustomTags[]=reference-filter
AvailableCustomTags[]=email-address
AvailableCustomTags[]=infobox-header
AvailableCustomTags[]=frontpage-header
AvailableCustomTags[]=community-header
AvailableCustomTags[]=horizontal-line
AvailableCustomTags[]=must-be-logged-in
AvailableCustomTags[]=package
AvailableCustomTags[]=require
IsInline[email-address]=true

[header]
UseStrictHeaderRule=false

[table]
AvailableClasses[]=list

[ul]
AvailableClasses[]=linklist

*/	
?>
