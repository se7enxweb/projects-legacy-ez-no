<?php /*

[ExtensionSettings]
DesignExtensions[]=ezprojects2007

*/
?>
