<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezprojects2007/autoloads/ezprebreakoperator.php',
                                    'class' => 'eZPreBreak',
                                    'operator_names' => array( 'ezprebreak' ) );
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezprojects2007/autoloads/isgithubrepooperator.php',
                                    'class' => 'IsGithubRepo',
                                    'operator_names' => array( 'isgithubrepo' ) );
?>
