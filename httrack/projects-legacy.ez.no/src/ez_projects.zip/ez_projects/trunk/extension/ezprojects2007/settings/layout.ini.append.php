<?php /* #?ini charset="iso-8859-1"?

[printarticle]
PageLayout=printarticle_pagelayout.tpl

*/ ?>