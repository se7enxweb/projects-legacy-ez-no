<?php /* #?ini charset="iso-8859-1"?

[EventSettings]
ExtensionDirectories[]=ezprojects
AvailableEventTypes[]=event_createsvnrepository

*/ ?>