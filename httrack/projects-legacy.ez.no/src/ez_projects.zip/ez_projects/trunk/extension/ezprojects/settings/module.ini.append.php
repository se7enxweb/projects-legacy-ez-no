<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezprojects
ModuleList[]=feeds

*/ ?>
