<?php /* #?ini charset="iso-8859-1"?


[CronjobSettings]
ExtensionDirectories[]=ezprojects

[CronjobPart-htpasswd]
Scripts[]
Scripts[]=htpasswd.php

[CronjobPart-authz]
Scripts[]
Scripts[]=authzsvnaccess.php

[CronjobPart-svnconfigsync]
Scripts[]
Scripts[]=authzsvnaccess.php
Scripts[]=htpasswd.php

[CronjobPart-exportrepositorylist]
Scripts[]
Scripts[]=exportrepositorylist.php

[CronjobPart-importsvnlogs]
Scripts[]
Scripts[]=importsvnlogs.php

[CronjobPart-importgithublogs]
Scripts[]
Scripts[]=importgithublogs.php

*/ ?>
