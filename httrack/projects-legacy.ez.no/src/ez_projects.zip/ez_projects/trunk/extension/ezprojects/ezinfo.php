<?php
class projectsInfo
{
    function info()
    {
        return array(
            'Name' => "Projects",
            'Version' => "0.x",
            'Copyright' => "Copyright (C) 2006-2007 Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>