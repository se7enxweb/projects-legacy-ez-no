<?php
/*
[Class_employee]
# Uncomment those fields that you want included in the vCard and map them to the
# attribute in the class containing the data by appending the attribute identifier
# separated by a colon. You can also "hard-code" the text by putting it in quotes.

# Examples
# Fields[]=FirstName;first_name
# Fields[]=LastName;last_name
# Fields[]=Company;"Netmaking AS"

#Fields[]=FirstName
#Fields[]=MiddleName
#Fields[]=LastName
#Fields[]=EducationTitle
#Fields[]=Addon
#Fields[]=Nickname
#Fields[]=Company
#Fields[]=Organisation
#Fields[]=Department
#Fields[]=JobTitle
#Fields[]=Note
#Fields[]=TelephoneWork1
#Fields[]=TelephoneWork2
#Fields[]=TelephoneHome1
#Fields[]=TelephoneHome2
#Fields[]=Cellphone
#Fields[]=Carphone
#Fields[]=Pager
#Fields[]=AdditionalTelephone
#Fields[]=FaxWork
#Fields[]=FaxHome
#Fields[]=ISDN
#Fields[]=PreferredTelephone
#Fields[]=Telex
#Fields[]=WorkStreet
#Fields[]=WorkZIP
#Fields[]=HomeCity
#Fields[]=HomeRegion
#Fields[]=HomeCountry
#Fields[]=PostalStreet
#Fields[]=PostalZIP
#Fields[]=PostalCity
#Fields[]=PostalRegion
#Fields[]=PostalCountry
#Fields[]=URLWork
#Fields[]=Role
#Fields[]=Birthday
#Fields[]=EMail
*/
?>