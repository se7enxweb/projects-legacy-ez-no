<?php
/*
[ModuleSettings]
ExtensionRepositories[]=nmvcard
*/
?>