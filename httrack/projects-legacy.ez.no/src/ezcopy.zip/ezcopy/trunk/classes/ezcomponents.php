<?php

require_once "ezc/Base/base.php";

function __autoload( $className )
{
    ezcBase::autoload( $className );
}


?>