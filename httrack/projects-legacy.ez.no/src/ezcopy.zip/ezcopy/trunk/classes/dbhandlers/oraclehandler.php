<?php

class oraclehandler extends dbhandler
{
	
}