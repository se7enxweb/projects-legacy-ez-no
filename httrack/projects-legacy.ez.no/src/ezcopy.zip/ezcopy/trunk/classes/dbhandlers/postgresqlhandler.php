<?php

class postgresqlhandler extends dbhandler
{
	
}