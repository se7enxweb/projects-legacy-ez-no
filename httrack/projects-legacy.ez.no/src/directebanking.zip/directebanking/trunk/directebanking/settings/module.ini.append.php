<?php /*

[ModuleSettings]
ExtensionRepositories[]=directebanking

ModuleList[]=directebanking

*/ ?>
