<?php /* #?ini charset="utf-8"?
[GeneralSettings]
EnableSOAP=true

[ExtensionSettings]
SOAPExtensions[]=ezsvn
*/ ?>