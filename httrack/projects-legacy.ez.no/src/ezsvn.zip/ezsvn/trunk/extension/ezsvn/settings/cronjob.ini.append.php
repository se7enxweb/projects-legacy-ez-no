<?php /* #?ini charset="utf-8"?
[CronjobSettings]
ScriptDirectories[]=extension/ezsvn/bin

[CronjobPart-ezsvn]
Scripts[]=ezsvn.php
*/ ?>