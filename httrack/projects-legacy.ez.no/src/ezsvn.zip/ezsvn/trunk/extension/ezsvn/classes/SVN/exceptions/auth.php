<?php
class xrowSVNAuthException extends xrowSVNException {}
?>