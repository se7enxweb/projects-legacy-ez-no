<?php /* #?ini charset="utf-8"?
[SiteAccessSettings]
AnonymousAccessList[]=svn/configserver

[RoleSettings]
PolicyOmitList[]=svn/configserver


[BackwardCompatibilitySettings]
AdvancedObjectRelationList=enabled
*/ ?>