<?php /* #?ini charset="utf-8"?

[string_svncomposition_base_edit]
Source=content/datatype/edit/ezstring.tpl
MatchFile=ezstring.tpl
Subdir=templates
Match[class_identifier]=svncomposition
Match[attribute_identifier]=base

[string_svnitem_password_edit]
Source=content/datatype/edit/ezstring.tpl
MatchFile=ezstring_password.tpl
Subdir=templates
Match[class_identifier]=svnitem
Match[attribute_identifier]=password

*/ ?>