<?php /* #?ini charset="utf-8"?
[Settings]
RsyncExecutable=rsync
MysqldumpExecutable=mysqldump
MysqlExecutable=mysql
# Stops if a system call had a return status other then 0
StopOnError=false
#DefaultMirror=Example

#[Mirror-Example]
#RemoteUser=admin
#RemoteServer=example.com
#RemoteEZPublishRoot=/path/to/ezpublish
#PrivateKey=/path/to/my.key
#ReportEmailList[]=test@example.com
#RemoteDatabaseName=nextgen
#RemoteDatabaseUser=admin
#RemoteDatabasePassword=publish
#RemoteDatabaseHost=example.com
*/ ?>
