<?php

$server->registerObject( 
    'eZSOAPsvn', 
    'extension/ezsvn/classes/ezsoapsvn.php' );

?>