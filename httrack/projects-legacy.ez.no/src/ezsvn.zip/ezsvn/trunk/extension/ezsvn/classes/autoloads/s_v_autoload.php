<?php
return array (
	'xrowSVN' => 'SVN/xrowsvn.php',
	'xrowSVNRecursiveDirectoryIterator' => 'SVN/xrowsvnrecursivedirectoryiterator.php',
	'xrowSVNWorkingCopy' => 'SVN/xrowsvnworkingcopy.php',
    'xrowSVNException' => 'SVN/exceptions/common.php',
	'xrowSVNUpdateException' => 'SVN/exceptions/update.php',
    'xrowSVNDifferentPathException' => 'SVN/exceptions/differentpath.php',
	'xrowSVNLockException' => 'SVN/exceptions/lock.php',
	'xrowSVNAuthException' => 'SVN/exceptions/auth.php'
);
?>
