<?php /*  

[Toolbar_admin_right]
Tool[]=admin_qcgears

*/ ?>