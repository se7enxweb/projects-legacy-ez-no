<?php /*

[ExtensionSettings]
DesignExtensions[]=qcgears

[JavaScriptSettings]
JavaScriptList[]=gears_init.js
JavaScriptList[]=qcgears.js

*/ ?>