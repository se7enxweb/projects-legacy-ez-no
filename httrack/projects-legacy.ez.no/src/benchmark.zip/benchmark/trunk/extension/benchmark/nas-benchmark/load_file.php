<?php
$content = file_get_contents( 'testfile.txt' );
?>
