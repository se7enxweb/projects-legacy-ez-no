<?php /* #?ini charset="iso-8859-1"?

[NavigationPart]
Part[ezloremipsumpart]=Lorem Ipsum

[TopAdminMenu]
Tabs[]=lorem_ipsum

[Topmenu_lorem_ipsum]
NavigationPartIdentifier=ezloremipsumpart
Name=Lorem Ipsum
Tooltip=Generator of the random content
URL[]
URL[default]=lorem/ipsum
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>