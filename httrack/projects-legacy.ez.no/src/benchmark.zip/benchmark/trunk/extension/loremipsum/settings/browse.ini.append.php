<?php /* #?ini charset="iso-8859-1"?

[LoremIpsumAddNode]
StartNode=content
SelectionType=multiple
ReturnType=NodeID

*/ ?>