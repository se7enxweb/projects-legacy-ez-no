<?php
class cddbInfo
{
    function info()
    {
        return array(
            'Name' => "CDDB",
            'Version' => "0.x",
            'Copyright' => "Copyright (C) 2006 Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>