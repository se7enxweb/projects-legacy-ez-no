<?php /*

[NavigationPart]
Part[instagramnavigationpart]=instagram

[TopAdminMenu]
Tabs[]=instagram

[Topmenu_instagram]
NavigationPartIdentifier=instagramnavigationpart
Name=instagram
Tooltip=instagram dashboard
URL[]
URL[default]=ig/connected_users
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
# We don't show it in browse mode
Shown[browse]=true
PolicyList[]=ig/connected_users

*/ ?>
