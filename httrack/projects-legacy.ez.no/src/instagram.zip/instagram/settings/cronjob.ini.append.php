<?php /*

[CronjobSettings]
ExtensionDirectories[]=instagram

[CronjobPart-frequent]
Scripts[]=importImagesFromRemote.php
#Scripts[]=setDefaultTags.php

[CronjobPart-importImagesFromRemote]
Scripts[]
Scripts[]=importImagesFromRemote.php


[CronjobPart-setDefaultTags]
Scripts[]
Scripts[]=setDefaultTags.php


*/ ?>
