<?php /* #?ini charset="utf-8"?

#[TemplateSettings]
#ExtensionAutoloadPath[]=instagram

[RoleSettings]
PolicyOmitList[]=ig/save
PolicyOmitList[]=ig/open
PolicyOmitList[]=ig/view
 
[Cache]
CacheItems[]=ig

[Cache_ig]
name=Instagram Push authorization cache
id=ig
path=ig

[RegionalSettings]
TranslationExtensions[]=instagram

*/ ?>
