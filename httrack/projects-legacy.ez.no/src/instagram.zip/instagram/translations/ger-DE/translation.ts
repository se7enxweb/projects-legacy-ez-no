<!DOCTYPE TS><TS>
<context>
	<name>extension/instagram</name>
	<message>
		<source>instagram</source>
		<translation>instagram</translation>
	</message>
	<message>
		<source>Connected users</source>
		<translation>Verbundene Benutzer</translation>
	</message>
	<message>
		<source>Connect now!</source>
		<translation>Jetzt verbinden!</translation>
	</message>
	<message>
		<source>IG ID</source>
		<translation>IG ID</translation>
	</message>
	<message>
		<source>IG Username</source>
		<translation>IG Benutzername</translation>
	</message>
	<message>
		<source>IG Full Name</source>
		<translation>IG voller Name</translation>
	</message>
	<message>
		<source>Photos</source>
		<translation>Fotos</translation>
	</message>
	<message>
		<source>Synchronised Photos</source>
		<translation>Synchronisierte Fotos</translation>
	</message>
	<message>
		<source>Followed by</source>
		<translation>Anhänger</translation>
	</message>
	<message>
		<source>Follows</source>
		<translation>folge ich</translation>
	</message>
	<message>
		<source>No users are connected at the moment!</source>
		<translation>Bislang wurden noch keine Benutzer verbunden!</translation>
	</message>
	<message>
		<source>No images found!</source>
		<translation>Keine Bilder gefunden!</translation>
	</message>

</context>
</TS>