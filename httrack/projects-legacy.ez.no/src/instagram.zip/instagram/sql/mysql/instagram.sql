
CREATE TABLE IF NOT EXISTS `ezig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accessToken` varchar(255) NOT NULL,
  `ig_username` varchar(255) NOT NULL,
  `ig_profile_picture` varchar(255) NOT NULL,
  `ig_full_name` varchar(255) NOT NULL,
  `ig_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `ezig_photos` (
  `created_time` int(11) NOT NULL,
  `link` varchar(255) NOT NULL,
  `likes_count` int(11) NOT NULL,
  `images` text NOT NULL,
  `id` varchar(255) NOT NULL,
  `caption` varchar(255) NOT NULL,
  `tags` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `contentobject_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

