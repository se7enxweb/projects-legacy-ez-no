<?php

$Module = array( 'name' => 'ig' );

$ViewList = array();
/*
 * display the selected users feed (of synchronised photos)
 */
$ViewList['feed'] = array(
	"functions"=>array('read'), 
	'script'	=> 'feed.php',
    'default_navigation_part' => 'instagramnavigationpart',
	'params'	=> array( 'UserID' ),
    'unordered_params' => array( 'offset' => 'Offset' )
);
/*
 * 'connect_user' handels the callback from the instagram api
 * it stores the auth token and other user specific data to the database
 */
$ViewList['connect_user'] = array(
	"functions"=>array('read'), 
    'default_navigation_part' => 'instagramnavigationpart',
	'script'	=> 'connect_user.php'
);
/*
 * list all connected users and some basic information 
 */
$ViewList['connected_users'] = array(
	"functions"=>array('read'), 
    'default_navigation_part' => 'instagramnavigationpart',
	'script'	=> 'connected_users.php'
);

$FunctionList = array();
$FunctionList['read'] = array();

?>
