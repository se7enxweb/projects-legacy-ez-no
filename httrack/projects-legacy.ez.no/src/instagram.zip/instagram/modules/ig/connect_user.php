<?php

$http = eZHTTPTool::instance();

$Module	= $Params['Module'];

$IGIni = eZINI::instance( 'instagram.ini' );

$config = array(
        'client_id' => $IGIni->variable( 'instagram', 'ClientId' ),
        'client_secret' => $IGIni->variable( 'instagram', 'ClientSecret' ),
        'grant_type' => 'authorization_code',
        'redirect_uri' => $IGIni->variable( 'instagram', 'RedirectURI' )
     );
// Instantiate the API handler object
$instagram = new Instagram($config);

$accessToken = $instagram->getAccessToken();
if( $accessToken == '' )
{
	$scope = $IGIni->variable( 'instagram', 'IGscope' );
	$instagram->openAuthorizationUrl( $scope );	
	eZExecution::cleanExit();
}	
	
$igUser = eZIG::fetch( $instagram->getCurrentUser()->id );
if( !is_object( $igUser ) )
{
	$igUser = new eZIG();
}
$igUser->setAttribute('accessToken', $accessToken );
$igUser->setAttribute('ig_id', $instagram->getCurrentUser()->id );
$igUser->setAttribute('ig_username', $instagram->getCurrentUser()->username );
$igUser->setAttribute('ig_profile_picture', $instagram->getCurrentUser()->profile_picture );
$igUser->setAttribute('ig_full_name', $instagram->getCurrentUser()->full_name );
$igUser->store();


$Module->redirectTo( "/ig/connected_users" );
return;
