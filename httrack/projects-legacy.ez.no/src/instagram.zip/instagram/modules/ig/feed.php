<?php

$http = eZHTTPTool::instance();
$http = eZHTTPTool::instance();
$tpl = eZTemplate::factory();

$Module	= $Params['Module'];
$userID = $Params['UserID'];
$offset = $Params['Offset'];

if( eZPreferences::value( 'admin_ig_feed_list_limit' ) )
{
    switch( eZPreferences::value( 'admin_ig_feed_list_limit' ) )
    {
        case '2': { $limit = 25; } break;
        case '3': { $limit = 50; } break;
        default:  { $limit = 10; } break;
    }
}
else
{
    $limit = 10;
}



$photoCount = eZIGPhotos::fetchCountByUser( $userID );
$photoArray = eZIGPhotos::fetchAllByUser( $userID, $offset, $limit );

$tpl->setVariable( 'object_array', $photoArray );
$tpl->setVariable( 'object_count', $photoCount );
$tpl->setVariable( 'number_of_items', $limit );


$Result = array();
$Result['left_menu'] = "design:ig/backoffice_left_menu.tpl";
$Result['content'] = $tpl->fetch( 'design:ig/feed.tpl' );
$Result['path'] = array( array( 'text' => 'Instagram',
                                'url' => false ),
						 array( 'text' => 'Feed',
                                'url' => false ) );

return $Result;

