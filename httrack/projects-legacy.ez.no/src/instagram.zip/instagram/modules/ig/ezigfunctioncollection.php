<?php

class eZIGFunctionCollection 
{
    function eZIGFunctionCollection( $accessToken = false )
    {
		$IGIni = eZINI::instance( 'instagram.ini' );
		
		$this->config = array(
	        'client_id' => $IGIni->variable( 'instagram', 'ClientId' ),
	        'client_secret' => $IGIni->variable( 'instagram', 'ClientSecret' ),
	        'grant_type' => 'authorization_code',
	        'redirect_uri' => $IGIni->variable( 'instagram', 'RedirectURI' )
	    );
	    if( $accessToken == false )
	    {
			$tokenArray = eZIG::fetchAll( );
			if( count( $tokenArray ) > 0 )
			{
				$this->accessToken = $tokenArray[0]->attribute('accessToken');
			}
	    }
	    else
	    	$this->accessToken = $accessToken; 
	    
		$instagram = new Instagram($this->config);
		$instagram->setAccessToken( '2251420.e284bb1.beed6dbf617f47b888df4a4943dec32a' );
		
		$this->ig = $instagram;
	}
    
	static function fetchUser( $userID = null )
	{
		$return = false;
		if( $userID != null )
		{
			$igFunctions = new eZIGFunctionCollection();
			$userInfo = json_decode( $igFunctions->ig->getUser( $userID ) );
			$return = array( 'counts_media' => $userInfo->data->counts->media, 'counts_followed_by' => $userInfo->data->counts->followed_by, 'counts_follows' => $userInfo->data->counts->follows);
		}
		
		return array( 'result' => $return );
	}	
	
	static function fetchAllImages( $userID = null )
	{
		$return = false;
		if( $userID == null )
		{
			$tmpArray = eZIG::fetchAll( false );
			foreach( $tmpArray as $item )
			{
				$userArray[ $item['ig_id'] ] = $item['accessToken'];
			}
		}
		else
		{
			$userArray = array( $userID );
		}

		
		if( count( $userArray )  )
		{
			$db = eZDB::instance();
			foreach( $userArray as $userID => $accessToken )
			{
				$igFunctions = new eZIGFunctionCollection( $accessToken );
				

				$ts = time();
				$i=0;
				
				echo "\n\nImporting images for: " .$userID."\n";
				$db->query( 'update ezig_photos set created_time='.time().' where user_id=' .$userID );

				while( true )
				{
					// get the latest entry in our db for this user and fetch the next entries from ig 
					$res = $db->arrayQuery( 'SELECT min(created_time) as ts FROM ezig_photos where user_id=' .$userID );

					// if the user hasn't been imported yet, we start with ts=0
					$ts = ( $res[0]['ts'] > 0 ) ? ($res[0]['ts']-1) : 0;
					$i++;
					$images = $igFunctions->ig->getUserRecent( $userID, '', '', $ts  );
					
					$res = json_decode($images, true);
					
					
					if( count( $res['data'] ) == 0 )
						break;
					else 
					{
						foreach ($res['data'] as $data) 
					    {
							$igPhoto = eZIGPhotos::fetch( $data['id'] );
							if( !is_object( $igPhoto ) )
							{
								$igPhoto = new eZIGPhotos();
							}
							$igPhoto->setAttribute('created_time', $data['created_time'] );
							$igPhoto->setAttribute('link', $data['link'] );
							$igPhoto->setAttribute('likes_count', $data['likes']['count'] );
							$igPhoto->setAttribute('images', serialize( $data['images'] ) );
							$igPhoto->setAttribute('id', $data['id'] );
							$igPhoto->setAttribute('caption', $data['caption']['text'] );
							 
							$igPhoto->setAttribute('tags',  ( count( $data['tags'] ) ? " #".implode( " #", $data['tags'] ) : "" ) );
							$igPhoto->setAttribute('user_id', $data['user']['id'] );
							$igPhoto->store();
							
							// echo $data['id'] ."\n";
					    }
					}
					// return;
				}
			}
			$return = array( );
		}
		
		return array( 'result' => $return );
	}	


	static function fetchAllLocalPhotosByUser( $userID = null, $offset = 0, $limit = 10, $asObject = true )
	{
		$return = false;
		if( $userID != null )
		{
			$count = eZIGPhotos::fetchCountByUser( $userID );
			echo $count;
			
			$return = eZIGPhotos::fetchAllByUser( $userID, $offset, $limit, $asObject );
		}
		
		return array( 'result' => $return );
	}	
	
	static function fetchCountPhotosByUser( $userID = null )
	{
		$return = false;
		if( $userID != null )
		{
			$return = eZIGPhotos::fetchCountByUser( $userID );
		}
		
		return array( 'result' => $return );
	}	
	
	
	
	
	protected $config; 
	protected $accessToken; 
	protected $ig; 
}

?>