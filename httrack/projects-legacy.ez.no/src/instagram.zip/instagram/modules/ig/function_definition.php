<?php


$FunctionList = array();

$FunctionList['user'] = array( 'name' => 'user',
                                 'operation_types' => 'read',
                                 'call_method' => array( 
                                 						 'class' => 'eZIGFunctionCollection',
                                                         'method' => 'fetchUser' ),
                                 'parameter_type' => 'standard',
                                 'parameters' => array( array( 'name' => 'user_id',
                                                               'type' => 'integer',
                                                               'required' => true ) ) );
															   
$FunctionList['local_photos'] = array( 'name' => 'local_photos',
                                 'operation_types' => 'read',
                                 'call_method' => array( 
                                 						 'class' => 'eZIGFunctionCollection',
                                                         'method' => 'fetchAllLocalPhotosByUser' ),
                                 'parameter_type' => 'standard',
                                 'parameters' => array( array( 'name' => 'user_id',
                                                               'type' => 'integer',
                                                               'required' => true ),
                                                        array( 'name' => 'offset',
                                                               'type' => 'integer',
                                                               'required' => false ),
                                                        array( 'name' => 'limit',
                                                               'type' => 'integer',
                                                               'required' => false ),
                                                        array( 'name' => 'as_object',
                                                               'type' => 'boolean',
                                                               'required' => false,
                                                               'default' => true )
                                                                ) );
															   
$FunctionList['local_photos_count'] = array( 'name' => 'local_photos',
                                 'operation_types' => 'read',
                                 'call_method' => array( 
                                 						 'class' => 'eZIGFunctionCollection',
                                                         'method' => 'fetchCountPhotosByUser' ),
                                 'parameter_type' => 'standard',
                                 'parameters' => array( array( 'name' => 'user_id',
                                                               'type' => 'integer',
                                                               'required' => true )
                                                                ) );
                                                                																
															   
															   
?>
