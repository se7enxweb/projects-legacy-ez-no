<?php

$cli->output( 'Instagram set default tags STARTED');

$IGIni = eZINI::instance( 'instagram.ini' );

$importUserID =  $IGIni->variable( 'ImportSettings', 'ImportUserID' );

$user = eZUser::fetch( $importUserID );

$db = eZDB::instance();

eZIGFunctionCollection::fetchAllImages( );

$allImageArray = eZIGPhotos::fetchAll();
 
$config = array(
    'client_id' => $IGIni->variable( 'instagram', 'ClientId' ),
    'client_secret' => $IGIni->variable( 'instagram', 'ClientSecret' ),
    'grant_type' => 'authorization_code',
    'redirect_uri' => $IGIni->variable( 'instagram', 'RedirectURI' )
);
$tokenArray = eZIG::fetchAll( );
if( count( $tokenArray ) > 0 )
{
	foreach( $tokenArray as $item )
	{
		$userArray[ $item->attribute('ig_id') ] = $item->attribute('accessToken');
	}

}
else
	return;

$defaultTagsArray = $IGIni->variable( 'DefaultTagsSettings', 'DefaultTags' );
$setLikesArray = $IGIni->variable( 'DefaultTagsSettings', 'LikesArray' );

$totalLikes = 0;
//Looping through all the collected images.
foreach( $allImageArray as $image )
{
	
	$instagram = new Instagram($config);
	$instagram->setAccessToken( $userArray[ $image->attribute('user_id')] );
	
	$tagCount = count( explode( " #", $image->attribute('tags') ) );

	$newTags = array();
	shuffle( $defaultTagsArray );
	foreach( $defaultTagsArray as $tag )
	{
		if( !strstr( $image->attribute('tags'), $tag) )
			$newTags[] = ' #'.$tag;
		if( ( count( $newTags ) + $tagCount ) > 29 )
			break;
	}
	$totalLikes = $totalLikes + $image->attribute('likes_count');
	$imageLikes = 5 * ( floor( $image->attribute('likes_count') / 5 ) );
	for( $i=$imageLikes;  $i > 0; $i-- )
	{
		if( in_array( $i, $setLikesArray ) )
		{ 
			$tag = $i."likes";
			if( !strstr( $image->attribute('tags'), $tag) )
				$newTags[] = ' #'.$tag;
			if( ( count( $newTags ) + $tagCount ) > 29 )
				break;
		}
		
	}
	if( count( $newTags ) )
		$ret = $instagram->postMediaComment( $image->attribute('id'), implode("",$newTags) );

}

$cli->notice("Overall likes received: ".$totalLikes);
$cli->notice("Instagram set default tags FINISHED");

?>