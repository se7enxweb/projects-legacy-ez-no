<?php
/*
 * When running the cronjob instagrams photo information will be stored locally in the ezpublish database
 * In a second step the images are fetched and the corresponding image contentobject_id is stored to the eZIGPhoto 
 */
class eZIGPhotos extends eZPersistentObject
{
	function eZIGPhotos( $row )
	{
		$this->PersistentDataDirty = false;
		if ( is_numeric( $row ) )
		$row = $this->fetch( $row, false );
		$this->fill( $row );
	}
 
	static function definition()
	{
		return array ("fields" => array (
			"created_time" => array ('name' => 'created_time', 'datatype' => 'integer', 'default' => 0, 'required' => true ),
			"link" => array ('name' => "link", 'datatype' => 'string', 'default' => '', 'required' => true ),
			"likes_count" => array ('name' => "likes_count", 'datatype' => 'int', 'default' => 0, 'required' => true ),
			"images" => array ('name' => "images", 'datatype' => 'text', 'default' => '', 'required' => true ),
			"id" => array ('name' => "id", 'datatype' => 'string', 'default' => '', 'required' => true ),
			"caption" => array ('name' => "caption", 'datatype' => 'string', 'default' => '', 'required' => false ),		
			"tags" => array ('name' => "tags", 'datatype' => 'text', 'default' => '', 'required' => false ),		
			"user_id" => array ('name' => "user_id", 'datatype' => 'integer', 'default' => 0, 'required' => true ), 
			"contentobject_id" => array (
									'name' => "contentobject_id", 
									'datatype' => 'integer', 
									'default' => '0', 
									'required' => false,
                                    'foreign_class' => 'eZContentObject',
                                    'foreign_attribute' => 'id',
									'multiplicity' => '1..*'
									)		
		),
		'function_attributes' => array( 'contentobject' => 'contentObject' ),
		
		"keys" => array( "id" ),
		"class_name" => "eZIGPhotos",
		"name" => "ezig_photos" );
	}
	static function fetch( $id, $asObject = true )
	{
		return eZPersistentObject::fetchObject( eZIGPhotos::definition(),
		null,
		array( "id" => $id ),
		$asObject );
	}


	static function fetchAll(  $asObject = true )
    {
        return eZPersistentObject::fetchObjectList( eZIGPhotos::definition(),
                                                    null,
                                                    null,
                                                    array( "created_time" => "desc" ), null,
                                                    $asObject );
		
	
    }	
    

	static function fetchAllUnimported(  $asObject = true )
    {
        return eZPersistentObject::fetchObjectList( eZIGPhotos::definition(),
                                                    null,
                                                    array("contentobject_id" => array( '=', 0 ) ),
                                                    array( "created_time" => "desc" ), null,
                                                    $asObject );
		
	
    }	

	static function fetchAllByLikes(  $asObject = true )
    {
        return eZPersistentObject::fetchObjectList( eZIGPhotos::definition(),
                                                    null,
                                                    null,
                                                    array( "likes_count" => "asc" ), null,
                                                    $asObject );
		
	
    }	
    
	static function fetchAllByUser( $userID = null, $offset = 0, $limit = 10, $asObject = true )
    {
    	if( $userID != NULL )
        	return eZPersistentObject::fetchObjectList( eZIGPhotos::definition(),
                                                    null,
                                                    array( "user_id" => $userID ),
                                                    array( "created_time" => "desc" ), 
                                                    array( 'offset' => $offset,
                                                           'length' => $limit ),
                                                    $asObject );
		
	
    }
	
	    
	static function fetchCountByUser( $userID = null )
    {
    	if( $userID != NULL )
        	return eZPersistentObject::count( eZIGPhotos::definition(), array( "user_id" => $userID ) );
		
		return false;		
	
    }	
	
    
	function contentObject()
	{
		if ( isset( $this->contentobject_id ) and $this->contentobject_id )
		{
			return eZContentObject::fetch( $this->contentobject_id );
		}
		//return 0;
	}
    
}
