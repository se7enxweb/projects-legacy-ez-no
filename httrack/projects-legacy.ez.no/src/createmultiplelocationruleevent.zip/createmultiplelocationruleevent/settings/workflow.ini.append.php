<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=createmultiplelocationruleevent
AvailableEventTypes[]=event_createmultiplelocationrule

*/ ?>