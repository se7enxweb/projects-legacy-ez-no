<?php /*

# Here you can define new locations (parent node IDs) for content classes (content class ID as array key).
# LocationsArray[2]=44;102;19;145 - add 4 additional locations for published articles where parent node id is 44, 102, 19 and 145.
# Note: parent class must have is_container flag set to true.

[LocationsSettings]
# chaines
LocationsArray[42]=7317;7319;7321;7324
# themes
LocationsArray[48]=7318;7320;7323;7325

*/ ?>