<?php /*

[InformationSettings]
ContenClassID[]
ContentClassID[]=2
ContentClassID[]=13

# If not set, admin e-mail from site.ini will be use as default setting.
[MailSettings]
EmailReceiver=
# Separate email and name with semi column
# Example:
# EmailCc[]
# EmailCc[]=example@example.com;Example
EmailCc[]
EmailBcc[]
EmailSender=

*/ ?>
