<?php /*

[EventSettings]
ExtensionDirectories[]=ezinformation
AvailableEventTypes[]=event_ezinformation

*/ ?>