<?php
class ezinformationInfo
{
    public static function info()
    {
        return array( 'Name' => 'eZ Information',
                      'Version' => '1.1.0',
                      'Copyright' => 'Copyright (C) ' . date( 'Y' ) . ' Łukasz Serwatka',
                      'License' => 'GNU General Public License v2.0'
                     );
    }
}
?>