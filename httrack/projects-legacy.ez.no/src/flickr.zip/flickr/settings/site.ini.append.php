<?php

[TemplateSettings]
ExtensionAutoloadPath[]=flickr

?>