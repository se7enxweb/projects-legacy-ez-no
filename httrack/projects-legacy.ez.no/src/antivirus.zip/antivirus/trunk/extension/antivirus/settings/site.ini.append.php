<?php /*

[RegionalSettings]
TranslationExtensions[]=antivirus

*/ ?>