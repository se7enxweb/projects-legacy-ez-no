<?php /*

[EventSettings]
ExtensionDirectories[]=antivirus
AvailableEventTypes[]=event_antivirus

*/ ?>
