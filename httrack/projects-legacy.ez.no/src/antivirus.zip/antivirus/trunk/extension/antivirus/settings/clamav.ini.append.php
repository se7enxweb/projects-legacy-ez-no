[ClamAVSettings]
Host=localhost
Port=3310
#Disable for more security. If the Deamon is not reachable,
# it will act as if no virus has been found.
ContinueOnError=enabled