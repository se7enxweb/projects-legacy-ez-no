<?php
class antivirusInfo
{
    /*!
     Constructor
    */
    function info()
    {
        return array( 'name' => 'Anti virus',
                      'version' => '2.0',
                      'copyright' => 'Copyright © 2007 xrow GbR',
                      'info_url' => 'http://projects.ez.no/antivirus',
                      'license' => 'GPL version 2' );
    }
}
?>