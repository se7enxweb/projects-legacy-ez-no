[ErrorSettings-kernel]
HTTPError[409]=409

[HTTPError-409]
HTTPName=File not found or removed by virus scanner