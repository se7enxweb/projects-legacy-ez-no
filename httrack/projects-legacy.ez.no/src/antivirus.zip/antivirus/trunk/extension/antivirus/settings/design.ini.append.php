<?php /*

[ExtensionSettings]
DesignExtensions[]=antivirus

*/ ?>