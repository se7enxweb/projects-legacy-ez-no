[BinaryFileSettings]
ExtensionRepositories[]=antivirus
# Enable if you want to virus protect your downloads
#Handler=ezavfilepasstrough