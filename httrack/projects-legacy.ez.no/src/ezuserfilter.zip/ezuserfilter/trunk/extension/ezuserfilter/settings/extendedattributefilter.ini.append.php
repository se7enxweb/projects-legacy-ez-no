<?php /*

[EnabledUserFilter]
ExtensionName=ezuserfilter
ClassName=eZUserExtendedAttributeFilter
MethodName=createEnabledSqlParts
FileName=classes/ezuserextendedattributefilter.php

[DisabledUserFilter]
ExtensionName=ezuserfilter
ClassName=eZUserExtendedAttributeFilter
MethodName=createDisabledSqlParts
FileName=classes/ezuserextendedattributefilter.php

*/ ?>