<?php

class ezlightboxInfo
{
    static function info()
    {
        return array( 'Name'      => "eZ Publish lightbox",
                      'Version'   => "0.7.3",
                      'Copyright' => "Copyright (C) 1999-2008 eZ Systems AS",
                      'License'   => "GNU General Public License v2.0"
                    );
    }
}

?>
