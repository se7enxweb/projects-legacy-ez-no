<?php /*

[CommonSettings]
UserSendOwnLightbox=enabled
UseShop=disabled

[LightboxItemSettings]
AvailableItemList[]
AvailableItemList[]=eZContentObject
AvailableItemList[]=eZContentNode

*/ ?>
