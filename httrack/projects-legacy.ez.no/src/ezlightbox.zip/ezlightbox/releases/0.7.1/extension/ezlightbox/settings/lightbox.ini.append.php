<?php /*

[CommonSettings]
UserSendOwnLightbox=enabled
UseShop=disabled

*/ ?>
