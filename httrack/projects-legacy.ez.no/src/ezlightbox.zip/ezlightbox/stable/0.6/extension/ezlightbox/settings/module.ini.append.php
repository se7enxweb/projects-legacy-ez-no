<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezlightbox

*/ ?>
