<?php /*

[CommonSettings]
UserSendOwnLightbox=enabled

*/ ?>
