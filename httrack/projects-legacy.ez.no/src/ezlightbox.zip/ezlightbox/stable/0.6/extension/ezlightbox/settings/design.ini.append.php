<?php /*

[ExtensionSettings]
DesignExtensions[]=ezlightbox

#[StylesheetSettings]
#CSSFileList[]=ezlightbox.css

[JavaScriptSettings]
JavaScriptList[]=lightbox.js

*/ ?>
