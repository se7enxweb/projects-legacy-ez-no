<?php /*

[ExtensionSettings]
DesignExtensions[]=ezlightbox

[StylesheetSettings]
CSSFileList[]=lightbox.css

[JavaScriptSettings]
JavaScriptList[]=lightbox.js

*/ ?>
