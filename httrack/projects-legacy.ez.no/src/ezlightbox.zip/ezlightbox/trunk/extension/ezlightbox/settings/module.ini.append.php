<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezlightbox
ModuleList[]=lightbox

*/ ?>
