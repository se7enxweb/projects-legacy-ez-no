<?php /*

[CronjobSettings]
ExtensionDirectories[]=ezlightbox

[CronjobPart-lightboxcleanup]
Scripts[]
Scripts[]=lightboxcleanup.php

*/ ?>
