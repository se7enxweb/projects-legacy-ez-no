<?php /*

[OperationSettings]
AvailableOperationList[]=lightbox_create
AvailableOperationList[]=lightbox_delete
AvailableOperationList[]=lightbox_add
AvailableOperationList[]=lightbox_remove
AvailableOperationList[]=lightbox_move
AvailableOperationList[]=lightbox_send
AvailableOperationList[]=lightbox_remove_users

*/ ?>
