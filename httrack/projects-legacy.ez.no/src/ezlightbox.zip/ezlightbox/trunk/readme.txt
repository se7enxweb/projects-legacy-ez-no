This repository is not yet officially in use, as migration from current one needs some careful planning.
Please do not commit here.

Stay tuned for the official opening.

gg@ez.no - 2009/11/3
