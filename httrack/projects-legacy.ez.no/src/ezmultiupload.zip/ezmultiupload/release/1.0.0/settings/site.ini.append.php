<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezmultiupload

[RegionalSettings]
TranslationExtensions[]=ezmultiupload

*/ ?>
