<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Aloittaa...</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Kaikki tiedostot vastaanotettu.</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>Flash-sisällön lataus epäonnistui. Voit asentaa viimeisimmän versoin Flash Playeristä osoitteesta</translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Adobe Flash Playerin Latauskeskus</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Tiedostot on ladattu osoitteeseen</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Valitse tiedostot</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Esikatselukuva luotu.</translation>
    </message>
    <message>
        <source>Multiupload</source>
        <translation>Monilataus</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
