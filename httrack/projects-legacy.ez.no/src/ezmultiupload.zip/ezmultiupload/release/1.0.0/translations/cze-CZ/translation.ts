<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Multiupload</source>
        <translation>Hromadná nahrávka</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Soubory jsou nahrány do</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Vybrat soubory</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>Není možné nahrát obsah Flash. Můžete nahrát poslední verzi Flash Player z </translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Adobe Flash Player Download Center</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Všechny soubory přijaty.</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Miniatura vytvořena.</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Spouští se...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
