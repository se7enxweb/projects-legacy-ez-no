<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Multiupload</source>
        <translation>Multiupload</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Els arxius s&apos;han penjat a</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Selecciona els fitxers</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>No es pot carregar el contingut Flash. Pot descarregar l&apos;última versió del Flash Player a</translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Centre de descàrregues d&apos;Adobe Flash Player</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>S&apos;han rebut tots els arxius.</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>S&apos;ha creat el thumbnail (imatge en miniatura).</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Iniciant...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>