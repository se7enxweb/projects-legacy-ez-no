<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Starter...</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Alle modtagne filer.</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>Kunne ikke hente Flash-indhold. Du kan downloade den seneste version af Flash Player fra </translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Adobe Flash Player Download Center</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Filerne er uploadet til</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Vælg filer</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Thumbnail er oprettet.</translation>
    </message>
    <message>
        <source>Multiupload</source>
        <translation>Multiupload</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/popupmenu</name>
    <message>
        <source>Upload multiple files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
