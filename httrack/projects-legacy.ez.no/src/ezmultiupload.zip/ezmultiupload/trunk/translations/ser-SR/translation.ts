<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Error</source>
        <translation>Greška</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Početni...</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Primljene su sve datoteke.</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>Nemoguće učitati Flash sadržaj. Možete preuzeti poslednju verziju Flash Player-a na ovoj lokaciji</translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Adobe Flash Player Download Center</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Datoteke su otpremljene u</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Odaberi datoteke</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Sličica je kreirana.</translation>
    </message>
    <message>
        <source>Multiupload</source>
        <translation>Višestruko otpremanje</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/popupmenu</name>
    <message>
        <source>Upload multiple files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
