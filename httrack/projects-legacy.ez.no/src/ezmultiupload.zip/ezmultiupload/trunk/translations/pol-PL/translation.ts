<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Multiupload</source>
        <translation>Wielokrotne wczytywanie</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Pliki wczytywane do</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Wybierz pliki</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>Nie można załadować zawartości Flash. Pobierz ostatnią wersję Flash Player z</translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Centrum pobierania Adobe Flash Player</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Wszystkie pliki otrzymano.</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Utworzone.</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Rozpoczęcie...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/popupmenu</name>
    <message>
        <source>Upload multiple files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
