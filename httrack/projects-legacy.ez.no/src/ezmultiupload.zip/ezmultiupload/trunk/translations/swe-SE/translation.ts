<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Startar...</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Alla filer har mottagits.</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>Kunde inte ladda Flash-innehåll. Du kan ladda ned den senaste versionen av Flash PLayer från</translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Adobe Flash Player nedladdningscenter</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Filerna har laddats upp till</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Välj filer</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Miniatyr skapad.</translation>
    </message>
    <message>
        <source>Multiupload</source>
        <translation>Multi-uppladdning</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/popupmenu</name>
    <message>
        <source>Upload multiple files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
