<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Multiupload</source>
        <translation>Multi-téléchargement</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Les fichiers sont téléchargés vers</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Sélectionner les fichiers</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>Impossible de télécharger le contenu Flash. Vous pouvez télécharger la dernière version de Flash Player à partir de</translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Adobe Flash Player Download Center</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Tous les fichiers ont été reçus.</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Vignette créé.</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Démarrage...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation>Upload annulé.</translation>
    </message>
</context>
<context>
    <name>design/admin/popupmenu</name>
    <message>
        <source>Upload multiple files</source>
        <translation>Déposer plusieurs fichiers</translation>
    </message>
</context>
</TS>
