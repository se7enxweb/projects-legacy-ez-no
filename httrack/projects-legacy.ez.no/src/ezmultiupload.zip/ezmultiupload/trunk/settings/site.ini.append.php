<?php /*

[RegionalSettings]
TranslationExtensions[]=ezmultiupload

*/ ?>
