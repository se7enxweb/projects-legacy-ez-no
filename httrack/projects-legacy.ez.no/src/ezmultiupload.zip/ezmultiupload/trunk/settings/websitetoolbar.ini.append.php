<?php /*

[CustomTemplateSettings]
CustomTemplateList[]=ezmultiupload

IncludeInView[ezmultiupload]=full

*/ ?>