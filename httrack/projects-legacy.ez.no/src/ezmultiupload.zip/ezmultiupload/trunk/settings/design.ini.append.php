<?php /*

[ExtensionSettings]
DesignExtensions[]=ezmultiupload

*/ ?>