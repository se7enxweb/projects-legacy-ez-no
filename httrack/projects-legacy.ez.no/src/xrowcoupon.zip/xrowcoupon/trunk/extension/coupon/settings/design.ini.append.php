[ExtensionSettings]
DesignExtensions[]=coupon