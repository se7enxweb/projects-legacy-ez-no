[DataTypeSettings]
ExtensionDirectories[]=coupon
AvailableDataTypes[]=ezcoupon