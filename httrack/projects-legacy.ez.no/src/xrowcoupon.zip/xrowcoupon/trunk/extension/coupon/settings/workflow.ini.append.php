[EventSettings]
ExtensionDirectories[]=coupon
AvailableEventTypes[]=event_ezcouponworkflow
