#[ModuleSettings]
#ExtensionRepositories[]=coupon
