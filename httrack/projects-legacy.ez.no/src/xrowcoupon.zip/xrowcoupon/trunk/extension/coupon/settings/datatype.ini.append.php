[EditSettings]
GroupedInput[]=ezcoupon