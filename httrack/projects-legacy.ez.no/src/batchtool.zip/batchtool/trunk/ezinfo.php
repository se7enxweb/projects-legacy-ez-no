<?php
class ezdebugInfo
{
    static function info()
    {
        return array(
            'Name' => "Batchtool",
            'Version' => "1.1 beta",
            'Copyright' => "Copyright (C) 2010 A.Bakkeboe",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>
