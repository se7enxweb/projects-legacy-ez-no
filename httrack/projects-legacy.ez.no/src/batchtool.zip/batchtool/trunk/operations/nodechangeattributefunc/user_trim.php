<?php

// Example on user created function for editing an attribute
function user_trim( $attribute_string )
{
    return trim( $attribute_string );
}

?>
