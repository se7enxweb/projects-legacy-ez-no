<?php

/*
[ExtensionSettings]
DesignExtensions[]=nmtemporders
*/
?>