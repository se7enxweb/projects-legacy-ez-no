<?php
/*
[ModuleSettings]
ExtensionRepositories[]=nmtemporders
*/
?>
