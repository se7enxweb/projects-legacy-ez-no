<?php /* #?ini charset="utf-8"?
# eZ publish configuration file for modules

[ExtensionSettings]
DesignExtensions[]=ezpersonalfrontpage

[StylesheetSettings]
CSSFileList[]=box_layout.css
CSSFileList[]=box_design_default.css
CSSFileList[]=personalfrontpage_content.css

[JavaScriptSettings]
JavaScriptList[]=json.js
JavaScriptList[]=personal_frontpage_helper.js
JavaScriptList[]=drag_drop.js
JavaScriptList[]=boxes.js
JavaScriptList[]=weather_module.js


*/ ?>
