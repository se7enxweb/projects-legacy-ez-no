<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezpersonalfrontpage

*/ ?>
