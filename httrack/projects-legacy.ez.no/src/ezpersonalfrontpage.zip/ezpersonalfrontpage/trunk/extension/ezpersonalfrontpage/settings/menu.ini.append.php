<?php /*

[MenuContentSettings]
TopIdentifierList[]=personal_frontpage
LeftIdentifierList[]=personal_frontpage

[MenuSettings]
HideLeftMenuClasses[]=personal_frontpage

*/ ?>
