<?php /* #?ini charset="utf-8"?

[full_personal_frontpage]
Source=node/view/full.tpl
MatchFile=full/personal_frontpage.tpl
Subdir=templates
Match[class_identifier]=personal_frontpage

*/ ?>
