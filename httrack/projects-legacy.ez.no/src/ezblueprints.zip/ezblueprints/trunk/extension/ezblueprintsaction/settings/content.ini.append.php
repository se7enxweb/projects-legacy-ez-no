<?php /*

[ActionSettings]
ExtensionDirectories[]=ezblueprintsaction

*/ ?>