<?php /*

[EventSettings]
ExtensionDirectories[]=ezblueprintsworkflowevent

AvailableEventTypes[]=event_ezblueprintsworkflowevent

*/ ?>