[TemplateSettings]
ExtensionAutoloadPath[]=show_variables