<?php
/*

[ModuleSettings]
ExtensionRepositories[]=ngsuggest
ModuleList[]=ngsuggest

*/
?>
