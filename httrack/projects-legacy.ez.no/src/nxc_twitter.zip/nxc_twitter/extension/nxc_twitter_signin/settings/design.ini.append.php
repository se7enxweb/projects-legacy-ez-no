<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=nxc_twitter_signin

[StylesheetSettings]
CSSFileList[]=nxc_twitter_signin.css
*/ ?>
