<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=nxc_twitter_signin
ModuleList[]=nxc_twitter_signin
*/ ?>
