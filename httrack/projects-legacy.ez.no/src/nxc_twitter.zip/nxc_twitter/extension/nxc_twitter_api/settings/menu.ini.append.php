<?php /* #?ini charset="utf-8"?

[Leftmenu_setup]
Links[twitter_access_token]=nxc_twitter_api/settings
LinkNames[twitter_access_token]=Twitter Settings
*/ ?>