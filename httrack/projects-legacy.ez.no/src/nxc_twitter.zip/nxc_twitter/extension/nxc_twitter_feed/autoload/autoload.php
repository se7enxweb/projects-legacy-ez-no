<?php
/**
 * @package nxcTwitter
 * @author  Serhey Dolgushev <serhey.dolgushev@nxc.no>
 * @date    21 Sep 2010
 **/

return array (
	'nxcTwitterFeed' => './classes/feed.php'
);
?>
