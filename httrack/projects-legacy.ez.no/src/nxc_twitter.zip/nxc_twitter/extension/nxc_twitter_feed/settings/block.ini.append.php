<?php /* #?ini charset="utf-8"?

[General]
AllowedTypes[]=TwitterFeed

[TwitterFeed]
Name=Twitter feed
ManualAddingOfItems=disabled
ViewList[]=list
ViewName[list]=List
*/ ?>
