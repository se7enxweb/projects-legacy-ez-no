<?php /* #?ini charset="utf8"?

[ExtensionSettings]
DesignExtensions[]=nxc_twitter_publish
*/ ?>
