<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=nxc_twitter_publish
AvailableEventTypes[]=event_nxctwitterpublish
*/ ?>
