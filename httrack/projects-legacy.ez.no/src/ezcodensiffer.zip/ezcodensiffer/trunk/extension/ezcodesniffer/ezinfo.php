<?php
class ezcodesnifferInfo
{
    static function info()
    {
        return array(
            'Name' => "ezcodesniffer",
            'Version' => '0.1',
            'Copyright' => "Copyright (C) 2009 G. Giunta",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>
