<?php /* #?ini charset="utf-8"?

[GeneralSettings]
AvailableHandlers[]=AmazonAdvertising

[AmazonAdvertising]
TestName=Amazon Product Advertising API access
HandlerClass=JVAmazonAdvertisingMonitoringHandler
HandlerParams[]
HandlerParams[Operation]=ItemSearch
HandlerParams[SearchIndex]=Books
HandlerParams[Keywords]=harry potter

*/
