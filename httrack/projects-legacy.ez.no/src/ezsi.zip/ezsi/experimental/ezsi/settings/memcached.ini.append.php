<?php /* #?ini charset="utf-8"?

[MemcachedSettings]
Host=127.0.0.1
Port=11211
# TimeOut in seconds
TimeOut=2

*/ ?>
