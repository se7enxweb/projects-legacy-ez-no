<?php
$eZTemplateFunctionArray[] = array( 'script' => 'extension/ezsi/classes/ezsiblockfunction.php',
                                    'class' => 'eZSIBlockFunction',
                                    'function_names' => array( 'si-block' ) );

?>
