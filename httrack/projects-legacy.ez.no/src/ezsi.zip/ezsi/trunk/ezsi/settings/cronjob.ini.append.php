<?php /* #?ini charset="utf-8"?
[CronjobSettings]
ExtensionDirectories[]=ezsi

[CronjobPart-siblockupdate]
Scripts[]=siblockupdate.php
*/
?>
