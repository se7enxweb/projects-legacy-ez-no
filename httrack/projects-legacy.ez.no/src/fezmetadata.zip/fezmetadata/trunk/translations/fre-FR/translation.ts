<!DOCTYPE TS><TS>
<context>
	<name>design/admin/node/view/full</name>
	<message>
		<source>Meta Data</source>
		<translation>Méta Données</translation>
	</message>
	<message>
		<source>Meta Data [%meta_data]</source>
		<translation>Meta Données [%meta_data]</translation>
	</message>
	<message>
		<source>Select meta data for removal.</source>
		<translation>Sélectionner les métas données à supprimer</translation>
	</message>
	<message>
		<source>Add meta data</source>
		<translation>Ajouter une méta donnée</translation>
	</message>
	</context>
<context>
	<name>fezmetadata</name>
	<message>
		<source>No Meta Data stored for this object</source>
		<translation>Aucune Méta Donnée enregistrée pour cet objet</translation>
	</message>
	<message>
		<source>Add one new meta data</source>
		<translation>Ajouter une nouvelle méta donnée</translation>
	</message>
	<message>
		<source>Add meta data</source>
		<translation>Ajouter une meta donnée</translation>
	</message>
	<message>
		<source>Update this Meta Data</source>
		<translation>Editer cette Méta Donnée</translation>
	</message>
	<message>
		<source>Metadata name</source>
		<translation>Nom de la méta donnée</translation>
	</message>
	<message>
		<source>Metadata value</source>
		<translation>Contenu de la méta donnée</translation>
	</message>
	<message>
		<source>Keywords</source>
		<translation>Mots clés</translation>
	</message>
	<message>
		<source>Title</source>
		<translation>titre</translation>
	</message>
</context></TS>
