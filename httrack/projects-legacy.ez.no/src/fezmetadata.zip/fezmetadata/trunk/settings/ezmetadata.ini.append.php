<?php /* #?ini charset="utf-8"?

[MetaData]
AvailablesMetaData[]
AvailablesMetaData[]=description
AvailablesMetaData[]=keywords
AvailablesMetaData[]=title

[MetaData_description]
Name=Description
Operator=ezmetadata_description

[MetaData_keywords]
Name=Keywords
Operator=ezmetadata_keywords

[MetaData_title]
Name=Title
Operator=ezmetadata_title

*/ 
