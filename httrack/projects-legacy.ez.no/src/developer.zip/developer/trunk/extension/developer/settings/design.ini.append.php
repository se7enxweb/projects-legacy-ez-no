<?php /*

[ExtensionSettings]
DesignExtensions[]=developer

*/ ?>