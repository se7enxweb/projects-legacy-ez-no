<?php /*

[ModuleSettings]
ExtensionRepositories[]=developer
ModuleList[]=developer

*/ ?>