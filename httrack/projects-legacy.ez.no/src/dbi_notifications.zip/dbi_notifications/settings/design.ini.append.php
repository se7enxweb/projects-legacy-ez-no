<?php /*

[ExtensionSettings]
DesignExtensions[]=dbi_notifications

*/ ?>