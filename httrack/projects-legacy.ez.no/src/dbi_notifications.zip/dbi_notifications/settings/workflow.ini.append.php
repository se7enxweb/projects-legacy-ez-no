<?php /*

[EventSettings]
ExtensionDirectories[]=dbi_notifications
AvailableEventTypes[]=event_dbiaddnotificationrule

*/ ?>