[TemplateSettings]
ExtensionAutoloadPath[]=pdfpreview