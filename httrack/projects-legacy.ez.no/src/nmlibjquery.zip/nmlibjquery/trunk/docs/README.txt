A wrapper for the jquery javascript library (http://jquery.com/).

The extension currently holds production relase of version 1.3.2.