<?php /* #?ini charset="iso-8859-1"?

[ExtensionSettings]
DesignExtensions[]=nmlibjquery

[JavaScriptSettings]
#JavaScriptList[]=jquery-latest.js

*/ ?>
