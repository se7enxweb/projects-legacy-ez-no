<?php
class jacimportxmlInfo
{
    function info()
    {
        return array( 'Name' => 'jacimportxml - Import contentobjects over a xml/folder structure',
                      'Version' => '0.9.0',
                      'eZ version' => '3.x',
                      'Copyright' => '(C) 2007-2008 <a href="http://www.jac-systeme.de">JAC Systeme</a>',
                      'License' => "GNU General Public License v2.0",
                      'More Information' => '<a href="http://projects.ez.no/jacimportxml">http://projects.ez.no/jacimportxml</a>'
                    );
    }
}
?>
