<?php /* #?ini charset="utf-8"?

[ImportSettings]
RepositoryDirectories[]=extension/jacimportxml/classes

ExtensionDirectories[]=jacimportxml

#HandlerAlias[contentclass]=ezcontentclass

FilterExtensionDirectories[]=jacimportxml

*/ ?>
