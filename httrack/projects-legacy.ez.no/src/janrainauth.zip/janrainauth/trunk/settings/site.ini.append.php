<?php /* #?ini charset="utf-8"?

[RoleSettings]
PolicyOmitList[]=janrain/login

[RegionalSettings]
TranslationExtensions[]=janrainauth

*/