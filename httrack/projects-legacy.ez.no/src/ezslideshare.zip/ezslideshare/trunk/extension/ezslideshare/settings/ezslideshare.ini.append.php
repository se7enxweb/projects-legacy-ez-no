<?php /* #?ini charset="utf-8"?

[SlideshareAPISettings]
# Get your own API key/shared-secret pair by :
#  1. Creating an account on http://www.slideshare.net/ if not already done
#  2. Following the steps there : http://www.slideshare.net/developers/applyforapi
APIKey=<your-api-key>
SharedSecret=<your-shared-secret>

*/ ?>
