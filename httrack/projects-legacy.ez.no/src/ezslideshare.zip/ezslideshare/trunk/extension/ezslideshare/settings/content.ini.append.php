<?php /* #?ini charset="utf-8"?

[CustomTagSettings]
AvailableCustomTags[]=slideshare
CustomTagsDescription[slideshare]=Slideshare presentation

[slideshare]
CustomAttributes[]
CustomAttributes[]=presentation_url
CustomAttributes[]=width
CustomAttributes[]=height

*/ ?>