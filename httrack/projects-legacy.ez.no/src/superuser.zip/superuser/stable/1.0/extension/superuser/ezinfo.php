<?php
class superuserInfo
{
    function info()
    {
        return array(
            'Name' => "Super user",
            'Version' => "1.0",
            'Copyright' => "Copyright (C) 2006 SCK-CEN",
            'Author' => "Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>