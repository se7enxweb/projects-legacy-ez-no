<?php

/*

[UserSettings]
# Post-3.6.2
ExtensionDirectory[]=superuser

# Until 3.6.2
ExtensionDirectories[]=superuser

*/

?>
