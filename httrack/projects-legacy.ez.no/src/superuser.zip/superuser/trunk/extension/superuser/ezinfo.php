<?php
class superuserInfo
{
    static function info()
    {
        return array(
            'Name' => "Super User",
            'Version' => "2.x",
            'Copyright' => "Copyright (C) 2005-2007 SCK-CEN, 2008-2009 Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>