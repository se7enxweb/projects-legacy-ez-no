<?php /*
[TemplateSettings]
ExtensionAutoloadPath[]=ezdebug
*/ ?>