<?php
/**
* This class is left in only for bacward compatibility, it will be removed soon!
*/

/// @deprecated
class eZDebugOperator extends eZDebugOperators
{

}

?>