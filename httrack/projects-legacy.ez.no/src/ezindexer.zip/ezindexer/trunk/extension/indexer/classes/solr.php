<?php
/**
* This class is used to index data coming from an attribute of the parent object
**/
class ezSolrDocumentFieldParentIndexer extends ezfSolrDocumentFieldBase
{
    /**
    * Constructor. Will get the parent content object attributes from the datatype,
    * and instanciate ezfSolrDocumentFieldBase for each of them
    * @param eZContentObjectAttribute $attribute
    **/
    function ezSolrDocumentFieldParentIndexer( eZContentObjectAttribute $attribute )
    {
        parent::ezfSolrDocumentFieldBase( $attribute );

        $parentContentObjectAttributes = $this->ContentObjectAttribute->contentClassAttribute()->dataType()->getParentAttributes( $this->ContentObjectAttribute );
        // $this->parentContentClassAttributes  = $this->parentContentObjectAttribute->contentClassAttribute();
        // $this->parentAttributeDatatype       = $this->parentContentClassAttribute->dataType();

        if ( $parentContentObjectAttributes )
        {
            foreach ( $parentContentObjectAttributes as $contentObjectAttribute )
            {
                $this->documentFieldBase[] = ezfSolrDocumentFieldBase::getInstance( $contentObjectAttribute );
            }
        }
    }

    /**
    * Returns the external data managed by the attribute
    * @return array
    **/
    function getData()
    {
        $data = array();
        foreach ( $this->documentFieldBase as $documentFieldBase )
        {
            $tmpData = $documentFieldBase->getData();
            foreach ( $tmpData as $field => $value )
            {
                if ( !isset( $data[$field] ) )
                    $data[$field] = array();
                if ( !is_array( $value ) )
                    $value = array( $value );
                $data[$field] = array_merge( $data[$field], $value );
            }
        }

        return $data;
    }

    /**
    * This attribute is NOT a collection
    * @return bool false
    **/
    function isCollection()
    {
        return false;
    }

    /**
    * Returns the custom fields handled by the parent indexer
    * @param eZContentClassAttribute $classAttribute
    * @param array $options
    * @return array
    **/
    static function getCustomFields( eZContentClassAttribute $classAttribute, $options = null )
    {
        $mapping = eZINI::instance( 'indexer.ini' )->variable( 'IndexerSettings', 'ParentAttributes' );
        if ( array_key_exists( $classAttribute->attribute( 'id' ), $mapping ) )
        {
            $fields = array();
            $mappedAttributes = explode( ',', $mapping[ $classAttribute->attribute( 'id' ) ] );
            foreach ( $mappedAttributes as $mappedAttributeID )
            {
                $contentClassAttribute = eZContentClassAttribute::fetch( $mappedAttributeID );
                $fields = array_merge( $fields, ezfSolrDocumentFieldBase::getClassAttributeFields( $contentClassAttribute, $options ) );
            }
            return $fields;
        }
        else
        {
            return array();
        }
    }

    private $documentFieldBase = array();
}
?>