<?php
//
// ChildrenIndexer - extension for eZ Publish
// Copyright (C) 2008 Seeds Consulting AS, http://www.seeds.no/
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of version 2.0 of the GNU General
// Public License as published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
// MA 02110-1301, USA.
//

class ReindexType extends eZWorkflowEventType
{
    const WORKFLOW_TYPE_ID = 'reindex';

    function __construct()
    {
        parent::__construct( ReindexType::WORKFLOW_TYPE_ID, 'Reindex objects' );
    }

    /**
    * @todo Fix this so that it reindexes based on the INI setting:
    *       We look in the mapping table for a cc attrbute mapped as parent / children
    *       Indexer, and process based on the content class
    **/
    function execute( $process, $event )
    {
        $parameters = $process->attribute( 'parameter_list' );
        $objectID = $parameters['object_id'];

       	$contentObject = eZContentObject::fetch( $objectID );

        // nothing to reindex if the published version is the first
        if ( $contentObject->attribute( 'current_version' ) == 1 )
            return eZWorkflowType::STATUS_ACCEPTED;

        // we first look into the currently published content object and checked
        // if attributes involved in reindexing have been altered
        $this->parseReindexData( $contentObject );

        // if no reindexing is required we exit directly
        if ( !$this->needsReindexing )
            return eZWorkflowType::STATUS_ACCEPTED;

        // and we finally launch reindexing of mapped classes for altered attributes
        if ( $this->haveAttributesChanged() )
            $this->reindexChildren();

        return eZWorkflowType::STATUS_ACCEPTED;
    }

    /**
    * Checks if an attribute has changed between the current and previous version of an object
    * @return bool
    **/
    private function haveAttributesChanged()
    {
        list( $currentObjectDataMap, $previousObjectDataMap ) = $this->getVersionsDataMaps();
        $changed = false;

        foreach ( $this->reindexAttributes as $attributeIdentifier )
        {
            $currentAttribute = $currentObjectDataMap[$attributeIdentifier];
            $previousAttribute = $previousObjectDataMap[$attributeIdentifier];

            switch ( $currentAttribute->attribute( 'data_type_string' ) )
            {
                case 'ezstring':
                {
                    $previousContent = trim( $previousAttribute->content() );
                    $currentContent  = trim( $currentAttribute->content() );
                    if ( $previousContent != $currentContent )
                        return true;
                } break;

                case 'ezobjectrelationlist':
                {
                    $previousContent = $previousAttribute->content();
                    $previousContentObjectIDArray = array();
                    foreach ( $previousContent['relation_list'] as $relatedObject )
                        $previousContentObjectIDArray[] = $relatedObject['contentobject_id'];

                    $currentContent = $currentAttribute->content();
                    $currentContentObjectIDArray = array();
                    foreach ( $currentContent['relation_list'] as $relatedObject )
                        $currentContentObjectIDArray[] = $relatedObject['contentobject_id'];

                    $diff = array_diff( $previousContentObjectIDArray, $currentContentObjectIDArray );
                    if ( count( $diff ) != 0 )
                        return true;
                } break;

                case 'ezxmltext':
                {
                    $previousContent = $previousAttribute->content()->attribute( 'output' )->attribute( 'output_text' );
                    $currentContent  = $currentAttribute->content()->attribute( 'output' )->attribute( 'output_text' );
                    if ( $previousContent != $currentContent )
                        return true;
                } break;

            } // switch data_type_string
        } // foreach attributes

        return false;
    }

    /**
    * Returns the currently published version and the previous one
    * @param eZContentObject $contentObject
    * @return array ( <current version datamap> <previous version datamap> )
    **/
    private function getVersionsDataMaps()
    {
        $versions = $this->contentObject->attribute( 'versions' );
        $currentVersion = array_pop( $versions );
        $currentVersionDataMap = $currentVersion->attribute( 'data_map' );
        unset( $currentVersion );

        $previousVersion = array_pop( $versions );
        $previousVersionDataMap = $previousVersion->attribute( 'data_map' );
        unset( $previousVersion );

        return array( $currentVersionDataMap, $previousVersionDataMap );
    }

    /**
    * Reindexes the children of class $classIdentifiers that are part of the subtrees
    * of $contentObject's locations
    * @param eZContentObject $contentObject
    * @param array $classIdentifiers
    * @return int the number of reindexed content objects
    **/
    private function reindexChildren()
    {
        $parentNodes = array();
        foreach ( $this->contentObject->assignedNodes( $asObject = false ) as $node )
        {
            $parentNodes[] = $node['node_id'];
        }

        $params = array( 'ClassFilterType' => 'include',
                         'ClassFilterArray' => $this->reindexClasses,
                         'AsObject' => false,
                         'DepthOperator' => 'ge',
                         'Depth' => 1 );
        if ( $children = eZContentObjectTreeNode::subTreeByNodeID( $params, $parentNodes ) )
        {
            foreach ( $children as $child )
            {
                eZContentOperationCollection::registerSearchObject( $child['contentobject_id'], 0 );
            }
        }
        return count( $children );
    }

    /**
    * Parses a content object for reindex data. Will read parsing configuration
    * and determine which classes and attributes need to be checked
    * @param eZContentObject $contentObject
    **/
    private function parseReindexData( eZContentObject $contentObject )
    {
        $this->contentObject = $contentObject;
        $classAttributes = $contentObject->contentClass()->fetchAttributes( $id = false, $asObject = false );

        $attributesMapping = eZINI::instance( 'indexer.ini' )->variable( 'IndexerSettings', 'ParentAttributes' );

        foreach ( $classAttributes as $classAttribute )
        {
            foreach ( $attributesMapping as $mappedAttribute => $attributeIDString )
            {
                $attributeIDArray = explode( ',', $attributeIDString );
                if ( in_array( $classAttribute['id'], $attributeIDArray ) )
                {
                    $this->needsReindexing = true;

                    // we store attributes that need to be checked for changes by identifier
                    foreach ( $attributeIDArray as $attributeID )
                    {
                        $attribute = eZContentClassAttribute::fetch( $attributeID, $asObject = false );
                        $this->reindexAttributes[] = $attribute['identifier'];
                    }

                    // and we store the classes that need to be looked for in the object's subtrees by identifier
                    $attribute = eZContentClassAttribute::fetch( $mappedAttribute, $asObject = false );
                    $class = eZContentClass::fetch( $attribute['contentclass_id'], $asObject = false );
                    $this->reindexClasses[] = $class['identifier'];
                }
            }
        }
    }

    /// vars
    private $needsReindexing   = false;
    private $reindexAttributes = array();
    private $reindexClasses    = array();
    private $contentObject     = null;
}

eZWorkflowEventType::registerEventType( ReindexType::WORKFLOW_TYPE_ID, 'reindextype' );

?>