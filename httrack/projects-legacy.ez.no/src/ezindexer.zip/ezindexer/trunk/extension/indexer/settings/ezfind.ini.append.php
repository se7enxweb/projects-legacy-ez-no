<?php /*
[SolrFieldMapSettings]
CustomMap[parentindexer]=ezSolrDocumentFieldParentIndexer
#CustomMap[childrenindexer]=ezSolrDocumentFieldParentIndexer

*/ ?>