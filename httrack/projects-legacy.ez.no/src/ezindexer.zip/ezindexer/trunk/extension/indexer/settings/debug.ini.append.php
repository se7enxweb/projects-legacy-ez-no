<?php /* #?ini charset="iso-8859-1"?

[GeneralCondition]
extension-indexer=enabled

*/ ?>
