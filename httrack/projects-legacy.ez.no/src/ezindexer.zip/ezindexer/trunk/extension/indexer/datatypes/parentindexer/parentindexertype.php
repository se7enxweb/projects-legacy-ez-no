<?php
//
// ChildrenIndexer - extension for eZ Publish
// Copyright (C) 2008 Seeds Consulting AS, http://www.seeds.no/
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of version 2.0 of the GNU General
// Public License as published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
// MA 02110-1301, USA.
//

class ParentIndexerType extends eZDataType
{
    const DATA_TYPE_STRING = 'parentindexer';

    function __construct()
    {
        parent::__construct( ParentIndexerType::DATA_TYPE_STRING, 'Parent attribute indexer' );
    }

    function isIndexable()
    {
        return true;
    }

    /**
    * Returns the parent object attribute's content based on the INI configuration
    **/
    function objectAttributeContent( $contentObjectAttribute )
    {
        $content = false;

        if ( $parentAttribute = self::getParentAttribute( $contentObjectAttribute ) != false )
            $content = $parentAttribute->metaData();

        return $content;
    }

    /**
    * @deprecated Uses an overload of ezfSolrDocumentFieldBase for greater flexibility
    **/
    function metaData( $contentObjectAttribute )
    {
        $metaDataString = false;

        if ( $parentAttribute = $this->getParentAttribute( $contentObjectAttribute ) != false )
            $metaDataString = $parentAttribute->metaData();

        return $metaDataString;
    }

    /**
    * Validates class / classattribute pairs submitted at class level
    * @param eZHTTPTool $http
    * @param string $base
    * @param eZContentClassAttribute $classAttribute
    * @return int
    **/
    function validateClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        return eZInputValidator::STATE_ACCEPTED;
    }

    /**
     * Stores class level input
     * @param eZHTTPTool $http
     * @param string $base
     * @param eZContentClassAttribute $classAttribute
     * @return bool
     **/
    function fetchClassAttributeHTTPInput( $http, $base, $classAttribute )
    {
        // $domTree = new DOMDocument( '1.0', 'utf-8' );
    }

    /**
    * Returns the class attribute content
    * @param eZContentClassAttribute $classAttribute
    * @return array an array with the following keys:
    *               attributes_list => array of eZAttributeIndexerAttributeEntry
    **/
    function classAttributeContent( $classAttribute )
    {
        if ( $classAttribute->Content == null )
        {
            $classAttribute->Content['attributes_list'] = array();
            $xmlString = $classAttribute->attribute( 'data_text5' );
            $domTree = new DOMDocument( '1.0', 'utf-8' );
            if ( $xmlString != '' )
            {
                $domTree->loadXML( $xmlString );
                foreach ( $domTree->getElementsByTagName( 'ClassAttributePair' ) as $pairNode )
                {
                    try
                    {
                        $pair = new eZAttributeIndexerAttributeListEntry( $pairNode->getAttribute( 'attributeID' ) );
                    }
                    catch ( Exception $e )
                    {
                        eZDebug::writeError( $e->getMessage(), 'ParentIndexerType::classAttributeContent()' );
                        continue;
                    }
                    $classAttribute->Content['attributes_list'][] = $pair;
                }
            }
        }
        return $classAttribute->Content;
    }

    /**
    * Initializes the class attribute content to an empty, valid XML string
    * and saves the class attribute to the database
    * @param eZContentClassAttribute $classAttribute
    * @return bool
    **/
    function initializeClassAttribute( $classAttribute )
    {
        $xmlText = $classAttribute->attribute( 'data_text5' );
        if ( trim( $xmlText ) == '' )
        {
            $content = array( 'attributes_list' => array() );
            return $this->storeClassAttributeContent( $classAttribute, $content );
        }
        return false;
    }

    /**
    * Returns the parent content object attributes mapped to the current attribute
    * @param eZContentObjectattribute $contentObjectAttribute
    * @return eZContentObjectAttribute
    **/
    function getParentAttributes( eZContentObjectAttribute $contentObjectAttribute )
    {
        echo "!!! getParentAttributes of {$contentObjectAttribute->attribute('id')}\n";
        static $parentAttributes = array();

        // multiple calls to the same content object attribute are cached in the
        // static variable $parentAttribute
        if ( !isset( $parentAttributes[$contentObjectAttribute->attribute( 'id' )] ) )
        {
            $contentObjectAttributeID = $contentObjectAttribute->attribute( 'id' );
            $parentAttributes[$contentObjectAttribute->attribute( 'id' )] = false;

            // we load the list of mapped content class attributes
            $classAttributeContent = $contentObjectAttribute->contentClassAttribute()->content();

            // we index all the parent attributes for the current attribute as follows:
            // array( <classidentifier> => array( 'attributeidentifier1', 'attributeidentifier2' )
            $parentContentClassAttributeArray = array(); $attributesCount = 0;
            foreach ( $classAttributeContent['attributes_list'] as $classAttributePair )
            {
                $parentContentClassAttribute = $classAttributePair->attribute( 'attribute' );
                $parentContentClass = $classAttributePair->attribute( 'class' );

                $parentContentClassIdentifier = $parentContentClass->attribute( 'identifier' );
                $parentContentClassAttributeIdentifier = $parentContentClassAttribute->attribute( 'identifier' );

                if ( !isset( $parentContentClassAttributeArray[$parentContentClassIdentifier] ) )
                    $parentContentClassAttributeArray[$parentContentClassIdentifier] = array();

                $parentContentClassAttributeArray[$parentContentClassIdentifier][] = $parentContentClassAttributeIdentifier;
                $attributesCount++;
            }
            $searchedContentClasses = array_keys( $parentContentClassAttributeArray );

            // we recursively loop over the content object parents until we find the attribute
            // when found, it is assigned in the static cache variable indexed by object ID
            $parentNode = $contentObjectAttribute->object()->mainNode()->fetchParent();
            do
            {
                if ( in_array( $parentNode->classIdentifier(), $searchedContentClasses ) )
                {
                    foreach ( $parentContentClassAttributeArray as $classIdentifier => $attributesIdentifiersArray )
                    {
                        $dataMap = $parentNode->dataMap();
                        foreach ( $attributesIdentifiersArray as $attributeIdentifier )
                        {
                            $parentAttributes[$contentObjectAttributeID][] = $dataMap[$attributeIdentifier];
                        }
                    }
                }
                $parentNode = $parentNode->fetchParent();
            } while( ( count( $parentAttributes[$contentObjectAttributeID] ) < $attributesCount ) and ( $parentNode->attribute( 'depth' ) > 1 ) );
        }
        print_r( $parentAttributes[$contentObjectAttributeID] );
        return $parentAttributes[$contentObjectAttributeID];
    }

    function preStoreClassAttribute( $classAttribute, $version )
    {
        $content = $classAttribute->content();
        return $this->storeClassAttributeContent( $classAttribute, $content );
    }

    /**
    * Handles custom attribute HTTP actions for class editing
    * Actions:
    *   - add_class_attribute_pair: adds a class / attribute pair
    *   - remove_class_attribute_pair: removes a (list of) class / attribute pair
    * @param eZHTTPTool $http
    * @param string $action
    * @param eZContentClassAttribute $classAttribute
    **/
    function customClassAttributeHTTPAction( $http, $action, $classAttribute )
    {
        switch ( $action )
        {
            // add a class / attribute pair
            case 'add_class_attribute_pair':
            {
                $attributeFieldName = 'ContentClass_indexer_class_attribute_list_' . $classAttribute->attribute( 'id' );
                if ( $http->hasPostVariable( $attributeFieldName ) )
                {
                    $attributeID = $http->postVariable( $attributeFieldName );
                    $this->addClassAttributePair( $classAttribute, $attributeID );
                }
            } break;

            // remove a selected (list of) class / attribute pair
            case 'remove_class_attribute_pair':
            {
                $checkboxFieldName = 'ContentClass_indexer_classattribute_pair_' . $classAttribute->attribute( 'id' );
                if ( $http->hasPostVariable( $checkboxFieldName ) )
                {
                    $selectedAttributeArray = $http->postVariable( $checkboxFieldName );
                    foreach ( $selectedAttributeArray as $selectedAttributeID )
                    {
                        $this->removeClassAttributePair( $classAttribute, $selectedAttributeID );
                    }
                }
            } break;
        }
    }

    /**
    * Adds a class / attribute pair to the attribute
    * @param eZContentClassAttribute $classAttribute
    * @param int $attributeID
    **/
    private function addClassAttributePair( eZContentClassAttribute $classAttribute, $attributeID )
    {
        $content = $this->classAttributeContent( $classAttribute );
        $content['attributes_list'][] = new eZAttributeIndexerAttributeListEntry( $attributeID );
        $classAttribute->setContent( $content );
    }

    /**
     * Removes a class / attribute pair to the attribute
     * @param eZContentClassAttribute $classAttribute
     * @param int $attributeID
     **/
    private function removeClassAttributePair( eZContentClassAttribute $classAttribute, $attributeID )
    {
        $content = $this->classAttributeContent( $classAttribute );
        foreach ( $content['attributes_list'] as $index => $classAttributePair )
        {
            if ( $classAttributePair->attribute( 'attribute' )->attribute( 'id' ) == $attributeID )
            {
                unset( $content['attributes_list'][$index] );
            }
        }
        $classAttribute->setContent( $content );
    }

    /**
    * Stores the class attribute content to an XML string in data_text5
    * @param eZContentClassAttribute $content
    * @param array $content
    * @return bool
    **/
    function storeClassAttributeContent( $classAttribute, $content )
    {
        if ( is_array( $content ) )
        {
            $doc = new DOMDocument( '1.0', 'utf-8' );
            $root = $doc->createElement( 'ClassAttributePairs' );
            foreach ( $content['attributes_list'] as $classAttributePair )
            {
                $classAttributePairNode = $doc->createElement( 'ClassAttributePair' );
                $classAttributePairNode->setAttribute( 'attributeID', $classAttributePair->attribute( 'attribute' )->attribute( 'id' ) );
                $root->appendChild( $classAttributePairNode );
            }
            $doc->appendChild( $root );
            $classAttribute->setAttribute( 'data_text5', $doc->saveXML() );
            return true;
        }
        return false;
    }
}

eZDataType::register( ParentIndexerType::DATA_TYPE_STRING, 'parentindexertype' );

?>