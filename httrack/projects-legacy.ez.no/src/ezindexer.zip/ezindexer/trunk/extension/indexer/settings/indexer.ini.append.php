﻿<?php /* #?ini charset="utf-8"?

[IndexerSettings]
# ParentAttributes[<ContentClassAttributeID>]=<AncestorContentClassAttributeID>

# ctc_libro/cta_autores mapped to parent:ctc_manuscrito/cta_autores
ParentAttributes[458]=203

# ctc_libro/cta_idioma mapped to parent:ctc_manuscrito/cta_idioma
ParentAttributes[459]=201

# Parent indexer configuration for books extras
# ctc_extra/cta_indexer_ctc_libro mapped to:
#  #203: ctc_manuscrito/cta_autores
#  #210: ctc_libro/cta_titulo
#  #212: ctc_libro/cta_sinopsis
ParentAttributes[460]=203,210,212

# Parent indexer configuration for books extras
# ctc_extra/cta_indexer_ctc_libro mapped to:
#  #189: ctc_autor/cta_nombre
#  #182: ctc_autor/cta_biografia
ParentAttributes[461]=182,189

*/ ?>