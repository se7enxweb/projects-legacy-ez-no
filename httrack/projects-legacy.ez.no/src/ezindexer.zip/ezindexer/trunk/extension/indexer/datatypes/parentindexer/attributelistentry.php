<?php
/**
 * Handles an entry of type c
 *
 */
class eZAttributeIndexerAttributeListEntry
{
    /**
     * Constructor
     * @param int $attributeID
     * @throws eZAttributeIndexerAttributeNotFoundException
     */
    function __construct( $attributeID )
    {
        if ( !$this->attribute = eZContentClassAttribute::fetch( $attributeID ) )
        {
            throw new eZAttributeIndexerAttributeNotFoundException( $attributeID );
        }
    }

    /**
    * Attribute callback
    * @param string $attributeName
    * @return mixed class:     the pair content class as an eZContentClass
    *               attribute: the pair content class as an eZContentClassAttribute
    **/
    public function attribute( $attributeName )
    {
        switch ( $attributeName )
        {
            // returns the class attribute as an eZContentClass
            case 'class':
            {
                if ( $this->class == null )
                {
                    $this->class = eZContentClass::fetch( $this->attribute( 'attribute' )->attribute( 'contentclass_id' ) );
                }
                return $this->class;
            } break;

            // returns the class attribute as an eZContentClassAttribute
            case 'attribute':
            {
                return $this->attribute;
            } break;
        }
    }

    public function attributes()
    {
        return array( 'class', 'attribute' );
    }

    public function hasAttribute( $attributeName )
    {
        return in_array( $attributeName, array( 'class', 'attribute' ) );
    }

    private $class = null;
    private $attribute = null;
}

class eZAttributeIndexerAttributeNotFoundException extends ezcBaseException
{
    public function __construct( $attributeID )
    {
        parent::__construct( "No attribute with ID #{$attributeID} was found" );
    }
}
?>