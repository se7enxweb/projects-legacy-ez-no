<?php
//
// ChildrenIndexer - extension for eZ Publish
// Copyright (C) 2008 Seeds Consulting AS, http://www.seeds.no/
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of version 2.0 of the GNU General
// Public License as published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
// MA 02110-1301, USA.
//

class ChildrenIndexerType extends eZDataType
{
    const DATA_TYPE_STRING = 'childrenindexer';

    function __construct()
    {
        parent::__construct( ChildrenIndexerType::DATA_TYPE_STRING, 'Children Indexer' );
    }

    function isIndexable()
    {
        return true;
    }

    function metaData( $contentObjectAttribute )
    {
        $db = eZDB::instance();
        $contentObjectID = $contentObjectAttribute->attribute( 'contentobject_id' );
       	$contentObject = eZContentObject::fetch($contentObjectID);
       	
       	if ($contentObject->ClassIdentifier == 'ctc_libro')
        {
	        // Find words indexed for children of the current object's main node
	        $words = $db->arrayQuery( "SELECT word 
	                                   FROM ezcontentobject_tree ot,
	                                        ezcontentobject_tree t,
	                                        ezsearch_object_word_link l,
	                                        ezsearch_word w
	                                   WHERE ot.contentobject_id=$contentObjectID
	                                     AND ot.main_node_id=ot.node_id
	                                     AND ot.parent_node_id=t.node_id
	                                     AND l.contentobject_id=t.contentobject_id
	                                     AND w.id=l.word_id", array( 'limit' => 1000 ) );
	        $metaData = array();
	        foreach ( $words as $word )
	        {
	            $metaData[] = $word['word'];
	        }
	        $metaDataString = implode( $metaData, ' ' );
        }
        else
        {
        	 $words = $db->arrayQuery( "SELECT word 
	                                   FROM ezcontentobject_tree ot,
	                                        ezsearch_object_word_link l,
	                                        ezsearch_word w
	                                   WHERE ot.contentobject_id=$contentObjectID
	                                     AND l.contentobject_id=ot.contentobject_id
	                                     AND w.id=l.word_id", array( 'limit' => 1000 ) );
	        $metaData = array();
	        foreach ( $words as $word )
	        {
	            $metaData[] = $word['word'];
	        }
	        $metaDataString = implode( $metaData, ' ' );
        }
        return $metaDataString;
    }
}

eZDataType::register( ChildrenIndexerType::DATA_TYPE_STRING, 'childrenindexertype' );

?>
