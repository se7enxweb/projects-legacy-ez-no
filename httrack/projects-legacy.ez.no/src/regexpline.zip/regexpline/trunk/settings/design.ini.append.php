<?php
/*

[ExtensionSettings]
DesignExtensions[]=regexpline

*/
?>
