<?php
/*

[RegionalSettings]
TranslationExtensions[]=regexpline

*/
?>