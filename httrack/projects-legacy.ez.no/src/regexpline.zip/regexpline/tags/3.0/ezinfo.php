<?php

class regexplineInfo
{
    function info()
    {
        return array(
            'Name' => 'Regular Expression Datatype',
            'Version' => '3.0',
            'Copyright' => 'Copyright (C) 2005-' . date( 'Y' ) . ' Hans Melis',
            'License' => 'GNU General Public License v2.0'
        );
    }
}

?>