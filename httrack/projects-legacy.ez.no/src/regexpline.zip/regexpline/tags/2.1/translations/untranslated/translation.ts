<!DOCTYPE TS><TS>
<context>
    <name>extension/regexpline/datatype</name>
    <message>
        <source>Regular Expression Text</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is a required field which means you can&apos;t leave it empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your input did not meet the requirements.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/regexpline/design/standard/class/datatype/edit</name>
    <message>
        <source>To allow all input:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help text for users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No subpatterns defined. Using the complete expression.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This field allows you to structure the object naming pattern for this attribute. To use a subpattern of your regular expression, place its number (visible in the list below) in a tag-like notation, e.g. &amp;lt;1&amp;gt; to use the first subpattern.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>These are the available subpatterns:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regular expression(s) (Perl-compatible)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add regular expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove regular expression(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Single text line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text area (Text block)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regexp / Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Negate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/regexpline/design/standard/class/datatype/view</name>
    <message>
        <source>Regular expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object name pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No pattern supplied. Using the complete expression.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Negated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error message</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/regexpline/design/standard/content/datatype/edit</name>
    <message>
        <source>Help text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
