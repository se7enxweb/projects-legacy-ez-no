<?php

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] = array( 'script' => 'extension/cmsxf2b/autoloads/cmsxf2btemplateutils.php',
                                    'class' => 'cmsxF2bTemplateUtils',
                                    'operator_names' => array( 'f2b_info_cobranca' ) );


?>
