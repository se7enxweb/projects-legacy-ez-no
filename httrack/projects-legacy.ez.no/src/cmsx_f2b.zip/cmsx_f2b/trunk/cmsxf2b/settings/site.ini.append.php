<?php /* #?ini charset="utf-8"?
# eZ publish configuration file for site wide settings

[ExtensionSettings]
ActiveExtensions[]=cmsxf2b

[RoleSettings]
PolicyOmitList[]=f2b/confirmardados

[TemplateSettings]
ExtensionAutoloadPath[]=cmsxf2b

*/ ?>