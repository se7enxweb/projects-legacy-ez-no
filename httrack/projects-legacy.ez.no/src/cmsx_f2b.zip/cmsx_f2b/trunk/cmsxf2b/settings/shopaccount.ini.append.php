<?php /* #?ini charset="utf-8"?

[HandlerSettings]
ExtensionRepositories[]=cmsxf2b

[AccountSettings]
Handler=cmsxf2b

*/ ?>