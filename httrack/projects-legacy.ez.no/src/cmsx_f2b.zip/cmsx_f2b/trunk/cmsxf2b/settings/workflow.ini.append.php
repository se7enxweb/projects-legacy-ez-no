<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=cmsxf2b

*/ ?>