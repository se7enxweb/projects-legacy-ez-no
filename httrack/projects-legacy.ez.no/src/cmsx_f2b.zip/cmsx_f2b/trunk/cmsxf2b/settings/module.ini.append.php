<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=cmsxf2b
ModuleList[]=f2b

*/ ?>