<?php /*

[CronjobPart-googlesitemaps]
Scripts[]
Scripts[]=generate.php

[CronjobSettings]
Scripts[]=generate.php
ExtensionDirectories[]=all2egooglesitemaps

*/ ?>
