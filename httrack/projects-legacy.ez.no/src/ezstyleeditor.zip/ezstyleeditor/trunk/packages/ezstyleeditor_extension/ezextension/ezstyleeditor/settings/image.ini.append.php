<?php /* 

[AliasSettings]
AliasList[]=styleeditor

[styleeditor]
Reference=
Filters[]
Filters[]=geometry/scaledownonly=100;75

*/ ?>