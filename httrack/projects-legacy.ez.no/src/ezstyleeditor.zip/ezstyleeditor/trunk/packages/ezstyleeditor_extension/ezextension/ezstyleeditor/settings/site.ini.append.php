<?php /*

[RegionalSettings]
TranslationExtensions[]=ezstyleeditor

*/ ?>
