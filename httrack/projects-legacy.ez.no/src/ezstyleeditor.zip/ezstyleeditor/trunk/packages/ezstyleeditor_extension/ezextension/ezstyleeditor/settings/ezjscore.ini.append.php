<?php /*

[ezjscServer_ezcsse]
Class=ezcsseServerCallFunctions
File=extension/ezstyleeditor/classes/ezcsseservercallfunctions.php

*/ ?>