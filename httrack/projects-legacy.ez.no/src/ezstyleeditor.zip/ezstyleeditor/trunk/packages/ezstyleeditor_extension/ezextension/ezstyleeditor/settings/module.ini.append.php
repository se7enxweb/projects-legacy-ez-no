<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezstyleeditor
ModuleList[]=styleeditor

*/ ?>
