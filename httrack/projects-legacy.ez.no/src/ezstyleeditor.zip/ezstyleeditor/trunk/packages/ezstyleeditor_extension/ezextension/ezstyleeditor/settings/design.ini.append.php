<?php /*

[ExtensionSettings]
DesignExtensions[]=ezstyleeditor

*/ ?>
