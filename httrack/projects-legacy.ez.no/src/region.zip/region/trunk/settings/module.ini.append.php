<?php /* #?ini charset="utf8"?

[ModuleSettings]
ExtensionRepositories[]=region
*/ ?>