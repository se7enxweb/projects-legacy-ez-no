<?php /* #?ini charset="utf-8"?

[ContentSettings]
#CachedViewPreferences[full]=user_preferred_currency='';user_preferred_country='';

[RoleSettings]
PolicyOmitList[]=region/index

[RegionalSettings]
TranslationExtensions[]=region

[TemplateSettings]
ExtensionAutoloadPath[]=region

[SSLZoneSettings]
ModuleViewAccessMode[region/*]=keep

*/ ?>
