[region_pagelayout]
Source=pagelayout_index.tpl
MatchFile=pagelayout_index.tpl
Subdir=templates