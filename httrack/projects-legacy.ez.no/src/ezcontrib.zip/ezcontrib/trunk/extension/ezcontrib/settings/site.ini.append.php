<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezcontrib

[DesignSettings]
AdditionalSiteDesignList[]=ezcontrib

[RegionalSettings]
TranslationExtensions[]=ezcontrib

*/ ?>
