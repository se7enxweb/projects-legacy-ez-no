<?php /*

[ExtensionSettings]
DesignExtensions[]=opsa_rsstemplate

*/ ?>