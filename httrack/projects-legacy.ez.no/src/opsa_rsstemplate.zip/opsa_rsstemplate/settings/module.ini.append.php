<?php /*

[ModuleSettings]
ExtensionRepositories[]=opsa_rsstemplate

ModuleList[]=rsstemplate

*/ ?>