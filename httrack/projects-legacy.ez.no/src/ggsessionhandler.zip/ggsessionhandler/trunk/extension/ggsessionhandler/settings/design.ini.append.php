<?php /*

[ExtensionSettings]
DesignExtensions[]=ggsessionhandler

*/ ?>