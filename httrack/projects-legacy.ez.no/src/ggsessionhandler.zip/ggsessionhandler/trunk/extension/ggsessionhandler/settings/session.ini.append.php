<?php /*

[SessionSettings]
### Definition of session storage handler
### supported value: database (default), shm, memcache
Handler=database

*/ ?>