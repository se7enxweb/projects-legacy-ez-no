<?php /*

[ModuleSettings]
ExtensionRepositories[]=ggsessionhandler

*/ ?>