<?php /*


[lightbox]
PageLayout=lightbox_pagelayout.tpl



*/ ?>