<?php /*

[ExtensionSettings]
DesignExtensions[]=oplightbox2

*/ ?>