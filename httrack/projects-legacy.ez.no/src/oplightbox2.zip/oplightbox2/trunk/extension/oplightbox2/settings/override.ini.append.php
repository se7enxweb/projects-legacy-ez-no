<?php /*

[full_flash_player]
Source=node/view/lightbox.tpl
MatchFile=lightbox/flash_player.tpl
Subdir=templates
Match[class_identifier]=flash_player

*/ ?>