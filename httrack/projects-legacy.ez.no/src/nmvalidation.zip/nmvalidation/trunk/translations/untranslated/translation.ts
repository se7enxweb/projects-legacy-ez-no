<!DOCTYPE TS><TS>
<context>
    <name>validate</name>
    <message>
        <source>Please provide a value.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please select an option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please provide a valid date in the syntax of DD.MM.YYYY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please provide a valid domain name in the form of &quot;domain.com&quot;. If your domain name contains norwegian characters, please convert your domain name to ACE.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please provide just the domain name, without the &quot;www&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please provide a valid username. The username must have between 2 and 8 characters, and only contain lowercase letters from the english alphabet. The username could not start with &quot;test&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please provide a valid email address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This field can only contain numbers.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This field must match the field </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There is already a user account registered with this email address.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
