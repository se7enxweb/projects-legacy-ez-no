[RegionalSettings]
TranslationExtensions[]=nmvalidation