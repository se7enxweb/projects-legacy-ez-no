eZFTP extension
---------------

Contributors
============

   eZFTP extension
   ---------------
   Damien Pitard, damien.pitard <at> gmail <dot> com

   nanoFTPd
   --------
   Arjen, arjenjb <at> wanadoo <dot> nl
   Phanatic, linux <at> psoftwares <dot> hu

License
=======

This software is licensed under the GNU General Public Licence v2.0.
The complete license agreement is included in the LICENSE.txt file.
For more information or questions please contact damien.pitard <at> gmail <dot> com

The FTP core system is based on the third-party software nanoFTPd.
nanoFTPd is licensed under the GNU General Public Licence v2.0.
For more information please visit http://nanoftpd.sourceforge.net

The content In&Out system is based on eZPublish webdav sources.
eZPublish is licensed under the GNU General Public Licence v2.0.
For more information please visit http://www.ez.no

Warranty
========

THE SOFTWARE IS PROVIDED �AS IS�, WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT THE AUTHOR OR
ANY OTHER CONTRIBUTOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Requirements
============

Please read the INSTALL.txt file for requirements instructions.

Installation
============

Please read the INSTALL.txt file for installation instructions.

Troubleshooting
===============

1. Read the FAQ
   ------------

   Some problems are more common than others. The most common ones are listed
   in the FAQ.txt file.

2. Documentation
   ------------

   none

3. Support
   -------

   none