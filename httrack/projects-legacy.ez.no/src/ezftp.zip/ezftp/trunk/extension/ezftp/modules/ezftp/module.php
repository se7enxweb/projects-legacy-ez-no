<?php

$Module = array( 'name' => 'eZFTP',
                 'variable_params' => true,
                 'functions' => array( 'use' ),
                 'function' => array( 'script' => 'ftp.php' ) );

$ViewList = array();

$FunctionList['use'] = array();

?>