<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezawstats
ModuleList[]=awstats

*/ ?>
