<?php /*

[ExtensionSettings]
DesignExtensions[]=ezawstats

[StylesheetSettings]
CSSFileList[]=awstats.css

*/ ?>
