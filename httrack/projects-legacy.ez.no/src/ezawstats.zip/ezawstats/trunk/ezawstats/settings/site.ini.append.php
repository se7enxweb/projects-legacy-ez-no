<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezawstats

*/ ?>
