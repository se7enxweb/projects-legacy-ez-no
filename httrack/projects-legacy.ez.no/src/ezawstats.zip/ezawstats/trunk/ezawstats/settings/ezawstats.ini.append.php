<?php /*

[AWStatsSettings]
DataDir=var/awstats
DefaultSite=
SiteList[]

*/?>
