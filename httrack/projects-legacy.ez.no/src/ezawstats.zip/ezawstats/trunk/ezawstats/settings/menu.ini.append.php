<?php /*

[NavigationPart]
Part[awstats]=Statistics

[TopAdminMenu]
Tabs[]=awstats

[Topmenu_awstats]
NavigationPartIdentifier=awstats
Name=Statistics
Tooltip=AWStats statistics
URL[]
URL[default]=awstats/stats
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[navigation]=true
Shown[default]=true
Shown[browse]=true

*/ ?>
