<?php /*

[ClassSettings]
Formats[awstats_day_month]=%d %M %Y

*/ ?>
