<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezawstats/autoloads/operators.php',
                                    'class' => 'eZAWStatsOperators',
                                    'operator_names' => array( 'is_week_end', 'date_eq', 'data_multiplier' ) );

?>
