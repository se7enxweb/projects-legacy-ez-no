<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezwt

*/ ?>