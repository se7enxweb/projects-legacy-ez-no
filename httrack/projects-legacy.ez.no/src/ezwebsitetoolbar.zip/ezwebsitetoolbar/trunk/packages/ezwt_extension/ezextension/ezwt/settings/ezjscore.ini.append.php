<?php /* 

[ezjscServer_ezwt]
Class=ezwtServerCallFunctions

*/ ?>