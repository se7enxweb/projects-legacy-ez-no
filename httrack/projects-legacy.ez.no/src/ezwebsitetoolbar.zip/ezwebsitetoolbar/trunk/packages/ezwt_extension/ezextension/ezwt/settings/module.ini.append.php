<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezwt
ModuleList[]=websitetoolbar

*/ ?>