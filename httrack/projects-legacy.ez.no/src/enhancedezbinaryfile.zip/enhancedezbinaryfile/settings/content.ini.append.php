<?php /* #?ini charset="iso-8859-1"?

[DataTypeSettings]
ExtensionDirectories[]=enhancedezbinaryfile
AvailableDataTypes[]=enhancedezbinaryfile

*/ ?>

