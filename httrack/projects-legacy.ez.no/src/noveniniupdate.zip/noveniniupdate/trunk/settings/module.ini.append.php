<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=noveniniupdate
ModuleList[]=noveniniupdate

*/ ?>