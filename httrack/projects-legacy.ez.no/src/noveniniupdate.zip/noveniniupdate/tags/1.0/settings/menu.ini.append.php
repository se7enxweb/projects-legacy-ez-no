<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[noveniniupdatenavigationpart]=Noven: advanced INI parameters

[TopAdminMenu]
Tabs[]=noveniniupdate

[Topmenu_noveniniupdate]
NavigationPartIdentifier=noveniniupdatenavigationpart
Name=Advanced INI Params
Tooltip=Edit INI files depending on your environment (ie. prod, preprod...)
Tooltip=Noven : édition de paramètres avancés INI en fonction de l'environnement
URL[]
URL[default]=noveniniupdate/view
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=false

*/ ?>
