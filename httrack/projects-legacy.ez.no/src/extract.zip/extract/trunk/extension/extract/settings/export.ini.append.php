<?php /* #?ini charset="utf8"?

[ExportSettings]
#If ExportClasses is not set or empty the system will make all classes available.
ExportClasses[]
#ExportClasses[]=user

# When unset it will take User placement/User ClassID
StartNodeID=
DefaultClassID=
PreselectAttributes=true

#Default to unlimited
Limit=0
Offset=0

*/ ?>