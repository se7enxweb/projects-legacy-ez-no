<?php /* #?ini charset="utf8"?

[ModuleSettings]
ExtensionRepositories[]=extract
ModuleList[]=extract

*/ ?>