<!DOCTYPE TS><TS>
<context>
    <name>design/standard/extract</name>
    <message>
        <source>Extract</source>
        <translation>Export</translation>
    </message>
    <message>
        <source>Extract settings</source>
        <translation>Réglage de l&apos;export</translation>
    </message>
    <message>
        <source>Row separator</source>
        <translation>Séparateur lignes</translation>
    </message>
    <message>
        <source>Column separator</source>
        <translation>Séparateur colonnes</translation>
    </message>
    <message>
	<source>Options</source>
	<translation>Options</translation>
    </message>
    <message>
	<source>Limit</source>
	<translation>Nombre de ligne</translation>
    </message>
    <message>
	<source>Offset</source>
	<translation>Décalage</translation>
    </message>
    <message>
        <source>Selected node</source>
        <translation>Noeud sélectionné</translation>
    </message>
    <message>
        <source>Selected attribute(s)</source>
        <translation>Attributs sélectionné(s)</translation>
    </message>
    <message>
        <source>Selected class</source>
        <translation>Classe sélectionnée</translation>
    </message>
    <message>
        <source>Choose node to export</source>
        <translation>Choisissez le noeud à exporter</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Changer</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation>Identifiant</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Actualiser</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Télécharger</translation>
    </message>
    <message>
        <source>Add attribute</source>
        <translation>Ajouter l&apos;attribut</translation>
    </message>
    <message>
        <source>Remove selected attribute(s)</source>
        <translation>Supprimer les attribut(s) sélectionés</translation>
    </message>
    <message>
        <source>Select a node to export</source>
        <translation>Choisissez le noeud a exporter</translation>
    </message>
    <message>
        <source>Setup format options</source>
        <translation>Choisissez les options de formatage</translation>
    </message>
    <message>
        <source>Select concerned class</source>
        <translation>Selectionnez la classe</translation>
    </message>
    <message>
	<source>Add/Remove attributes</source>
	<translation>Ajoutez/Supprimez des attributs</translation>
    </message>
    <message>
        <source>Click the download button</source>
        <translation>Cliquez sur le bouton telecharger</translation>
    </message>
</context>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Extract</source>
        <translation>Export</translation>
    </message>
</context>
</TS>
