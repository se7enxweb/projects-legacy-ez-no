<?php /* #?ini charset="utf8"?

[RegionalSettings]
TranslationExtensions[]=extract

*/ ?>