<?php /* #?ini charset="utf8"?

Part[ezextractnavigationpart]=Extract

[TopAdminMenu]
Tabs[]=extract

[Topmenu_extract]
NavigationPartIdentifier=ezextractnavigationpart
Name=Export
Tooltip=Export CSV
URL[]
URL[default]=extract/csv
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=false
Shown[navigation]=true
Shown[browse]=true

*/ ?>