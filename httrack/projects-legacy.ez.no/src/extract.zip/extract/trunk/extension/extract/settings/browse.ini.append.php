<?php /* #?ini charset="utf8"?

# Action for finding placement for toolbar node
[ExtractionSubtree]
StartNode=users
SelectionType=single
ReturnType=NodeID
TopLevelNodes[]
TopLevelNodes[]=users
TopLevelNodes[]=

*/ ?>