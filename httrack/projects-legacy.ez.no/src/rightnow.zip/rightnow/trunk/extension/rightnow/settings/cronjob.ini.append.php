<?php /* #?ini charset="utf-8"?

[CronjobSettings]
ExtensionDirectories[]=rightnow

[CronjobPart-faqimport]
Scripts[]=faqimport.php

*/ ?>