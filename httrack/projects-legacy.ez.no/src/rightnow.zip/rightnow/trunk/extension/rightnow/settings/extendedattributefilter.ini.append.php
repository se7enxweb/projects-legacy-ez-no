<?php /* #?ini charset="utf-8"?

#The name of the filter.
[RelationFilter]
 
#The name of the extension where the filtering code is defined.
ExtensionName=rightnow
 
#The name of the filter class.
ClassName=RightNowExtendedFilter
 
#The name of the method which is called to generate the SQL parts.
MethodName=createSqlParts
 
#The file which should be included (extension/myextension will automatically be prepended).
FileName=classes/rightnowextendedfilter.php

*/ ?>