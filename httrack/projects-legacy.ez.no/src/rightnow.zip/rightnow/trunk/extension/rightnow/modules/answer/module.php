<?php
/**
 * File module.php
 *
 * @package rightnow
 * @version //autogentag//
 * @copyright Copyright (C) 2007 xrow. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl.txt GPL License
 */
$Module = array( "name" => "Answer Create" );

$ViewList = array();

$ViewList["create"] = array(    
    'functions' => array( ),
    'script' => 'create.php' );
?>