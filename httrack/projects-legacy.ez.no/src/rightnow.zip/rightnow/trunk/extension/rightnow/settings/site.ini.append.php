<?php /* #?ini charset="utf-8"?
[RoleSettings]
PolicyOmitList[]=answer/create
PolicyOmitList[]=rightnow/logout
#Use for testing only
#PolicyOmitList[]=rightnow/test


[UserSettings]
LoginHandler[]=rightnow
ExtensionDirectory[]=rightnow
*/ ?>