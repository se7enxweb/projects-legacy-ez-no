<?php /* #?ini charset="utf-8"?
[ImportSettings]
ExtensionDirectories[]=rightnow
FilterExtensionDirectories[]=rightnow
*/ ?>