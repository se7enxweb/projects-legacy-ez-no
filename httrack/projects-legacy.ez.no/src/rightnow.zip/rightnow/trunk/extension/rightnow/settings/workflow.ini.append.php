<?php /* #?ini charset="utf-8"?
[EventSettings]
ExtensionDirectories[]=rightnow
AvailableEventTypes[]=event_rightnowuser
AvailableEventTypes[]=event_rightnowanswer
*/ ?>