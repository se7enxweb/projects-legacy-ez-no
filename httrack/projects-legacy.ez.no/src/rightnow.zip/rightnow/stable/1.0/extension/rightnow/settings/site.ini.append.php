<?php /* #?ini charset="utf-8"?
[RoleSettings]
PolicyOmitList[]=rightnow/test
PolicyOmitList[]=answer/create

[UserSettings]
LoginHandler[]=rightnow
ExtensionDirectory[]=rightnow
*/ ?>