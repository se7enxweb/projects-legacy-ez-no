<?php /*

[ActionSettings]
ExtensionDirectories[]=ezevent

[DataTypeSettings]
ExtensionDirectories[]=ezevent
AvailableDataTypes[]=ezevent

*/ ?>
