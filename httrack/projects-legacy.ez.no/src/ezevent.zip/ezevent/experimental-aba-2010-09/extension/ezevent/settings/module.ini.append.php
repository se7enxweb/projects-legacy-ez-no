<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezevent
ModuleList[]=ezajax
ModuleList[]=event

*/ ?>
