<?php /*

[EventSettings]
ExtensionDirectories[]=ezevent
AvailableEventTypes[]=event_updateevents

*/ ?>
