<?php /*

[RegionalSettings]
TranslationExtensions[]=ezevent

[SearchSettings]
EnableWildcard=true

*/ ?>
