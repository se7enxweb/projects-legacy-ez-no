<?php /*

#[AttendeeSettings]
#SearchRootNode=2
#ClassIdentifierFilter=folder

#[ForwardSettings]
#RedirectToParentCalendar=enabled

# Usage: ForwardUrlMap[<param>]=<target>
#ForwardUrlMap[]

*/ ?>
