<?php /*

[ExtensionSettings]
DesignExtensions[]=ezevent

[JavaScriptSettings]
#JavaScriptList[]=yui/build/yahoo-dom-event/yahoo-dom-event.js
#JavaScriptList[]=yui/build/calendar/calendar.js
#JavaScriptList[]=ezdatepicker.js
#JavaScriptList[]=ezevent.js

[StylesheetSettings]
CSSFileList[]=ezevent.css

*/ ?>
