<?php /* #?ini charset="utf8"?

[DataTypeSettings]
ExtensionDirectories[]=ezmbpaex
AvailableDataTypes[]=ezpaex

[ContentOverrideSettings]
EnableClassGroupOverride=true

*/ ?>
