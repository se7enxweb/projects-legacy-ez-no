<?php /*

[SearchSettings]
ExtensionDirectories[]=ezsolr
SearchEngine=ezsolr

*/ ?>