<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezpaypal
ModuleList[]=paypal

*/ ?>