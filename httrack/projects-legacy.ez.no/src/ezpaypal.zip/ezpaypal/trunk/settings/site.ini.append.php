<?php /* 


[RoleSettings]
PolicyOmitList[]=paypal/notify_url


*/ ?>