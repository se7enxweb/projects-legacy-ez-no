<?php
class all2eVccInfo
{
    function info()
    {
        return array( 'Name' => "all2e Varnish Control Center",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) 2008 <a href='http://www.all2e.com' title='eZ Publish'>all2e GmbH</a>"
                     );
    }
}
?>
