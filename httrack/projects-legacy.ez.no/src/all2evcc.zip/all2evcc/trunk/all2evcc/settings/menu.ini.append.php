<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[all2evccnavigationpart]=Varnish Control

[TopAdminMenu]
Tabs[]=all2evcc

[Topmenu_all2evcc]
NavigationPartIdentifier=all2evccnavigationpart
Name=Varnish Control
Tooltip=Control your 'Varnish Server'
URL[]
URL[default]=all2evcc/varnish_control
Enabled[]
Enabled[default]=false
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=false
Shown[edit]=false
Shown[navigation]=true
Shown[browse]=false

*/ ?>
