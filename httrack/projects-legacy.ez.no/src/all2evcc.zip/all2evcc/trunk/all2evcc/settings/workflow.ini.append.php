<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=all2evcc

AvailableEventTypes[]=event_varnish

*/ ?>
