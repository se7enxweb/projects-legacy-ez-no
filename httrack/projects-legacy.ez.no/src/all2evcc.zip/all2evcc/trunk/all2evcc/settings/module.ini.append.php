<?php /*

[ModuleSettings]
ModuleList[]=all2evcc
ExtensionRepositories[]=all2evcc



*/ ?>
