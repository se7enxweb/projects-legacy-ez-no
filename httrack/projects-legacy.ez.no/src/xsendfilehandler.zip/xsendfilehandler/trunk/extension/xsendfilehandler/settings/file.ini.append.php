<?php /*

[BinaryFileSettings]
ExtensionRepositories[]=xsendfilehandler

# handler for lighttpd and Apache's mod_xsendfile
Handler=xsendfile

# handler for Nginx
#Handler=xaccelredirect

*/ ?>