<?php
class xsendfilehandlerInfo
{
    static function info()
    {
        return array(
            'Name' => "X-SendFile binary file download handler",
            'Version' => "0.2",
            'Copyright' => "Copyright (C) 2008,2009 K. Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>
