<?php

include_once( 'extension/ggwebservices/xmlrpc/common.php' );

?>
