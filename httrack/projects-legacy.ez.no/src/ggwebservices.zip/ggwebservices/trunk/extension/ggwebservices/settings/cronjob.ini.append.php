<?php /*

[CronjobSettings]
ExtensionDirectories[]=ggwebservices

[CronjobPart-rotatewslogs]
Scripts[]=rotatewslogs.php

*/ ?>
