<?php
/**
 * Sample xmlrpc server that uses the ggws classes outside of an eZ Publish context
 *
 * @version $Id: xmlrpc_server_outside_ezp.php 420 2012-01-11 08:41:39Z gg $
 * @author Gaetano Giunta
 * @copyright (c) 2010-2012 G. Giunta
 * @license code licensed under the GNU GPL. See LICENSE file
 */

// include client classes (this is done by autload when within an eZP context)
include_once( "ggwebservices/classes/ggwebservicesserver.php" );
include_once( "ggwebservices/classes/ggxmlrpcserver.php" );
include_once( "ggwebservices/classes/ggwebservicesrequest.php" );
include_once( "ggwebservices/classes/ggxmlrpcrequest.php" );
include_once( "ggwebservices/classes/ggwebservicesresponse.php" );
include_once( "ggwebservices/classes/ggxmlrpcresponse.php" );
include_once( "ggwebservices/classes/ggwebservicesfault.php" );

$server = new ggXMLRPCServer();
$server->registerFunction( "examples.addtwo", array( "valueA" => "int", "valueB" => "int" ) );
$server->processRequest();

function examples_addtwo( $valueA, $valueB )
{
    return (int)$valueA + (int)$valueB;
}

?>