<?php

define( 'WS_PROTOCOL', 'jsonrpc' );
require( 'extension/ggwebservices/webservicescontroller.php' );

?>