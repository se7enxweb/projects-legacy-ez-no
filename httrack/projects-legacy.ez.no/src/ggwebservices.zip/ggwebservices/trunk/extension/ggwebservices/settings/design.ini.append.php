<?php /*

[ExtensionSettings]
DesignExtensions[]=ggwebservices

*/ ?>