<?php /*

[ModuleSettings]
ExtensionRepositories[]=ggwebservices

ModuleList[]=webservices

*/ ?>