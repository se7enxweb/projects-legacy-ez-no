<?php /*

[EventSettings]
ExtensionDirectories[]=dbi_readverification
AvailableEventTypes[]=event_dbiaddreadverification

*/ ?>