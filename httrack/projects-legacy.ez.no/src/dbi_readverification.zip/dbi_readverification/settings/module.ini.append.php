<?php /*

[ModuleSettings]
ExtensionRepositories[]=dbi_readverification
ModuleList[]=readverification

*/ ?>