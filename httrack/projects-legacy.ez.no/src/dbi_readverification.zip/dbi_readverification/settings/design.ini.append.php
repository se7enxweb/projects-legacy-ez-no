<?php /*

[ExtensionSettings]
DesignExtensions[]=dbi_readverification

*/ ?>