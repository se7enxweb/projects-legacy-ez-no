<?php /*

[ActionSettings]
ExtensionDirectories[]=dbi_readverification

*/ ?>