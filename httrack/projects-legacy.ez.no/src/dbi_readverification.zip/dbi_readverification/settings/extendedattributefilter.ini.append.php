<?php /*

[ReadVerificationFilter]
ExtensionName=dbi_readverification
ClassName=eZContentObjectReadVerificationFilter
MethodName=createSqlParts
FileName=classes/ezcontentobjectreadverificationfilter.php

*/ ?>