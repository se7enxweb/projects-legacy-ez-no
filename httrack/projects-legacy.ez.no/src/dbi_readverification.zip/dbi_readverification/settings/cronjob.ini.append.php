<?php /*

[CronjobPart-readverificationcleanup]
Scripts[]
Scripts[]=readverificationcleanup.php

[CronjobSettings]
ExtensionDirectories[]=dbi_readverification

*/ ?>