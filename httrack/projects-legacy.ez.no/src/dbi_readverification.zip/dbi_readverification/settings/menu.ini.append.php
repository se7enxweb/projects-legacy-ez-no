<?php /*

[NavigationPart]
Part[readverification]=Read verification

[TopAdminMenu]
Tabs[]=readverification

[Topmenu_readverification]
NavigationPartIdentifier=readverification
Name=Read verification
Tooltip=Verify if certain objects were read
URL[]
URL[default]=readverification/object_list
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=false
Shown[edit]=true
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false

*/ ?>