<?php

include_once( 'extension/dbi_readverification/classes/ezcontentobjectreadverification.php' );

eZContentObjectReadVerification::cleanupPurgedContent();

?>
