<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezrating/autoloads/ezratingoperator.php',
                                    'class' => 'eZRatingOperator',
                                    'operator_names' => array( 'ezrating_summary' ) );

?>
