<?php
class gisoperatorsInfo
{
    function info()
    {
        return array(
            'Name' => "<a href='http://projects.ez.no/gisoperators'>Global Information Systems Operators</a>",
            'Version' => "0.0.2",
            'Copyright' => "Copyright (C) 2007, <a href='http://www.all2e.com/'>all2e GmbH</a>",
            'Author' => "Norman Leutner",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>