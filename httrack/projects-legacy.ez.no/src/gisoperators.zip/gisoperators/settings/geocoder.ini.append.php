<?php /*

[GoogleGeoCoder]
# Your Google API Key 
APIKey=ABQIAAAALOkn_RM177NhKbfH2CJxGRTHHMuXVISMjvokekEjCug0O_BoMBQV_-fAVJYVce2F-mR9NEO05Hnxvw

# Url of Google Maps API
Url=http://maps.google.com/maps/geo

/*?>