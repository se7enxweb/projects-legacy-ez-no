<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=gisoperators

*/ ?>