<?php
class redirectInfo
{
    function info()
    {
        return array(
            'Name' => "Redirect",
            'Version' => "1.0",
            'Copyright' => "Copyright (C) 2005-2006 SCK-CEN",
            'Author' => "Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>