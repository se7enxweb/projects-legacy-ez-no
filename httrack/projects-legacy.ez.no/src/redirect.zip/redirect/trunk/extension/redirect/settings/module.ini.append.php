<?php
/*

[ModuleSettings]
ExtensionRepositories[]=redirect
ModuleList[]=redirect

*/
?>
