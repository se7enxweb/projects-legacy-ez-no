<?php
class redirectInfo
{
    static function info()
    {
        return array(
            'Name' => '<a href="http://projects.ez.no/redirect">Redirect</a>',
            'Version' => "2.0",
            'Copyright' => "Copyright (C) 2005-2006 SCK-CEN, 2007-2008 Kristof Coomans",
            'Author' => "Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>