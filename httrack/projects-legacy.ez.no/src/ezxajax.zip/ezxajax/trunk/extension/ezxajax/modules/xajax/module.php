<?php
/**
 * File module.php
 *
 * @package xajax
 * @version //autogentag//
 * @copyright Copyright (C) 2006 SCK-CEN All rights reserved.
 * @license http://www.gnu.org/licenses/lgpl.txt LGPL License
 */
$Module = array( 'name' => 'Xajax', 'variable_params' => false );

$ViewList = array();

$ViewList['call'] = array(
    'script' => 'call.php',
    'ui_context' => 'edit',
    'params' => array( )
);

$FunctionList = array();

?>
