<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ezxajax

[RoleSettings]
PolicyOmitList[]=xajax
*/ ?>