<?php

class ezxajax_helloworldInfo
{
    static function info()
    {
        return array(
            'Name' => "ezxajax hello world example",
            'Version' => "1.0.0",
            'Copyright' => "Copyright (C) 2006-2007 SCK-CEN, 2008-2009 Kristof Coomans",
            'Author' => "Kristof Coomans",
            'License' => "GNU Lesser General Public License v2.1",
        );
    }
}
?>
