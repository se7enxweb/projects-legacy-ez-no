<?php /*

[ExtensionSettings]
ExtensionDirectories[]=xajax_helloworld

# sayHelloWorld is the function name
# helloworld(.php) is the file under the xajax/ dir which contains the function
AvailableFunctions[sayHelloWorld]=helloworld

*/ ?>