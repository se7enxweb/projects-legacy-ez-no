<?php /* #?ini charset="utf8"?

[ModuleSettings]
ExtensionRepositories[]=xrowmetadata

ModuleList[]=sitemaps
*/ ?>