[DataTypeSettings]
ExtensionDirectories[]=xrowmetadata
AvailableDataTypes[]=xrowmetadata
