<?php /*

[EditorInputSettings]
MaxTitle=65
MaxDescription=150

?>
