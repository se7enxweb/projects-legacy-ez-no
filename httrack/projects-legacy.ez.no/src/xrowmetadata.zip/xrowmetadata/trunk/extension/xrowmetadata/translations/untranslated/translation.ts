<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use in sitemap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change frequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>always</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hourly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>daily</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>weekly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>monthly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>yearly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use in sitemap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change frequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <location filename="xrowmetadatatype.php" line="14"/>
        <source>Metadata</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="xrowmetadatatype.php" line="55"/>
        <source>Input required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="xrowmetadatatype.php" line="60"/>
        <source>Title required.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
