<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=xrowmetadata

[RegionalSettings]
TranslationExtensions[]=xrowmetadata

[RoleSettings]
PolicyOmitList[]=sitemaps/index
PolicyOmitList[]=sitemaps/robots
*/?>
