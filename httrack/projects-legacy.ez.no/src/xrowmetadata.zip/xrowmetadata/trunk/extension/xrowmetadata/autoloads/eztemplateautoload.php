<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 
    'script' => 'extension/xrowmetadata/autoloads/xrowmetadataoperator.php' , 
    'class' => 'xrowMetaDataOperator' , 
    'operator_names' => array( 
        'metadata' 
    ) 
);

?>