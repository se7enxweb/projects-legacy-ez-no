<?php

class xrowSitemap extends xrowSitemapList
{
    const BASENAME = 'urlset';
    const SUFFIX = 'xml';
    const ITEMNAME = 'url';
}

?>