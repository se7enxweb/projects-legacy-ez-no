[ExtensionSettings]
DesignExtensions[]=xrowmetadata
