<?php /*

[CronjobPart-sitemap]
Scripts[]
Scripts[]=sitemap.php

[CronjobPart-archivesitemap]
Scripts[]
Scripts[]=archivesitemap.php

[CronjobPart-newssitemap]
Scripts[]
Scripts[]=newssitemap.php

[CronjobPart-mobilesitemap]
Scripts[]
Scripts[]=mobilesitemap.php

[CronjobSettings]
Scripts[]=sitemap.php
Scripts[]=newssitemap.php
ExtensionDirectories[]=xrowmetadata

*/?>
