[ViewSettings]
GroupedInput[]=xrowmetadata

[EditSettings]
GroupedInput[]=xrowmetadata

[CollectionSettings]
GroupedInput[]=xrowmetadata
