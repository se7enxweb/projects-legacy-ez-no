<?php

class xrowSitemapIndex extends xrowSitemapList
{
    const BASENAME = 'sitemapindex';
    const SUFFIX = 'xml';
    const ITEMNAME = 'sitemap';
}

?>