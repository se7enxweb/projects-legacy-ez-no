<?php
/**
 * File containing the xrowmetadataInfo class.
 *
 * @package xrowmetadata
 * @version //autogentag//
 * @copyright Copyright (C) 2009 xrow GmbH. All rights reserved.
 * @license GPL
 */
class xrowmetadataInfo
{
    static function info()
    {
        return array(
            'Name' => "xrowmetadata",
            'Version' => "1.0",
            'Release' => "1",
            'Copyright' => "Copyright (C) 2009 xrow GmbH",
            'Author' => "xrow GmbH",
            'License' => "GPL" );
    }
}
?>