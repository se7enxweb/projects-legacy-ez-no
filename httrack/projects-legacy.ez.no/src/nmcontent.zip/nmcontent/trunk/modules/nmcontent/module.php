<?php

$Module = array( 'name' => 'Test',
                 'variable_params' => true );

$ViewList = array();

$ViewList['classimport'] = array(
    'script' => 'classimport.php',
    );
    
$ViewList['structureimport'] = array(
    'script' => 'structureimport.php',
    );

$ViewList['classlist'] = array(
    'script' => 'classlist.php',
    );


?>
