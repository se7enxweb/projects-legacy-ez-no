<?php /* #?ini charset="utf-8"?

[SiteAccessSettings]
AnonymousAccessList[]=nmcontent/classlist

[RoleSettings]
PolicyOmitList[]=nmcontent/classlist

*/ ?>