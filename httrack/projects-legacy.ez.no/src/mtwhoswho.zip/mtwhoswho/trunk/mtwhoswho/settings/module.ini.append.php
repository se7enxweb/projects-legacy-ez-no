<?php /*

[ModuleSettings]
ExtensionAjaxRepositories[]=mtwhoswho
ExtensionRepositories[]=mtwhoswho


*/ ?>