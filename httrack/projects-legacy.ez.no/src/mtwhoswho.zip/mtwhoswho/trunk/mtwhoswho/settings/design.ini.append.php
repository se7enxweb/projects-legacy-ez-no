<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=mtwhoswho

[StylesheetSettings]
CSSFileList[]=mtwhoswho.css

[JavaScriptSettings]
JavaScriptList[]=jquery-1.3.2.min.js
JavaScriptList[]=mtwhoswho.js

*/ ?>
