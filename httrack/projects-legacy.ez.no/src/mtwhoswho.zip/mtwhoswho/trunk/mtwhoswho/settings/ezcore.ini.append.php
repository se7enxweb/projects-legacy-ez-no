<?php
/*
[eZCoreServerCall_mtwhoswho]
Class=MTWhoswhoServerCallFunctions
File=extension/mtwhoswho/classes/mtwhoswhoservercallfunctions.php

*/?>