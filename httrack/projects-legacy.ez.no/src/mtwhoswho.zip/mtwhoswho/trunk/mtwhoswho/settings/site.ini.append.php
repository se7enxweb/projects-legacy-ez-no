<?php /*

[RegionalSettings]
TranslationExtensions[]=mtwhoswho

*/ ?>