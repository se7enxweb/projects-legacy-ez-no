<?php

class mtwhoswhoInfo
{
    static function info()
    {
        return array( 'Name' => "MT Who's Who",
                      'Version' => "0.9",
                      'Copyright' => "Copyright (C) 2009 Maxime THOMAS",
                      'License' => "GNU General Public License v3.0",
					  'More info' => "http://www.wascou.org"
    }
}
?>
