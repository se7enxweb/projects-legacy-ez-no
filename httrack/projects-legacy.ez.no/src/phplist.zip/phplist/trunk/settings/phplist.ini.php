<?php /* #?ini charset="iso-8859-1"?

# Entries are of the form
# MapEzPhplist[eZ publish attribute id]=phplist attribute id
# This is experimental so your luck may vary

#[AttributeMap]
#MapEzPhplist[246]=1
#MapEzPhplist[247]=2
#MapEzPhplist[457]=3

*/ ?>
