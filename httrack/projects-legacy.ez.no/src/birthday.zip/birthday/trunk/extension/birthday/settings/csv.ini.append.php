<?php /* #?ini charset="utf-8"?

[General]
ExportableDatatypes[]=ezbirthday

[ezbirthday]
HandlerFile=extension/birthday/classes/parsers/ezbirthdayhandler.php
HandlerClass=eZBirthdayHandler

*/ ?>