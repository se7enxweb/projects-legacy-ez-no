<?php

class ezworkflowcollectionInfo
{
    static function info()
    {
        return array( 'Name' => "ezworkflowcollection",
                      'Version' => "0.5-dev",
                      'Copyright' => "Copyright (C) 2010-2011 G. Giunta - O. Portier",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}

?>