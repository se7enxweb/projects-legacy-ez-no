<?php /*

[DashboardSettings]
# Adds a new dashboard block
DashboardBlocks[]=updatestate_pending

[DashboardBlock_updatestate_pending]
Priority=12
NumberOfItems=10
PolicyList[]=updatestate/list

*/ ?>
