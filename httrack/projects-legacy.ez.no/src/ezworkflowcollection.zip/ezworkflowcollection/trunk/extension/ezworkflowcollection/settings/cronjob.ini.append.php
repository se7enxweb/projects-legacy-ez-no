<?php /*

[CronjobSettings]
ExtensionDirectories[]=ezworkflowcollection

[CronjobPart-archiver]
Scripts[]=updateobjectstate.php

[CronjobPart-frequent]
Scripts[]=updateobjectstate.php

*/ ?>
