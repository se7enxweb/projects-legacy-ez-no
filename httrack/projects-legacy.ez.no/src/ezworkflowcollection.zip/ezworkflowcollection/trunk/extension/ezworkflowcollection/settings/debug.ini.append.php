<?php /*

[GeneralCondition]
ezworkflowcollection-workflow-approve-location=enabled

*/ ?>