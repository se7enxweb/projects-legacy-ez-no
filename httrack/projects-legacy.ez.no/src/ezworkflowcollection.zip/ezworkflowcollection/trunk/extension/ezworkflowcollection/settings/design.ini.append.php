<?php /*

[ExtensionSettings]
DesignExtensions[]=ezworkflowcollection

*/ ?>