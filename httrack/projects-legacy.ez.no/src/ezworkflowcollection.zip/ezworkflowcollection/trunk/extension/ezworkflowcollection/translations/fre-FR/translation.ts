<!DOCTYPE TS><TS>
<context>
    <name>extension/ezworkflowcollection</name>
    <message>
        <source>Target nodes</source>
        <translation>Noeud cible</translation>
    </message>
    <message>
        <source>Multipublish</source>
        <translation></translation>
    </message>
    <message>
        <source>Class name</source>
        <translation>Nom de la classe</translation>
    </message>
    <message>
        <source>ClassAttribute name</source>
        <translation>Nom de l'attribut de la classe</translation>
    </message>
    <message>
        <source>Filter on class attributes:</source>
        <translation>Filtrer sur un attribut de la classe</translation>
    </message>
    <message>
        <source>(only booleans supported)</source>
        <translation>(booléens supportés uniquement)</translation>
    </message>

    <message>
        <source>Subtree Multiplexer</source>
        <translation>Multiplexer de sous arborescence</translation>
    </message>
    <message>
        <source>Affected subtree</source>
        <translation>Sous arbrescence affectée</translation>
    </message>
</context>
<context>
    <name>extension/ezworkflowcollection/design/admin/updatestate/list</name>
    <message>
        <source>Content in state</source>
        <translation>Contenus à l'état</translation>
    </message>
    <message>
        <source>List content in state</source>
        <translation>Liste des contenus à l'état</translation>
    </message>
    <message>
        <source>There is no content in state</source>
        <translation>Il n'y a aucun contenu à l'état</translation>
    </message>
    <message>
        <source>Update selected content objects for following state</source>
        <translation>Mettre à jour les objets de contenu pour l'état suivant</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Mettre à jour</translation>
    </message>
</context>
<context>
    <name>extension/ezworkflowcollection/admin/parts/my/menu</name>
    <message>
        <source>Update states</source>
        <translation>Mettre à jour les états</translation>
    </message>
</context>
<context>
    <name>extension/ezworkflowcollection/dashboard</name>
    <message>
        <source>Content waiting for publishing validation</source>
        <translation>Contenus à valider et publier</translation>
    </message>
</context>
</TS>
