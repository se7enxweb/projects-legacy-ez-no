<?php /*

[ModuleSettings]
ExtensionRepositories[]=montradapayment

ModuleList[]=montrada

*/ ?>
