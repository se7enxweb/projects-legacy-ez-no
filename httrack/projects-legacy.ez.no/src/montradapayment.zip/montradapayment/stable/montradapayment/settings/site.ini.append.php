<?php /*

[RoleSettings]
PolicyOmitList[]=montrada/notificate
PolicyOmitList[]=montrada/redirector

*/ ?>
