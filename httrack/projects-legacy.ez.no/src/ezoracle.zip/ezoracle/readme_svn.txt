THIS REPOSITORY HAS BEEN MIGRATED TO GITHUB ON MARCH 2001, AND IT IS NOW CLOSED.
PLEASE HEAD ON TO https://github.com/ezsystems/ezoracle FOR THE SOURCE CODE


The structure of the repository:

- releases: full copies of released versions - in eZ standard it is often named 'versions'
- stable: one branch for every major version of the extension
- trunk: where most of the development happens, is the current major version
- branches: same as unstable: different versions that might become the next major one or be merged one day
