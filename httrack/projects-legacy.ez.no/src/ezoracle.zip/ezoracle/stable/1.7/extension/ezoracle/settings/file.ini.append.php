<?php /*

[ClusteringSettings]
ExtensionDirectories[]=ezoracle

# Example configuration for activating cluster mode with oracle
#FileHandler=ezdb
#DBBackend=oracle
#DBHost=orcl
#DBPort=1521
#DBName=
#DBUser=scott
#DBPassword=tiger
#DBChunkSize=65535
#DBConnectRetries=3
#DBExecuteRetries=20

*/ ?>
