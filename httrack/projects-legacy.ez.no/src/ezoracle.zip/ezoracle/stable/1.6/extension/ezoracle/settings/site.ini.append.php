<?php /*
[DatabaseSettings]
ImplementationAlias[oracle]=ezoracle
*/ ?>
