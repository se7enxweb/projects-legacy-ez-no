<?php /*
[ClusteringSettings]
ExtensionDirectories[]=ezoracle
*/ ?>
