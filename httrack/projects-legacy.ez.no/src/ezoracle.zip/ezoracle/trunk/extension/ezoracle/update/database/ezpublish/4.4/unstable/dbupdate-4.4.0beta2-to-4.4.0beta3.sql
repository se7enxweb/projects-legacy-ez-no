UPDATE ezsite_data SET value='1' WHERE name='ezpublish-release';
UPDATE ezsite_data SET value='4.4.0beta3' WHERE name='ezpublish-version';
