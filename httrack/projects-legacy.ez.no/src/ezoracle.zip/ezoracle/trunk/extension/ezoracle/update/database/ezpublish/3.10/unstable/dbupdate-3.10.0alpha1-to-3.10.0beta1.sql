UPDATE ezsite_data SET value='3.10.0beta1' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='2' WHERE name='ezpublish-release';
