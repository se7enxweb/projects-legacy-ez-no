ALTER TABLE ezcollab_simple_message MODIFY ( data_text1 NULL );
ALTER TABLE ezcollab_simple_message MODIFY ( data_text2 NULL );
ALTER TABLE ezcollab_simple_message MODIFY ( data_text3 NULL );
