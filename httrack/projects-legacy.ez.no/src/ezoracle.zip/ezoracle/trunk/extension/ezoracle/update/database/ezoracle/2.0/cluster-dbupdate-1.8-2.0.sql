ALTER TABLE ezdbfile MODIFY (
  datatype NULL,
  scope NULL );