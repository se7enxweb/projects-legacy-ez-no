UPDATE ezsite_data SET value='3.8.6' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='12' WHERE name='ezpublish-release';