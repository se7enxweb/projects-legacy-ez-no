UPDATE ezsite_data SET value='4.0.8' WHERE name='ezpublish-version';
UPDATE ezsite_data SET value='1' WHERE name='ezpublish-release';
