<?php /* #?ini charset="utf-8"?

[TopAdminMenu]
Tabs[]=fezviewcache

[Topmenu_fezviewcache]
NavigationPartIdentifier=fezviewcachenavigationpart
Name=Manage the cache
Tooltip=Provide an interface to manage cache
URL[]
URL[default]=fezviewcache/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

[NavigationPart]
Part[fezviewcachenavigationpart]=Manage the cache

*/ ?>
