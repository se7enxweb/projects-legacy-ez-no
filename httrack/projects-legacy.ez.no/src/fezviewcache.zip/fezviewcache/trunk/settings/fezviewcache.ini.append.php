<?php /* #?ini charset="utf-8"?

[CacheMethod]
ClearCacheMethod[]
ClearCacheMethod[]=object
ClearCacheMethod[]=parent
ClearCacheMethod[]=relating
ClearCacheMethod[]=keyword
ClearCacheMethod[]=siblings
ClearCacheMethod[]=all

*/ ?>
