<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=fezviewcache
ModuleList[]=fezviewcache

*/ ?>
