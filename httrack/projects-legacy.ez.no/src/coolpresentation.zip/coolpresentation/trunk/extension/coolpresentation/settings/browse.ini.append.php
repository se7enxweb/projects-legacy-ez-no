<?php /* #?ini charset="utf-8"?
[CSPPlace]
StartNode=content
SelectionType=single
ReturnType=NodeID

*/?>