<?php /* #?ini charset="iso-8859-1"?

[ExtensionSettings]
DesignExtensions[]=ezsurvey

[StylesheetSettings]
CSSFileList[]=survey.css

*/ ?>

