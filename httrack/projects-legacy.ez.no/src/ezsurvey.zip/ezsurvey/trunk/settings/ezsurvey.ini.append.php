[PathTextSettings]
#PathText[]=eZ publish
#PathText[]=Surveys

[PathNodeIDSettings]
#PathNodeID[]=2
#PathNodeID[]=SURVEYS_FOLDER_NODE_ID