<?php /* #?ini charset="iso-8859-1"?

#Add the following rules to siteaccess/admin/override.ini.append.php
# admin
#[survey_folder]
#Source=node/view/full.tpl
#MatchFile=survey/list.tpl
#Subdir=templates
#Match[node]=SURVEYS_FOLDER_NODE_ID

#[survey_admin_preview]
#Source=node/view/full.tpl
#MatchFile=admin_preview/survey.tpl
#Subdir=templates
#Match[class_identifier]=survey

#Add the following rule to siteaccess/[your_site_access]/override.ini.append.php
#standard
#[full_survey]
#Source=node/view/full.tpl
#MatchFile=full/survey.tpl
#Subdir=templates
#Match[class_identifier]=survey

*/ ?>
