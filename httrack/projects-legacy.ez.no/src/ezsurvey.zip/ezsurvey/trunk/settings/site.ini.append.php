[TemplateSettings]
ExtensionAutoloadPath[]=ezsurvey

[RegionalSettings]
TranslationExtensions[]=ezsurvey