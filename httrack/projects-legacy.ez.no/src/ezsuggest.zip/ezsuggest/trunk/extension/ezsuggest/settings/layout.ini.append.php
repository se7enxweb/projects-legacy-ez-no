<?php /* #?ini charset="iso-8859-1"?


[ezsuggest]
PageLayout=ezsuggest_pagelayout.tpl
ContentType=text/xml

*/
?>