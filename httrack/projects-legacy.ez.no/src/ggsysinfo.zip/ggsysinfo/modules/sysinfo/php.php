<?php
/**
 *
 * @author G. Giunta
 * @version $Id: php.php 75 2010-09-25 14:03:21Z gg $
 * @copyright (C) G. Giunta 2008-2010
 * @license Licensed under GNU General Public License v2.0. See file license.txt
 */

ob_start();
phpinfo();
$output = ob_get_contents();
ob_end_clean();
$output = preg_replace( array( '#^.*<body>#s','#</body>.*$#s' ), '', $output );

$tpl->setVariable( 'css', 'php.css' );
$tpl->setVariable( 'info', $output );

?>
