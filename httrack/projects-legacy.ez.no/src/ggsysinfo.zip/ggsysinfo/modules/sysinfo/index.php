<?php

$tpl->setVariable( 'groups', sysinfoModule::groupList() );

?>