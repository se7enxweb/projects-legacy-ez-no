<?php
// This view is empty: all work is done by the template
?>