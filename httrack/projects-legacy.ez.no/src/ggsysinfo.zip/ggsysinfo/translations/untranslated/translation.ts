<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>SysInfo</name>
    <message>
        <source>Cache search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cache stats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Storage stats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Storage churn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content stats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log stats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log churn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Policy Functions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fetch Functions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Template Operators</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content classes definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regexp search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select file for removal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove all cache files found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attribute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total size (bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Structure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Identifize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datatype</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translatable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Info Collector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Searchable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Call method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limitations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>KO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Positional parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Named parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post action parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Required Policy Functions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Doc Content class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>messages per </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>files per </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/content/draft</name>
    <message>
        <source>Invert selection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to remove all cache files found?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/bfbp_sonde</name>
    <message>
        <source>%test% connection</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
