<?php /*

[ModuleSettings]
ExtensionRepositories[]=ggsysinfo

ModuleList[]=sysinfo

*/?>