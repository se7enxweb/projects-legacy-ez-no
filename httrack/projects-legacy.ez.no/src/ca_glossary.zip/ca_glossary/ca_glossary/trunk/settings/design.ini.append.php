<?php /* #?ini charset="utf-8"?

[StylesheetSettings]
CSSFileList[]=ca_glossary.css

[ExtensionSettings]
DesignExtensions[]=ca_glossary

*/ ?>
