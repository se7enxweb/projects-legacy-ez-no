<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ca_glossary

[RegionalSettings]
TranslationExtensions[]=ca_glossary

*/ ?>