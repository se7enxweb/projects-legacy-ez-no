<?php /* #?ini charset="utf-8"?

[ezjscServer]
FunctionList[]=ezjscngpush

[ezjscServer_ezjscngpush]
Class=ezjscoreNGPush
TemplateFunction=false
File=extension/ngpush/classes/ezjscorengpush.php
*/ ?>
