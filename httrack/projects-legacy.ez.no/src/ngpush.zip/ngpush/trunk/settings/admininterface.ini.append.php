<?php /* #?ini charset="utf-8"?

[AdditionalMenuSettings]
ContextMenuTemplateArray[]=popupmenu/pushcontextmenu.tpl
SubitemsContextMenuTemplateArray[]=popupmenu/pushsubitemscontextmenu.tpl
*/ ?>
