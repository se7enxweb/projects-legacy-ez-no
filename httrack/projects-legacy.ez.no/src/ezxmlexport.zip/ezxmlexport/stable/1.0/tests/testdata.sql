INSERT INTO ezxmlexport_available_contentclasses VALUES (1);
INSERT INTO ezxmlexport_available_contentclass_attributes VALUES (4, 1);
INSERT INTO ezxmlexport_available_contentclass_attributes VALUES (119, 1);
INSERT INTO ezxmlexport_available_contentclass_attributes VALUES (155, 1);
INSERT INTO ezxmlexport_available_contentclass_attributes VALUES (156, 1);
INSERT INTO ezxmlexport_available_contentclass_attributes VALUES (158, 1);
INSERT INTO ezxmlexport_exports VALUES (1, 2, 'test xml export', 'test xml export', 'a:1:{i:0;s:1:"2";}', 'a:5:{s:4:"host";s:15:"ftp.mozilla.org";s:4:"port";s:2:"21";s:5:"login";s:9:"anonymous";s:8:"password";s:12:"nospam@ez.no";s:4:"path";s:4:"/pub";}', '1', '1255989600', '1264892400', 'a:0:{}', -1, 1, 1, 1, 'test.xsl', 1);
INSERT INTO ezxmlexport_customers VALUES (2, 'ez', 'a:5:{s:4:"host";s:15:"ftp.mozilla.org";s:4:"port";s:2:"21";s:5:"login";s:9:"anonymous";s:8:"password";s:12:"nospam@ez.no";s:4:"path";s:4:"/pub";}', '1');
