<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=ezxmlexport

[JavaScriptSettings]
JavaScriptList[]=yui/build/yahoo/yahoo-min.js
JavaScriptList[]=yui/build/event/event-min.js
JavaScriptList[]=yui/build/connection/connection-min.js
JavaScriptList[]=ezxmlexport_contentclasses.js
JavaScriptList[]=yui/build/dom/dom-min.js
JavaScriptList[]=calendar.js

[StylesheetSettings]
CSSFileList[]=ftprelated.css

*/
?>
