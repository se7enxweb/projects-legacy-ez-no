<?php /* #?ini charset="utf-8"?

[BrowseXMLExport]
StartNode=content
SelectionType=multiple
ReturnType=NodeID
*/
?>
