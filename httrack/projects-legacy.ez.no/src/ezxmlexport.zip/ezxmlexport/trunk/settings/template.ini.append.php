<?php /* #?ini charset="utf-8"?
[PHP]
PHPOperatorList[unserialize]=unserialize
*/
?>
