<?php /* #?ini charset="utf-8"?

[ezxmlexport_browse]
Source=content/browse.tpl
MatchFile=content/browse.tpl
Subdir=templates
Match[navigation_part_identifier]=ezcontentnavigationpart

[ezxmlexport_browse_mode_list]
Source=content/browse_mode_list.tpl
MatchFile=content/browse_mode_list.tpl
Subdir=templates
Match[navigation_part_identifier]=ezcontentnavigationpart

[ezxmlexport_browse_mode_thumbnail]
Source=content/browse_mode_thumbnail.tpl
MatchFile=content/browse_mode_thumbnail.tpl
Subdir=templates
Match[navigation_part_identifier]=ezcontentnavigationpart

*/ ?>
