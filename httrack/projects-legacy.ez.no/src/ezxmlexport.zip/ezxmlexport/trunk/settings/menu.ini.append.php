<?php /* #?ini charset="utf-8"?
[Leftmenu_setup]
Links[xmlexport]=xmlexport/menu
LinkNames[xmlexport]=XML Export

*/
?>