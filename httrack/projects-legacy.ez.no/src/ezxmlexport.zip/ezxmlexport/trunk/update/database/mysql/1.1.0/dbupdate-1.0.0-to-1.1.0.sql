ALTER TABLE `ezxmlexport_available_contentclass_attributes` RENAME `ezxport_available_cclass_attr`;
ALTER TABLE `ezxmlexport_available_contentclasses` RENAME `ezxport_available_cclasses`;
ALTER TABLE `ezxmlexport_customers` RENAME `ezxport_customers` ;
ALTER TABLE `ezxmlexport_export_object_log` RENAME `ezxport_export_object_log`;
ALTER TABLE `ezxmlexport_exports` RENAME `ezxport_exports` ;
ALTER TABLE `ezxmlexport_process_logs` RENAME `ezxport_process_logs`;