<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=ezjssumtype
AvailableDataTypes[]=ezjssum


*/ ?>