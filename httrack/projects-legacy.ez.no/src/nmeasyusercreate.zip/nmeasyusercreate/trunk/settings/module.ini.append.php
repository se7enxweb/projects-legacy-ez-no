<?php
/*

[ModuleSettings]
ExtensionRepositories[]=nmeasyusercreate

*/
?>
