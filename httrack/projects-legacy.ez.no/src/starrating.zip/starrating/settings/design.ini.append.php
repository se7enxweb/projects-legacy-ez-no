<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=starrating

[StylesheetSettings]
CSSFileList[]=star_rating.css

[JavaScriptSettings]
JavaScriptList[]=yui/build/yahoo-dom-event/yahoo-dom-event.js
*/ ?>

