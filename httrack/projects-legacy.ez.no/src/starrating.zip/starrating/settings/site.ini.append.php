<?php /* #?ini charset="utf-8"?

[RoleSettings]
PolicyOmitList[]=starrating/collect
PolicyOmitList[]=xajax

*/ ?>
