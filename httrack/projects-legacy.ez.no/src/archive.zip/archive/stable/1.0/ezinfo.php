<?php
class ezarchiveInfo
{
    static function info()
    {
        return array( 'Name' => "Archive",
                      'Version' => "1.0.1",
                      'Copyright' => "Łukasz Serwatka",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>
