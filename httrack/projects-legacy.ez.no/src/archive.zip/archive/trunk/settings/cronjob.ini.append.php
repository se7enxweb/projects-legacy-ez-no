<?php /*

[CronjobSettings]
ExtensionDirectories[]=archive

[CronjobPart-archive]
Scripts[]=archive.php

*/ ?>