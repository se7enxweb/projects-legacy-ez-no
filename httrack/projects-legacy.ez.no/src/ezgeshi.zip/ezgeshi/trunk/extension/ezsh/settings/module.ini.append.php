<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezsh

ModuleList[]=geshi

*/?>