<?php /*

#[RelateCreatorSettings]
#GlobalOverwrite=enabled|disabled
#RelateClasses[]=<class_identifier>

#UserAccountAttribute=<attribute_name>

#DefaultRelationAttribute=<attribute_name>
#DefaultNameAttribute=<attribute_name>

#RelationAttributes[<content_class>]=<attribute_name>
#NameAttributes[<content_class>]=<attribute_name>

*/ ?>


