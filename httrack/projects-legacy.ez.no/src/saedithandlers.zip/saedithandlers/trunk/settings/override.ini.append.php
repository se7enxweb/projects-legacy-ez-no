<?php /* #?ini charset="utf-8"?

[edit_locations_saeasylocations]
Source=content/edit_locations.tpl
MatchFile=content/edit_saeasylocations.tpl
Subdir=templates

*/ ?>
