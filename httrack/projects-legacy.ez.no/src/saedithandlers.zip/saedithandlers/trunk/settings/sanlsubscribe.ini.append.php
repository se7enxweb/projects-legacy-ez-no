<?php /*

[SubscribeSettings]
UserClasses[]=user
FirstNameAttributes[user]=first_name
SecondNameAttributes[user]=last_name
AccountAttributes[user]=user_accunt
#ReceiveNewsletterAttributes[<class_identifier>]=<attribute_identifier>
#ParentListIDAttribute=<attribute_identifier>

*/ ?>
