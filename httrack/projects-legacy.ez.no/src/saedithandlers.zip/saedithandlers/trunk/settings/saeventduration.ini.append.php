<?php /*

[EventDurationSettings]
#EventClasses[]=article
#EventClasses[]=news

DefaultStartDateAttribute=date_start
DefaultEndDateAttribute=date_end

#StartDateAttributes[<class_identifier>]=<attribute_name>
#EndDateAttributes[<class_identifier>]=<attribute_name>

*/ ?>


