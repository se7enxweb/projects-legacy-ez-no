<?php /*

[AttributeMetaSettings]
UseAllClasses=false
#MetaDataClasses[]=article
#MetaDataClasses[]=news

#MetaDataAttributes[]=<class_identifier>/<attribute_identifier>|<class_attribute_id>


*/ ?>


