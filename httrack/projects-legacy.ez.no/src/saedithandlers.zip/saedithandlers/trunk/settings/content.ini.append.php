<?php /*

[EditSettings]
ExtensionDirectories[]=saedithandlers

*/ ?>
