<?php /*

[PublishDateSettings]
UseAllClasses=false
#DateClasses[]=article
#DateClasses[]=news

DefaultFillEmptyAttribute=false
DefaultDateAttribute=date

#DateAttributes[<class_identifier>]=<attribute_name>
#FillEmptyAttributes[<class_identifier>]=true|false

*/ ?>


