eZ Survey extension 2.1 README

What is the eZ Survey extension?
================================

Survey module for eZ Publish


eZ Survey version
=======================

The current version of eZ Survey is 2.1.
You can find details about changes for this version in
doc/changelogs/CHANGELOG-2.0-to-2.1.


License
=======

This software is licensed under the GPL. The complete
license agreement is included in the LICENSE file. For more information
or questions please contact info@ez.no


Requirements
============

The following requirements exists for using eZ Survey extension:

o  eZ Publish version:

   Make sure you use eZ Publish version 4.0 or higher.

o  PHP version:

   Make sure you have PHP 5.1 or higher.


Installation
============
Please read the INSTALL file for installation instructions.


Troubleshooting
===============

1. Read the FAQ
   ------------

   Some problems are more common than others. The most common ones are listed
   in the the FAQ.

2. Support
   -------

   If you have find any problems not handled by this document or the FAQ you
   can contact eZ system trough the support system:
   http://ez.no/services/support
