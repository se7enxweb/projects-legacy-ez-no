<?php

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezmailhide/autoloads/ezmailhideutils.php',
                                    'class' => 'eZMailHideUtils',
                                    'operator_names' => array( 'ezmailhide' ) );


?>
