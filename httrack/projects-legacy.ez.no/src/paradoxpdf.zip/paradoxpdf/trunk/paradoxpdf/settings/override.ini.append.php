<?php /** #?ini charset="utf-8"?

[ParadoxPDF]
Source=pagelayout.tpl
MatchFile=paradoxpdf_layout.tpl
Subdir=templates
Match[viewmode]=pdf

*/ ?>