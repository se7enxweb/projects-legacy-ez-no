Paradoxpdf is built uppon xhtmlrendrer alias Flying Saucer https://xhtmlrenderer.dev.java.net

Flying Saucer is distributed under the LGPL.Flying Saucer itself is licensed
under the GNU Lesser General Public License, version 2.1 or later, available at
http://www.gnu.org/copyleft/lesser.html. You can use Flying Saucer in any
way and for any purpose you want as long as you respect the terms of the
license. A copy of the LGPL license is included as license-lgpl-2.1.txt
in our distributions and in our source tree.

Paradoxpdf is distributed under the GPL;
Paradoxpdf  is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

