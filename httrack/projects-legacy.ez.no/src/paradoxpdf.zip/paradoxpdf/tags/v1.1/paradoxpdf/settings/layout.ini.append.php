<?php /** #?ini charset="utf-8"?

[pdf]
PageLayout=paradoxpdf_layout.tpl
UseAccessPass=false

*/ ?>