<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=xroweventmanager
ModuleList[]=xrowevent

*/ ?>
