<?php
class xroweventmanagerInfo
{
    function info()
    {
        return array( 'Name' => "xrow eventmanager",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) xrow GbR",
                      'Author' => 'Georg Franz',
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>