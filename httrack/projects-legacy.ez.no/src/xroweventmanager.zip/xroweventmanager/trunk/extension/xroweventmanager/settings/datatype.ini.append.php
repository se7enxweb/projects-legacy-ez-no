<?php /* #?ini charset="utf-8"?

[ViewSettings]
GroupedInput[]=xrowevent

[EditSettings]
GroupedInput[]=xrowevent

*/ ?>