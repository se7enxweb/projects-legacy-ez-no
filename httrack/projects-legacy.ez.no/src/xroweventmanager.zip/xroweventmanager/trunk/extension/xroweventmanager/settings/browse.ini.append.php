<?php /* #?ini charset="utf-8"?

[BrowsePersonList]
StartNode=users
SelectionType=multiple
ReturnType=ObjectID
Class[]
Class[]=user

*/ ?>