<?php /* #?ini charset="utf-8"?

[XrowEventManagerSettings]
# Max. character length of comments of event participants
CommentLength=500

*/ ?>