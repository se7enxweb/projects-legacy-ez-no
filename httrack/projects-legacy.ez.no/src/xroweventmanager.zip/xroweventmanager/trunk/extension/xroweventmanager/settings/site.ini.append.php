<?php /* #?ini charset="utf-8"?

[RoleSettings]
#PolicyOmitList[]=

[RegionalSettings]
TranslationExtensions[]=xroweventmanager

*/ ?>