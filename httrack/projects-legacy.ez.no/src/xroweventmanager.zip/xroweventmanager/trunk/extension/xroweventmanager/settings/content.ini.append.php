<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=xroweventmanager
AvailableDataTypes[]=xrowevent

*/ ?>