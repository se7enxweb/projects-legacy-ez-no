<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[xroweventmanager]=Events

[TopAdminMenu]
Tabs[]=xroweventmanager

[Topmenu_xroweventmanager]
NavigationPartIdentifier=xroweventmanager
Tooltip=Manage your events
Name=Events
URL[]
URL[default]=xrowevent/list
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Enabled[event]=true
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=false
Shown[event]=true

*/ ?>