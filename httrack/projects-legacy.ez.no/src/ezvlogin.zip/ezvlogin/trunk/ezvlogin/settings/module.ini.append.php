<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=ezvlogin
ModuleList[]=vlogin

*/
?>
