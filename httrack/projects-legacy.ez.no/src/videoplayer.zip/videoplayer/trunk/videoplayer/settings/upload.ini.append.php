<?php /* #?ini charset="utf-8"?

[CreateSettings]
MimeClassMap[video/x-flv]=flash_video

[flash_video_ClassSettings]
FileAttribute=file
NameAttribute=name
NamePattern=<original_filename_base>
?>
