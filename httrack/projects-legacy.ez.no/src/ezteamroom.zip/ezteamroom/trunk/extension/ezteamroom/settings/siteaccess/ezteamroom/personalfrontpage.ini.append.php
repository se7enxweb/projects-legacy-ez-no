<?php /* #?ini charset="utf-8"?

[WidgetSettings]
ShowAsList[]=personal_frontpage
ShowAsList[]=teamroom_personal_frontpage

DisabledContentClasses[]
DisabledContentClasses[]=frontpage
DisabledContentClasses[]=teamroom_frontpage

[WidgetTemplateSettings]
UseUserTemplateAsList[personal_frontpage]=line
UseUserTemplateAsList[teamroom]=line
UseUserTemplateAsList[teamroom_personal_frontpage]=line
UseUserTemplateAsList[teamroom_room]=line


*/ ?>
