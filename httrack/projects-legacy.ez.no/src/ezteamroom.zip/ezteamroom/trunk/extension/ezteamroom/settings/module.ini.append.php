<?php /* #?ini charset="iso-8859-1"?

[ModuleSettings]
ExtensionRepositories[]=ezteamroom
ModuleList[]=tasklist
ModuleList[]=teamroom
ModuleList[]=filelist

*/ ?>
