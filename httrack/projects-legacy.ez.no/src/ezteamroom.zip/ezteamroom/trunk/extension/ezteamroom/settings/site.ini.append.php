<?php /*

[SiteSettings]
RootNodeDepth=1

[TemplateSettings]
ExtensionAutoloadPath[]=ezteamroom

[RegionalSettings]
TranslationExtensions[]=ezteamroom

*/ ?>
