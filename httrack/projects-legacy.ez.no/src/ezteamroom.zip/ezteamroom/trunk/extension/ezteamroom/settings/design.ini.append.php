<?php /* #?ini charset="utf-8"?
# eZ publish configuration file for modules

[ExtensionSettings]
DesignExtensions[]=ezteamroom

[JavaScriptSettings]
JavaScriptList[]=editfunctions.js
JavaScriptList[]=ezmultiupload.js

[StylesheetSettings]
CSSFileList[]=yui/build/calendar/assets/calendar.css

*/ ?>
