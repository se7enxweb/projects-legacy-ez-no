<?php /* #?ini charset="iso-8859-1"?

[XMLInstallerSettings]
ExtensionDirectories[]=ezteamroom
XMLInstallerHandler[]=ezcheckteamroomrequirements

*/?>
