<?php /*

[CronjobSettings]
ExtensionDirectories[]=ezteamroom

[CronjobPart-cleanup_users]
Scripts[]
Scripts[]=cleanup_users.php

[CronjobPart-import_mail]
Scripts[]
Scripts[]=teamroom_mail_import.php

*/ ?>
