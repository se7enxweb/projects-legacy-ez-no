<?php /* #?ini charset="iso-8859-1"?


[OperationSettings]
AvailableOperationList[]=teamroom_register
# This will slow down all other siteaccesses
# Commented in, and moved the activation to the
# teamroom siteaccess settings
# AvailableOperationList[]=content_read

[EventSettings]
ExtensionDirectories[]=ezteamroom
AvailableEventTypes[]=event_ezsetsection
AvailableEventTypes[]=event_ezsetteamroom
AvailableEventTypes[]=event_ezapprovememberregistration

*/ ?>
