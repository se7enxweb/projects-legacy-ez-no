<?php /* #?ini charset="iso-8859-1"?

[HandlerSettings]
Extensions[]=ezteamroom
Active[]
Active[]=ezapprovememberregistration

*/ ?>
