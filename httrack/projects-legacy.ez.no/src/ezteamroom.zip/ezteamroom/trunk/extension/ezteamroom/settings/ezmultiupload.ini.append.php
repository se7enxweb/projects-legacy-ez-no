<?php /*

[MultiUploadSettings]
AvailableClasses[]=file_folder
AvailableClasses[]=teamroom_file_folder
AvailableClasses[]=teamroom_file_subfolder

[FileTypeSettings_file_folder]
FileType[]
FileType[]=*.*

[FileTypeSettings_teamroom_file_folder]
FileType[]
FileType[]=*.*

*/ ?>
