<?php /* #?ini charset="iso-8859-1"?

[CommonSettings]
UserSendOwnLightbox=enabled
UseShop=disabled

*/ ?>
