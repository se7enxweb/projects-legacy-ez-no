<?php /* #?ini charset="utf-8"?

[WebsiteToolbarSettings]
AvailableForClasses[]=personal_frontpage
AvailableForClasses[]=teamroom
AvailableForClasses[]=teamroom_personal_frontpage
AvailableForClasses[]=teamroom_room

*/ ?>
