<?php /* #?ini charset="utf-8"?

[TreeMenu]
ToolTips=disabled
ShowClasses[]
ShowClasses[]=folder
ShowClasses[]=documentation_page
ShowClasses[]=frontpage
ShowClasses[]=forums
ShowClasses[]=teamroom_documentation_page
ShowClasses[]=teamroom_frontpage
ShowClasses[]=teamroom_forums

*/ ?>
