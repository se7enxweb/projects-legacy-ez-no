<?php /* #?ini charset="utf-8"?

[AliasSettings]
AliasList[]=thumbnail
AliasList[]=tiny
AliasList[]=small
AliasList[]=userthumbnail

[thumbnail]
Reference=original
Filters[]
Filters[]=geometry/scaledownonly=120;

[tiny]
Reference=original
Filters[]
Filters[]=geometry/scaledownonly=30;

[small]
Reference=original
Filters[]
Filters[]=geometry/scaledownonly=60;60

[userthumbnail]
Reference=original
Filters[]
Filters[]=geometry/scaledownonly=75;150

*/ ?>