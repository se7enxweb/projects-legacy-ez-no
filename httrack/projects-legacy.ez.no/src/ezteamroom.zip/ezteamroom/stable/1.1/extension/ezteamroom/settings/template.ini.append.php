<?php /* #?ini charset="utf-8"?

[PHP]
#PHPOperatorList[mktime]=mktime
PHPOperatorList[striptags]=strip_tags
PHPOperatorList[html_entity_dee]=html_entity_decode
PHPOperatorList[urlencode]=rawurlencode
PHPOperatorList[urldecode]=rawurldecode
PHPOperatorList[array_flip]=array_flip

*/ ?>
