<?php /*

[SelectSkeleton]
StartNode=content
SelectionType=single
ReturnType=NodeID

[AddSkeletonUserGroups]
SelectionType=multiple
ReturnType=NodeID
Class[]
Class[]=user_group

[SelectInviteUsers]
StartNode=12
SelectionType=multiple
ReturnType=ObjectID
Class[]
Class[]=user

[AddBookmark]
StartNode=2
SelectionType=multiple
ReturnType=NodeID

*/ ?>