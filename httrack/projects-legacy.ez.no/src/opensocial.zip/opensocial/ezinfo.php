<?php

class opensocialInfo
{
    function info()
    {
        return array( 'name' => "OpenSocial stuff",
                      'version' => "0.0000000000001",
                      'copyright' => "Copyright (C) 2007 Paul Forsyth",
                      'license' => "GNU General Public License v2.0"
                    );
    }
}
?>
