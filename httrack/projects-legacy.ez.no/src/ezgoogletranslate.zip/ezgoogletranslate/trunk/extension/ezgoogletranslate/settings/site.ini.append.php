<?php /*

[RegionalSettings]
TranslationExtensions[]=ezgoogletranslate

[Cache_sysinfo]
name=eZGooleTransdlate auth tokens cache
path=ezgoogletranlsate

*/ ?>
