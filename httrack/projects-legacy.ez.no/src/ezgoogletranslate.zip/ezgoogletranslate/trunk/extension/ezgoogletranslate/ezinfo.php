<?php

class ezgoogletranslateInfo
{
    static function info()
    {
        return array(
            'Name' => "eZ Google Translate",
            'Version' => "0.2",
            'Copyright' => "Copyright (C) Gaetano Giunta 2009-2012",
            'License' => "GNU General Public License v2.0"
            )
        );
    }
}

?>