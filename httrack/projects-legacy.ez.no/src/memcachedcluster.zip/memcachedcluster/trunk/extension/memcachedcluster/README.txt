﻿eZ publish memcached cluster
============================

:Status: alpha (proof of concept)
:Author: Bertrand Dunogier <bd@ez.no>

This extensions aims at speeding up eZ publish cluster by integrating a memcache
server between the CMS and the cluster database.

Features
--------

Auto memcache updates using MySQL triggers
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
MySQL triggers are used to update the memcache server with fresh data upon update.
This method is supposed to avoid wasting valuable resources, since it can be
time consuming to determine what files are updated by eZ publish in the cluster,
especially when a large set of files are updated.

This feature requires custom User Defined Functions to be used in MySQL. See
INSTALL file for more details.

Read data from memcache at runtime
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Once the appropriate cluster file handler has been configured, files metadata
will first be read from memcache, and if not available, read from DB (as usual).