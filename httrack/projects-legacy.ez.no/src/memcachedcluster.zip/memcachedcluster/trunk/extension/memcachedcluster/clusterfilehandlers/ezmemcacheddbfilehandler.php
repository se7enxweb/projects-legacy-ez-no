<?php
class eZMemcachedDBFileHandler extends eZDBFileHandler
{
	function loadMetaData( $force = false )
	{
		// Fetch metadata.
		if ( $this->filePath === false )
			return;

		// we don't fetch metaData if self::metaData === false, since this means
		// we already tried and got no results, unless $force == true
		if ( ( $this->metaData === false ) && ( $force !== true ) )
			return;

		if ( $force && isset( $GLOBALS['eZClusterInfo'][$this->filePath] ) )
			unset( $GLOBALS['eZClusterInfo'][$this->filePath] );

		// Checks for metadata stored in memory, useful for repeated access
		// to the same file in one request
		// TODO: On PHP5 turn into static member
		if ( isset( $GLOBALS['eZClusterInfo'][$this->filePath] ) )
		{
			$GLOBALS['eZClusterInfo'][$this->filePath]['cnt'] += 1;
			$this->metaData = $GLOBALS['eZClusterInfo'][$this->filePath]['data'];
			return;
		}

		$memcache = eZMemcachedHandler::instance();
		if ( $metaData = $memcache->get( md5( $this->filePath ) ) )
		{
			eZDebug::writeDebug( "Loaded metadata for {$this->filePath}", __METHOD__ );
			eZLog::write( "[memcachedcluster] Loaded metadata for {$this->filePath}", 'cluster.log' );
			$this->metaData = $metaData;
		}
		else
		{
			eZDebug::writeDebug( "No metadata for {$this->filePath}, falling back to DB", __METHOD__ );
			eZLog::write( "[memcachedcluster] No metadata for {$this->filePath}, falling back to DB", 'cluster.log' );
			parent::loadMetaData( $force );
		}


		// Clean up old entries if the maximum count is reached
		if ( isset( $GLOBALS['eZClusterInfo'] ) &&
			count( $GLOBALS['eZClusterInfo'] ) >= self::INFOCACHE_MAX )
		{
			usort( $GLOBALS['eZClusterInfo'],
			       create_function( '$a, $b',
			                        '$a=$a["cnt"]; $b=$b["cnt"]; if ( $a > $b ) return -1; else if ( $a == $b ) return 0; else return 1;' ) );
			array_pop( $GLOBALS['eZClusterInfo'] );
		}
		$GLOBALS['eZClusterInfo'][$this->filePath] = array( 'cnt' => 1,
		                                                    'data' => $metaData );
	}

	/**
	 * Check if given file/dir exists.
	 *
	 * NOTE: this function does not interact with database.
	 * Instead, it just returns existance status determined in the constructor.
	 *
	 * \public
	 */
	function exists()
	{
		$memcache = eZMemcachedHandler::instance();

		$path = $this->filePath;
		eZDebugSetting::writeDebug( 'kernel-clustering', "db::exists( '$path' )" );
		if ( $metaData = $memcache->get( md5( $path ) ) )
		{
			return ( $metaData['mtime'] > 0 );
		}
		else
		{
			return parent::exists();
		}
	}
}
?>