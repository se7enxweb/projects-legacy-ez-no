<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[ezgoogleanalytics]=Google Analytics

[TopAdminMenu]
# Activate the Google Analytics tab here to show the tab
#Tabs[]=ezgoogleanalytics

[Topmenu_ezgoogleanalytics]
NavigationPartIdentifier=ezgoogleanalytics
Name=Google Analytics
Tooltip=Google Analytics administration interface menu
URL[]
URL[default]=googleanalytics/admin
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>
