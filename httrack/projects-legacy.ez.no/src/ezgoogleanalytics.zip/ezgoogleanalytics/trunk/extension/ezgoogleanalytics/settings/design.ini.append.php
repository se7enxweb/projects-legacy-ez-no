<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=ezgoogleanalytics

[StylesheetSettings]
#CSSFileList[]=

[JavaScriptSettings]
#JavaScriptList[]=sleep.js

*/ ?>