<?php
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ezgoogleanalytics/autoloads/googleanalyticsoperators.php',
                                    'class' => 'GoogleAnalyticsOperators',
                                    'operator_names' => array( 'googleanalytics_tracker' ) );
?>