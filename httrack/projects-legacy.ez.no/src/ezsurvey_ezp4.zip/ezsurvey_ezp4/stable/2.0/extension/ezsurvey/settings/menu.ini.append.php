<?php  /* #?ini charset="utf-8"?
         
[NavigationPart]
Part[ezsurveynavigationpart]=Survey

[TopAdminMenu]
Tabs[]=survey

[Topmenu_survey]
Name=Survey
Tooltip=Add your own survey.
URL[]
URL[default]=survey/list
URL[browse]=survey/list
NavigationPartIdentifier=ezsurveynavigationpart

Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=false

*/ ?>
