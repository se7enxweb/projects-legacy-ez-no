<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=ezsurvey

[RegionalSettings]
TranslationExtensions[]=ezsurvey

*/ ?>