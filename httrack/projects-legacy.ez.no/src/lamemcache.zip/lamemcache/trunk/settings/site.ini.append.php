<?php /*
[TemplateSettings]
ExtensionAutoloadPath[]=lamemcache
ModuleList[]=laface
*/ ?>