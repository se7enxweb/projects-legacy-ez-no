<?php /* #?ini charset="iso-8859-1"?
[ModuleSettings]
ExtensionRepositories[]=lamemcache
ModuleList[]=lamemcache
*/
?>

