<?php /* #?ini charset="utf-8"?
# eZ publish configuration file for modules

[ExtensionSettings]
DesignExtensions[]=ezflashtagcloud

# List of javascripts to use in footer
[JavaScriptSettings]
JavaScriptList[]=swfobject.js

*/ ?>
