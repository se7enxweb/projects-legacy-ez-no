<?php /*

[NavigationPart]
Part[aidnavigationpart]=AdminAid

[TopAdminMenu]
Tabs[]=aid

[Topmenu_aid]
Name=AdminAid
NavigationPartIdentifier=aidnavigationpart
URL[]
URL[default]=aid/search
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>
