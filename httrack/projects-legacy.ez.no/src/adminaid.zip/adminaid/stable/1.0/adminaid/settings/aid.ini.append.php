<?php /* #?ini charset="utf-8"?

[Aid]
# Only users with ID listed here can use user switch function
UserSwitchIDLimit[]
UserSwitchIDLimit[]=14

# Classes representing a user
UserClass[]
UserClass[]=user

*/ ?>
