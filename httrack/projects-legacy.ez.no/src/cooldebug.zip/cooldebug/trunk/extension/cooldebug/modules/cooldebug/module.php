<?php


$Module = array( 'name' => 'cooldebug' );
$ViewList = array();
$ViewList['nodeattribute'] = array(    'script' => 'node_attribute.php', 'params' => array ( 'NodeID' , 'LevelDeep' ) );

$FunctionList['nodeattribute'] = array( );
?>