<?php
/*
[TemplateSettings]
ExtensionAutoloadPath[]=cooldebug


*/
?>