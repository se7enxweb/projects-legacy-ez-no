<?php

// Operator autoloading

$eZTemplateOperatorArray = array();


$eZTemplateOperatorArray[] = array( 'script' => 'extension/cooldebug/autoloads/eztemplatecoolattributeoperator.php',
                                    'class' => 'eZTemplateCoolAttributeOperator',
                                    'operator_names' => array( 'coolattribute' ) );
?>