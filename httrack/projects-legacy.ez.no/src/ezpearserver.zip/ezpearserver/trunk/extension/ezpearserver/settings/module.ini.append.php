<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezpearserver
ModuleList[]=pear

*/ ?>
