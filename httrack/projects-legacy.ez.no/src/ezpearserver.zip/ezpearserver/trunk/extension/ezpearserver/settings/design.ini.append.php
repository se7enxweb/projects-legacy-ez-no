<?php /*

[ExtensionSettings]
DesignExtensions[]=ezpearserver

*/ ?>
