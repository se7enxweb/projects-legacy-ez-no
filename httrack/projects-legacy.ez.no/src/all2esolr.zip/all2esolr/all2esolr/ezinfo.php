<?php
class all2esolrInfo
{
    static function info()
    {
        return array( 'Name' => "all2e solr index after content move",
                      'Version' => "1.0.0",
                      'Copyright' => "Copyright (C) 2011 <a href='http://www.all2e.com/'>all2e GmbH</a>",
                      'Author' => 'Mark Simon',
                      'License' => "GNU General Public License v2.0"
                    );
    }
}
?>
