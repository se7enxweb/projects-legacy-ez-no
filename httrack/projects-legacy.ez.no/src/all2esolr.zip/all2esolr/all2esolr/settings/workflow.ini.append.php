<?php /*

[OperationSettings]
AvailableOperationList[]=content_move

[EventSettings]
ExtensionDirectories[]=all2esolr
AvailableEventTypes[]=event_indexaftermove

*/ ?>
