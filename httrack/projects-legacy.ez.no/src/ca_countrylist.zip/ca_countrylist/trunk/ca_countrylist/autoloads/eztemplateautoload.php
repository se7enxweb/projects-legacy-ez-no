<?php
$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ca_countrylist/autoloads/countryinfooperator.php',
                                    'class' => 'CountryInfoOperator',
                                    'operator_names' => array( 'fetch_country_list' ) );