<?php /* #?ini charset="utf-8"?

[RegionalSettings]
TranslationExtensions[]=ca_countrylist

[TemplateSettings]
ExtensionAutoloadPath[]=ca_countrylist

 */ ?>