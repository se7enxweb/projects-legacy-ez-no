<?php
/* 
[DataTypeSettings]
ExtensionDirectories[]=ca_countrylist
AvailableDataTypes[]=countrylist
 */

?>