<?php
class eZExpireCacheBlockType  extends eZWorkflowEventType
{
    const WORKFLOW_TYPE_STRING = "ezexpirecacheblock";

    function eZExpireCacheBlockType()
    {
        $this->eZWorkflowEventType( self::WORKFLOW_TYPE_STRING, ezi18n( 'extension/ezcacheblockexpirer', "Expire cache blocks" ) );
        $this->setTriggerTypes( array( 'content' => array( 'publish' => array( 'after' ) ) ) );
    }

    function execute( $process, $event )
    {
        $parameters = $process->attribute( 'parameter_list' );
        $object = eZContentObject::fetch( $parameters['object_id'] );

        $subtrees = array();
        $ini = eZINI::instance( 'cacheblockexpirer.ini' );

        // we create an indexed array of subtree => array( $groups )
        foreach ( $ini->groups() as $iniGroupName => $iniGroupContents )
        {
            foreach ( $iniGroupContents['Subtrees'] as $subtree )
                if ( isset( $subtrees[$subtree] ) )
                    $subtrees[$subtree][] = $iniGroupName;
                else
                    $subtrees[$subtree] = array( $iniGroupName );
        }

        // loop over object's locations, and for each location,
        // loop over subtrees
        $objectClassIdentifier = $object->contentClassIdentifier();
        $clearCacheObjects = array();
        foreach ( $object->assignedNodes() as $objectNode )
        {
            $pathString = $objectNode->attribute( 'path_string' );
            foreach ( $subtrees as $subtree => $groups )
            {
                if ( strlen( $pathString ) > strlen( $subtree ) )
                {
                    // the subtree matches: we can check the content class
                    if ( substr( $pathString, 0, strlen( $subtree ) ) == $subtree )
                    {
                        // we now check the object's class identifier
                        foreach ( $groups as $group )
                        {
                            $groupClassIdentifiers = $ini->variable( $group, 'ClassIdentifiers' );
                            if ( in_array( $objectClassIdentifier, $groupClassIdentifiers ) )
                            {
                                $clearCacheObjectID = $ini->variable( $group, 'ClearCacheObject' );
                                eZDebugSetting::writeNotice( 'extension-ezcacheblockexpirer', $clearCacheObjectID, '[eZExpireCacheBlockType::execute()] Clearing cache block for object' );
                                eZContentCacheManager::clearTemplateBlockCache( $clearCacheObjectID );
                            }
                        }
                    }
                }
            }
        }

        // if the location matches the subtree, check if the content object's
        // class belongs to the content classes list for this subtree
        return eZWorkflowType::STATUS_ACCEPTED;
    }
}

eZWorkflowEventType::registerEventType( eZExpireCacheBlockType::WORKFLOW_TYPE_STRING, "eZExpireCacheBlockType" );
?>