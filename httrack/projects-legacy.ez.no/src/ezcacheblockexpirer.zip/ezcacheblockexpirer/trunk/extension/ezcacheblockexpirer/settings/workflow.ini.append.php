﻿<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=ezcacheblockexpirer
AvailableEventTypes[]=event_ezexpirecacheblock

*/ ?>