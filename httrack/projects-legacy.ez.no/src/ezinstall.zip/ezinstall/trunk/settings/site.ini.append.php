<?php /* #?ini charset="utf-8"?

[RegionalSettings]
TranslationExtensions[]=ezrole

[RoleSettings]
PolicyOmitList[]=ezrole/action

*/ ?>
