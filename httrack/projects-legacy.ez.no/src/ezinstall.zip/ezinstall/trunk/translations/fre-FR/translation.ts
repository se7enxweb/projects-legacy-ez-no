<!DOCTYPE TS><TS>
<context>
    <name>design/admin/role/list</name>
    <message>
        <source>Import Role</source>
        <translation>Importer un rôle</translation>
    </message>
    <message>
        <source>Import a new role.</source>
        <translation>Importer un nouveau rôle</translation>
    </message>
    <message>
        <source>Export Role</source>
        <translation>Exporter un rôle</translation>
    </message>
    <message>
        <source>Export a role.</source>
        <translation>Exporter un rôle</translation>
    </message>
</context>
</TS>
