<?php

$Module = array( 'name' => 'ezfire' );
$ViewList = array();
$ViewList['firetest'] = array( 'script' => 'firetest.php', 'params' => array () );

?>
