<?php /* #?ini charset="utf-8"?

[eZFireSettings]
#If this isn't set, then nothing is sent to the FireBug interface
FireDebug=enabled

DebugLevel=INFO
DefaultDepth=6
DefaultTestNode=54
#This goes to the Display
DumpToScreen=disabled
#Debug output to a file 
DumpToFile=enabled
#This goes to a File
DebugFile=/tmp/ezfire.txt

*/ ?>