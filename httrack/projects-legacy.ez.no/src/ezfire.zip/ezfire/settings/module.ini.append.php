<?php /* #?ini charset="iso-8859-1"?

[ModuleSettings]
ExtensionRepositories[]=ezfire
ModuleList[]=ezfire

*/ ?>
