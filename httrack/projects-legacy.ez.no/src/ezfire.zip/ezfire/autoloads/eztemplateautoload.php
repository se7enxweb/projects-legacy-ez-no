<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] =
	array( 'script' => 'extension/ezfire/autoloads/eztemplatefireoperator.php',
                            'class' => 'FireOperator',
                            'operator_names' => array( 'fire','ezfire' ) );
?>
