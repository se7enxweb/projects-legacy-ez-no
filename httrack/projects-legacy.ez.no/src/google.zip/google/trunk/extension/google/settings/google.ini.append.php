<?php /* #?ini charset="utf-8"?
# Documentation on Google Search protocol
# http://code.google.com/enterprise/documentation/xml_reference.html#results_xml_tag_m

[GoogleSettings]
URL=http://googleserver.example.com/search
# Protocol parameter client
DefaultFrontend=website
#Enable the following collections to be included in the search result.
#Collections[]
#Collections[]=mywebsite
#Collections[]=otherwebsite
*/ ?>