<?php /*

[ModuleSettings]
ExtensionRepositories[]=csmailcheck
ModuleList[]=mailcheck

*/ ?>