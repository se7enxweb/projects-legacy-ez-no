<? /*
[ExtensionSettings]
DesignExtensions[]=csmailcheck

[JavaScriptSettings]
JavaScriptList[]=jquery.min.js
JavaScriptList[]=csmailcheck.js

[StylesheetSettings]
CSSFileList[]=csmailcheck.css

*/ ?>