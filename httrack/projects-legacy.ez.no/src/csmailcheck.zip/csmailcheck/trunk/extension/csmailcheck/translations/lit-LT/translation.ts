<!DOCTYPE TS><TS>
<context>
    <name>csmailcheck/loginform</name>
    <message>
        <source>Username</source>
        <translation>Vartotojo vardas</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Slaptažodis</translation>
    </message>
    <message>
        <source>Remember me</source>
        <translation>Prisiminti mane</translation>
    </message>
    <message>
        <source>Server</source>
        <translation>Serveris</translation>
    </message>    
</context>
<context>
    <name>csmailcheck/infobox</name>
    <message>
        <source>Mail check</source>
        <translation>Pašto tikrinimas</translation>
    </message>   
</context>
<context>
    <name>csmailcheck/inbox</name>
    <message>
        <source>Messages</source>
        <translation>Žinutės</translation>
    </message> 
    <message>
        <source>Empty...</source>
        <translation>Tuščia...</translation>
    </message> 
    <message>
        <source>Logout</source>
        <translation>Atsijungti</translation>
    </message>   
</context>
<context>
    <name>csmailcheck/error</name>
    <message>
        <source>Incorrect logins</source>
        <translation>Nekorektiški prisijungimai</translation>
    </message> 
</context>
</TS>
