<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=csmailcheck

[RegionalSettings]
TranslationExtensions[]=csmailcheck



*/ ?>