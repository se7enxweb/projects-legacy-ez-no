<?php /*
 
[CronjobSettings]
ExtensionDirectories[]=csmailcheck
Scripts[]
Scripts[]=deleteexpired.php

*/ ?>
