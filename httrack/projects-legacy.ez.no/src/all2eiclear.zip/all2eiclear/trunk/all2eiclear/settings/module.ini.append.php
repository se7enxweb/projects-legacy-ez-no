<?php /*

[ModuleSettings]
ExtensionRepositories[]=all2eiclear

*/ ?>
