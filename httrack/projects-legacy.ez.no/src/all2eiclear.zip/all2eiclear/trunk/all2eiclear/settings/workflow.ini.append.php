<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=all2eiclear
AvailableEventTypes[]=event_all2eiclear
AvailableEventTypes[]=event_all2eselectpayment

*/ ?>
