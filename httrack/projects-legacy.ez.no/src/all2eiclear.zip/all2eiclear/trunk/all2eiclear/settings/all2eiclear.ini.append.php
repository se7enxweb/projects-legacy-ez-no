<?php /*
                
[iclearSettings]
ShopID=#
# Magic Keyword "orderview" redirect to the orderview for the orderID
shopURL=orderview
AquiseID=#


[acceptOrderSettings]
iclearIP=78.35.17.78
FailedURL=http://www.mobello.de/failed
payedByIclearStatus=1000
pendingStatusIDs[]=1

*/
?>
