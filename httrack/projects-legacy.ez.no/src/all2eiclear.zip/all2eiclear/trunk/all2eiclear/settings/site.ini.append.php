<?php


[RoleSettings]
PolicyOmitList[]=iclear_soap


[SiteAccessSettings]
AnonymousAccessList[]=iclear_soap



?>
