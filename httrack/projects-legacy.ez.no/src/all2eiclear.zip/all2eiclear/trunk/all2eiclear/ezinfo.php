<?php

class all2eiClearInfo
{
    static function info()
    {
        return array( 'Name' => "all2e iClear",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) 2008 <a href='http://www.all2e.com' title='all2e GmbH'>all2e GmbH</a>",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}

?>
