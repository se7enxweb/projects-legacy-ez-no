<?php
class addcollabruleInfo
{
    function info()
    {
        return array(
            'Name' => "Collaboration rule creation event",
            'Version' => "0.x",
            'Copyright' => "Copyright (C) 2007 Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>