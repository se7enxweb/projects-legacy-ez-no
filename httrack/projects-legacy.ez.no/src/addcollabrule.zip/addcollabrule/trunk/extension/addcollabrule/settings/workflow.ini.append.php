<?php /* #?ini charset="iso-8859-1"?

[EventSettings]
ExtensionDirectories[]=addcollabrule
AvailableEventTypes[]=event_addcollabrule

*/ ?>