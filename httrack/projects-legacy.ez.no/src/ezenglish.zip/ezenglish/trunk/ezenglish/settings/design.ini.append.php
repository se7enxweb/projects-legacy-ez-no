<?php /*

[ExtensionSettings]
DesignExtensions[]=ezenglish

*/ ?>
