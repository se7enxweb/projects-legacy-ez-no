<?php /*

[RegionalSettings]
TranslationExtensions[]=ezenglish

*/ ?>
