<?php /*

[Leftmenu_my]
Name=dashboard
Links[]
LinkNames[]

Links[collaboration]=collaboration/view/summary
PolicyList_collaboration[]=collaboration/view

Links[my_pending]=content/pendinglist
PolicyList_my_pending[]=content/pendinglist

Links[my_drafts]=content/draft
PolicyList_my_drafts[]=content/edit

Links[my_bookmarks]=content/bookmark
PolicyList_my_bookmarks[]=content/bookmark

Links[edit_profile]=user/edit/(action)/edit
PolicyList_edit_profile[]=user/selfedit

Links[change_password]=user/password
PolicyList_change_password[]=user/password

Links[my_notifications]=notification/settings
PolicyList_my_notifications[]=notification/use
*/ ?>