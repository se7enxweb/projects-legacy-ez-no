<?php
/*

[ExtensionSettings]
DesignExtensions[]=nusoap

*/
?>
