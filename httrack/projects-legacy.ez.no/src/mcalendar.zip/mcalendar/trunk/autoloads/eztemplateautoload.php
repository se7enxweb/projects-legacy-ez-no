<?php

$eZTemplateOperatorArray = calendarOperators::operators();
?>
