<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.




[ezjscServer]
FunctionList[]=mcalendar_removeEvent
FunctionList[]=mcalendar_updateEventAjax
FunctionList[]=mcalendar_updateEventTimeSlot
FunctionList[]=mcalendar_addEventAjax
FunctionList[]=mcalendar_fetchEvents


[ezjscServer_mcalendar]
Functions[]=mcalendar
PermissionPrFunction=enabled
Class=mcServerFunctions
File=extension/mcalendar/classes/mcserverfunctions.php



*/
?>
