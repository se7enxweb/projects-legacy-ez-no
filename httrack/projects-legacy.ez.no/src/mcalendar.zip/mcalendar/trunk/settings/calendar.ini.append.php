<?php /* #?ini charset="utf-8"?

[McalendarSettings]

CacheTime=1200

[EventClass]
# Identifiant of events's class
EventClassID=event



*/ ?>