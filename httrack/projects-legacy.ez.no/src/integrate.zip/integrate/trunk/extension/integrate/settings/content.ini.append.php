<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=integrate

AvailableDataTypes[]=externaloption
AvailableDataTypes[]=externalmultipleoption

*/ ?>
