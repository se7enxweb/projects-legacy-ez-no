<?php
class integrateInfo
{
    static function info()
    {
        return array(
            'Name' => "Integrate Datatypes",
            'Version' => "2.0",
            'Author' => "<a href='http://www.stuffandcontent.com'>Bruce Morrison</a>",
            'Copyright' => "Copyright (C) 2004-2009 designIT",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>