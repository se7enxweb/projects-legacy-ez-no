<?php /*

[EventSettings]
ExtensionDirectories[]=akismet
AvailableEventTypes[]=event_ezakismet

*/ ?>