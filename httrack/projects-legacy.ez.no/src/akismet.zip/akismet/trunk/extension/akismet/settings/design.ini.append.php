<?php /*

[ExtensionSettings]
DesignExtensions[]=akismet

*/ ?>