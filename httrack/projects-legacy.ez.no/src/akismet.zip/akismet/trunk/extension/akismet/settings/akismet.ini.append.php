<?php /*

[InformationExtractorSettings]
ExtensionDirectory[]=akismet
ClassMap[user]=ezuser

*/ ?>