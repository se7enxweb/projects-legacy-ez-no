<?php /*

[AuditSettings]
AuditFileNames[akismet]=akismet.log

*/ ?>
