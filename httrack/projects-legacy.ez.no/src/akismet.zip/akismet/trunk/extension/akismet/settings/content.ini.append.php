<?php /*

[ActionSettings]
ExtensionDirectories[]=akismet

*/ ?>