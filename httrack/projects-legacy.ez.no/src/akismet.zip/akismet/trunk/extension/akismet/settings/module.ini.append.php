<?php /*

[ModuleSettings]
ExtensionRepositories[]=akismet
ModuleList[]=akismet

*/ ?>