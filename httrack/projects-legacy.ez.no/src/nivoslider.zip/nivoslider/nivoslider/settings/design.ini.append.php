<?php /* #?ini charset="utf-8"?


[ExtensionSettings]
DesignExtensions[]=nivoslider

[StylesheetSettings]
CSSFileList[]=nivo-slider.css
FrontendCSSFileList[]=nivo-slider.css

*/
?>
