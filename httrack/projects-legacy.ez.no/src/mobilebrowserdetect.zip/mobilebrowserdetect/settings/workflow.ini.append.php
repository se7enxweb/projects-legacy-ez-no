<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=mobilebrowserdetect
AvailableEventTypes[]=event_mobilebrowserdetect

[OperationSettings]
AvailableOperationList[]=content_read

*/ ?>