<?php /*

[EventSettings]
ExtensionDirectories[]=ezping
AvailableEventTypes[]=event_ezping

*/ ?>
