<?php /*

[PingSettings]
UserAgent=eZ Ping extension
UseCronjob=enabled
LogFile=ping.log
### Add the class identifier of objects that needs a ping to
# the PingClasses array and then create the class_identifierPingSettings
# section with a PingURL array containing the URLs to call
#
# For example, for weblog class :
#
#PingClasses[]
#PingClasses[]=weblog
#
#[weblogPingSettings]
#PingURL[]
#PingURL[]=http://blogsearch.google.com/ping?url=http://yoursite.com
#PingURL[]=http://pingomatic.com/ping/?title=~tigrou/pwet.fr&blogurl=http://pwet.fr/blog&rssurl=http://pwet.fr/feed/blog&chk_weblogscom=on&chk_blogs=on&chk_technorati=on&chk_feedburner=on&chk_syndic8=on&chk_newsgator=on&chk_myyahoo=on&chk_pubsubcom=on&chk_blogdigger=on&chk_blogrolling=on&chk_blogstreet=on&chk_moreover=on&chk_weblogalot=on&chk_icerocket=on&chk_newsisfree=on&chk_topicexchange=on&chk_tailrank=on&chk_bloglines=on&chk_aiderss=on&chk_rubhub=on&chk_blogshares=on
#
###

*/ ?>
