<?php /*

[RegionalSettings]
TranslationExtensions[]=optionmatrix

*/ ?>

