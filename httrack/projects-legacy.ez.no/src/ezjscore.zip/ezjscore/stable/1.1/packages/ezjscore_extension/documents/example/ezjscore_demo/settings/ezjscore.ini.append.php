<?php /*

[ezjscServer]
FunctionList[]=ezjscdemo

[ezjscServer_ezjscdemo]
Class=ezjscoreDemoServerCallFunctions
# Define File to avoid relying on autoload system for this simple example
File=extension/ezjscore_demo/classes/ezjscoredemoservercallfunctions.php
Functions[]=ezjscdemo

*/ ?>