<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=ezrss2
ModuleList[]=rss2

*/ ?>
