<?php /* #?ini charset="utf-8"?

[AuditSettings]
AuditFileNames[remote-login]=remote_login.log
AuditFileNames[remote-verify]=remote_verify.log

*/ ?>