<?php /* #?ini charset="utf-8"?

[UserSettings]
ExtensionDirectory[]=cmsxremotelogin
LoginHandler[]
LoginHandler[]=RemoteLogin


[RoleSettings]
PolicyOmitList[]=remotelogin

[SiteAccessSettings]
AnonymousAccessList[]=remotelogin

[SSLZoneSettings]
ModuleViewAccessMode[remotelogin/*]=ssl

*/ ?>