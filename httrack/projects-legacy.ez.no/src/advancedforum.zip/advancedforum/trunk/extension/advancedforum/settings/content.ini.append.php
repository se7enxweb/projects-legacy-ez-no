#[CustomTagSettings]
#AvailableCustomTags[]=quote
#IsInline[quote]=true