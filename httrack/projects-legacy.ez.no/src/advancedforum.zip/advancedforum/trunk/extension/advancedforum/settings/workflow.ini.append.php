[EventSettings]
ExtensionDirectories[]=advancedforum
AvailableEventTypes[]=event_ezaddlanguage