[ExtensionSettings]
DesignExtensions[]=advancedforum