<?php
class phpbbtextvconverter {

	function phpbbtextvconverter()
	{
		
	}
	function convert()
	{
		phpbbtextvconverter::convertLiteral();
	}
	function convertLiteral()
	{
		
	}
}
?>