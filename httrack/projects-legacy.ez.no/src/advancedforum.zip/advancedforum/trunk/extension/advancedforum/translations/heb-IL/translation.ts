<!DOCTYPE TS><TS>
<context>
    <name>design/standard/notification</name>
    <message>
        <source>Node notification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Re</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The full forum thread can be read at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you do not wish to continue receiving these notifications,
change your settings at:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%sitename notification system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Notification settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/advancedforum</name>
    <message>
        <source>Edit %1 - %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sticky</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New topic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Neues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Topic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moderated by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous topic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next topic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Posts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit forum message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Posted on %date by %user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have to login to use this feature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New content since last visit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your last visit to this site was</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There is no new content since your last visit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last post</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
