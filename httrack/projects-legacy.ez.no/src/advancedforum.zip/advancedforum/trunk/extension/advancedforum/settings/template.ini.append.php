[PHP]
PHPOperatorList[strip_tags]=strip_tags