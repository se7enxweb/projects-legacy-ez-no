<?php
/**
 * Description of ezpInvalidClassExceptionclass
 *
 * @author Francesco (cphp) Trucchia
 */
class ezpInvalidClassException extends Exception
{
    
}
?>
