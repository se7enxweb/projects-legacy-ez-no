<?php
/**
 * Description of ezpInvalidClassExceptionclass
 *
 * @author Francesco (cphp) Trucchia
 */
class ezpInvalidObjectException extends Exception
{
    
}
?>
