<?php
/**
 * Description of ezpInvalidClassExceptionclass
 *
 * @author Francesco (cphp) Trucchia
 */
class ezpInvalidObjectAttributeException extends Exception
{
    
}
?>
