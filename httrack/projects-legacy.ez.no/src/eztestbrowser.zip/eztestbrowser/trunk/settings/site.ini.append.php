<?php /*#?ini charset="utf-8"?

# [DebugSettings]
# DebugOutput=enabled
# DebugRedirection=disabled

# [TemplateSettings]
# Debug=disabled
# ShowXHTMLCode=disabled
# ShowUsedTemplates=enabled
# NodeTreeCaching=disabled
# TemplateCache=disabled
# TemplateCompile=disabled
# TemplateCompression=disabled
# TemplateOptimization=disabled

# [OverrideSettings]
# Cache=disabled

# [DatabaseSettings]
# SQLOutput=disabled

# [ContentSettings]
# ViewCaching=disabled

*/ ?>