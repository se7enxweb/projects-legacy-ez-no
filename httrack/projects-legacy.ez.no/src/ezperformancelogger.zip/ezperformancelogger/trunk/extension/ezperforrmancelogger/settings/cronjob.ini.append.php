<?php /*

[CronjobSettings]
ExtensionDirectories[]=ezperformancelogger

[CronjobPart-updateperfstats]
Scripts[]=updateperfstats.php

*/ ?>
