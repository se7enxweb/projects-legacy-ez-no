<?php /*

[OutputSettings]
OutputFilterName=eZPerfLogger

*/ ?>