<?php
class eZperformanceloggerInfo
{
    static function info()
    {
        return array( 'Name' => "<a href=\"http://projects.ez.no/ezperformancelogger\">ezperformancelogger</a>",
                      'Version' => "0.3-dev",
                      'Copyright' => "Copyright (C) 2010-2012 Gaetano Giunta",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>