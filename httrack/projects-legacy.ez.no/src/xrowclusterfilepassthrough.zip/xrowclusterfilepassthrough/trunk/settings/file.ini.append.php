[BinaryFileSettings]
Handler=xrowclusterfilepassthrough
ExtensionRepositories[]
ExtensionRepositories[]=xrowclusterfilepassthrough

[DownloadSettings]
# "attached", "inline" and "none"
# none will let the browser decide 
Default=none
List[mpl]=attached
List[csv]=inline