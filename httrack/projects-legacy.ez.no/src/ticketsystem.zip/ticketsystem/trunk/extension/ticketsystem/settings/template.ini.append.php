[PHP]
PHPOperatorList[striptags]=strip_tags