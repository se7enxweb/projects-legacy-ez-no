#?ini charset="iso-8859-1"?
[TicketSettings]
TicketNodeID=94