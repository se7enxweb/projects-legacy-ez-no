<?php
	$Module = array( "name" => "ticketsystem" );
	$ViewList = array();
	$ViewList["tickets"]	= array( "script" => "tickets.php");	

$FunctionList['use'] = array( );
$FunctionList['deligate'] = array( );
?>