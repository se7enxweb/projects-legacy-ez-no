[ModuleSettings]
ExtensionRepositories[]=ticketsystem
