/*
    Ticketsystem for eZ publish
    Copyright (C) 2007 xrow GbR, Hannover Germany
*/

Developed by
Konstantin Pogrebnoj
Bj�rn Dieding