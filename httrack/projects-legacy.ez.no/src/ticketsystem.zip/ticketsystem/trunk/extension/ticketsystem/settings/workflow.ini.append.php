[EventSettings]
ExtensionDirectories[]=ticketsystem
AvailableEventTypes[]=event_ticketnotification
[OperationSettings]
AvailableOperations=content_publish
