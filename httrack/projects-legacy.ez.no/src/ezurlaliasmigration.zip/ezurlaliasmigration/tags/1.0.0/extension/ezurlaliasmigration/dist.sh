#!/bin/bash
EXTENSION_NAME="eZ Url Alias Migration Extension"
EXTENSION_IDENTIFIER="ezurlaliasmigration"
EXTENSION_SUMMARY="This extension enables users to migrate custom url aliases and url history entries."
EXTENSION_LICENSE="GNU General Public License v2.0"
EXTENSION_VERSION="1.0.0"
EXTENSION_PUBLISH_VERSION="4.0.1 and higher"
EXTENSION_ARCHIVE_NAME="ezurlaliasmigration"
EXTENSION_PHP_VERSION="5.1"

# EXTENSION_FILTER_FILES=""
