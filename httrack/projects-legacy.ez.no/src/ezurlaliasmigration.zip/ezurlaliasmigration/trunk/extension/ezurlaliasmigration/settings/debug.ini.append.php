<?php /* #?ini charset="iso-8859-1"?
# eZ Publish configuration file for debug

[GeneralCondition]
urlalias-migration-checks=disabled
urlalias-migration-result=disabled
urlalias-migration-pathwalker=disabled
urlalias-migration-pathwalker-debug=disabled
urlalias-migration-extra=disabled

*/
?>