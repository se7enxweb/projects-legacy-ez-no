<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[ezurlaliasnavigationpart]=URL Alias

[TopAdminMenu]
Tabs[]=urlalias

[Topmenu_urlalias]
NavigationPartIdentifier=ezurlaliasnavigationpart
Name=URL Aliases
Tooltip=Look at defined custom url aliases in the system
URL[]
URL[default]=urlalias/migrate
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=false

*/
?>