<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezurlaliasmigration

*/ ?>