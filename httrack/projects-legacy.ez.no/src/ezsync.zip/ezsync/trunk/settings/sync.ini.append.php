<?php /*

[DefaultSyncSettings]
Host=
User=
Port=22
Parameters=
FileRsyncExclude=extension/ezdeploy/settings/rsync_exclude.txt

[ProductionSyncSettings]
# Dir=/var/www


*/ ?>
