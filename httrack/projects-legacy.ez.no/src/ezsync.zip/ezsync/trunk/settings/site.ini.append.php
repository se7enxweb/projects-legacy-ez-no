<?php /*

[RoleSettings]
PolicyOmitList[]=courtesy

*/ ?>