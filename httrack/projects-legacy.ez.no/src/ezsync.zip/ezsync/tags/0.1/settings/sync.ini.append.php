<?php /*

[DefaultSyncSettings]
Host=
Dir=
User=
Port=22
Parameters=
FileRsyncEclude=extension/ezdeploy/settings/rsync_exclude.txt

[ProductionSyncSettings]
Dir=


*/ ?>
