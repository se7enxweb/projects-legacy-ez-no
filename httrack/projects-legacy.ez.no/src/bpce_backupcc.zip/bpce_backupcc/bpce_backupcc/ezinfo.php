<?php
class bpce_backupccInfo
{
    static function info()
    {
        return array( 'Name' => "bpce_backupcc",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) 1999-2009 BPCE",
                      'License' => "GNU General Public License v2.0"
                      );
    }
}
?>
