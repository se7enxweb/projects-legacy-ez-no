<?php /*

[CronjobSettings]
ScriptDirectories[]=extension/bpce_backupcc/cronjobs

[CronjobPart-backup_classes]
Scripts[]=backup_classes.php

[CronjobPart-backup_classes_allinone]
Scripts[]=backup_classes_allinone.php

*/
?>