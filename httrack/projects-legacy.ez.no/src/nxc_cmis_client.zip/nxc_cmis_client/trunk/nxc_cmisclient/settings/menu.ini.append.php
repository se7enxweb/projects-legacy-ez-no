<?php /*

[NavigationPart]
Part[nxccmispart]=CMIS

[TopAdminMenu]
Tabs[]=cmis

[Topmenu_cmis]
NavigationPartIdentifier=nxccmispart
Name=CMIS Client
Tooltip=CMIS Client
URL[]
URL[default]=cmis_client/browser
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[navigation]=true
Shown[browse]=false


*/ ?>