<?php
class createsubtreenoficationruleeventInfo
{
    function info()
    {
        return array(
            'Name' => "<a href='http://projects.ez.no/createsubtreenotificationruleevent'>Create subtree notification rule event type</a>",
            'Version' => "1.0.1",
            'Copyright' => "Copyright (C) 2006 SCK-CEN",
            'Author' => "Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>