<?php /* #?ini charset="utf-8"?

[EventSettings]
ExtensionDirectories[]=createsubtreenotificationruleevent
AvailableEventTypes[]=event_createsubtreenotificationrule

*/ ?>