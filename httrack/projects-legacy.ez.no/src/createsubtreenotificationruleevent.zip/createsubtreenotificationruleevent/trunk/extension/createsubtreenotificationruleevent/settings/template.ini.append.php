<?php /* #?ini charset="utf-8"?

[PHP]
PHPOperatorList[addslashes]=addslashes

*/ ?>