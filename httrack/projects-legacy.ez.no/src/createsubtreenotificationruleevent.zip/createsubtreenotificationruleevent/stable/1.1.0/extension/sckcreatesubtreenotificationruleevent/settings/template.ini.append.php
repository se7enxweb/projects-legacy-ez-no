<?php /*

[PHP]
PHPOperatorList[addslashes]=addslashes

*/ ?>