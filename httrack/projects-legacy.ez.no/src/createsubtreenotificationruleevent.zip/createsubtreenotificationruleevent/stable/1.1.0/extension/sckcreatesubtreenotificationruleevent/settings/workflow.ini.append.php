<?php
/*

[EventSettings]
ExtensionDirectories[]=sckcreatesubtreenotificationruleevent
AvailableEventTypes[]=event_sckcreatesubtreenotificationrule

*/
?>
