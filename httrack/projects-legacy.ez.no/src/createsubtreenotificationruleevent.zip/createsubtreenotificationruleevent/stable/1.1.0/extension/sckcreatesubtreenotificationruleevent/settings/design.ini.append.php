<?php
/*

[ExtensionSettings]
DesignExtensions[]=sckcreatesubtreenotificationruleevent

*/
?>
