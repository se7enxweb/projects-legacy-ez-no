<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>extension/nxc_string</name>
    <message>
      <source>NXC String</source>
      <translation type="unfinished">NXC String</translation>
    </message>
    <message>
      <source>Input required.</source>
      <translation type="unfinished">Input required.</translation>
    </message>
    <message>
      <source>Default value</source>
      <translation type="unfinished">Default value</translation>
    </message>
    <message>
      <source>Matching limitations</source>
      <translation type="unfinished">Matching limitations</translation>
    </message>
    <message>
      <source>There are no limitations</source>
      <translation type="unfinished">There are no limitations</translation>
    </message>
    <message>
      <source>Not-matching limitations</source>
      <translation type="unfinished">Not-matching limitations</translation>
    </message>
    <message>
      <source>New limitation</source>
      <translation type="unfinished">New limitation</translation>
    </message>
    <message>
      <source>Matching</source>
      <translation type="unfinished">Matching</translation>
    </message>
    <message>
      <source>Not-matching</source>
      <translation type="unfinished">Not-matching</translation>
    </message>
    <message>
      <source>Add</source>
      <translation type="unfinished">Add</translation>
    </message>
    <message>
      <source>Regular expression</source>
      <translation type="unfinished">Regular expression</translation>
    </message>
    <message>
      <source>Description</source>
      <translation type="unfinished">Description</translation>
    </message>
    <message>
      <source>Error message</source>
      <translation type="unfinished">Error message</translation>
    </message>
    <message>
      <source>Update</source>
      <translation type="unfinished">Update</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation type="unfinished">Remove</translation>
    </message>
    <message>
      <source>Empty</source>
      <translation type="unfinished">Empty</translation>
    </message>
  </context>
</TS>
