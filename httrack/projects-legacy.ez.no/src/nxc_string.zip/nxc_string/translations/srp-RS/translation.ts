<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>extension/nxc_string</name>
    <message>
      <source>NXC String</source>
      <translation type="TranslatedByGoogleAPI">НКСЦ Стринг</translation>
    </message>
    <message>
      <source>Input required.</source>
      <translation type="TranslatedByGoogleAPI">Улаз је потребно.</translation>
    </message>
    <message>
      <source>Default value</source>
      <translation type="TranslatedByGoogleAPI">Подразумевана вредност</translation>
    </message>
    <message>
      <source>Matching limitations</source>
      <translation type="TranslatedByGoogleAPI">Одговарајући ограничења</translation>
    </message>
    <message>
      <source>There are no limitations</source>
      <translation type="TranslatedByGoogleAPI">Не постоје ограничења</translation>
    </message>
    <message>
      <source>Not-matching limitations</source>
      <translation type="TranslatedByGoogleAPI">Не-налажења ограничења</translation>
    </message>
    <message>
      <source>New limitation</source>
      <translation type="TranslatedByGoogleAPI">Нови ограничења</translation>
    </message>
    <message>
      <source>Matching</source>
      <translation type="TranslatedByGoogleAPI">Одговарајући</translation>
    </message>
    <message>
      <source>Not-matching</source>
      <translation type="TranslatedByGoogleAPI">Не-налажења</translation>
    </message>
    <message>
      <source>Add</source>
      <translation type="TranslatedByGoogleAPI">Додати</translation>
    </message>
    <message>
      <source>Regular expression</source>
      <translation type="TranslatedByGoogleAPI">Регуларни израз</translation>
    </message>
    <message>
      <source>Description</source>
      <translation type="TranslatedByGoogleAPI">Опис</translation>
    </message>
    <message>
      <source>Error message</source>
      <translation type="TranslatedByGoogleAPI">Порука о грешци</translation>
    </message>
    <message>
      <source>Update</source>
      <translation type="TranslatedByGoogleAPI">Ажурирање</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation type="TranslatedByGoogleAPI">Уклонити</translation>
    </message>
    <message>
      <source>Empty</source>
      <translation type="TranslatedByGoogleAPI">Празан</translation>
    </message>
  </context>
</TS>
