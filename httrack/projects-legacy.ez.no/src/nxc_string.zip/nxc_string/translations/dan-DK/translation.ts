<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>extension/nxc_string</name>
    <message>
      <source>NXC String</source>
      <translation type="unfinished">NXC String</translation>
    </message>
    <message>
      <source>Input required.</source>
      <translation type="TranslatedByGoogleAPI">Input påkrævet.</translation>
    </message>
    <message>
      <source>Default value</source>
      <translation type="TranslatedByGoogleAPI">Standardværdi</translation>
    </message>
    <message>
      <source>Matching limitations</source>
      <translation type="TranslatedByGoogleAPI">Matchende begrænsninger</translation>
    </message>
    <message>
      <source>There are no limitations</source>
      <translation type="TranslatedByGoogleAPI">Der er ingen begrænsninger</translation>
    </message>
    <message>
      <source>Not-matching limitations</source>
      <translation type="TranslatedByGoogleAPI">Ikke-matchende begrænsninger</translation>
    </message>
    <message>
      <source>New limitation</source>
      <translation type="TranslatedByGoogleAPI">Ny forældelsesfrist</translation>
    </message>
    <message>
      <source>Matching</source>
      <translation type="TranslatedByGoogleAPI">Matchende</translation>
    </message>
    <message>
      <source>Not-matching</source>
      <translation type="TranslatedByGoogleAPI">Ikke-matching</translation>
    </message>
    <message>
      <source>Add</source>
      <translation type="TranslatedByGoogleAPI">Tilføj</translation>
    </message>
    <message>
      <source>Regular expression</source>
      <translation type="TranslatedByGoogleAPI">Regulært udtryk</translation>
    </message>
    <message>
      <source>Description</source>
      <translation type="TranslatedByGoogleAPI">Beskrivelse</translation>
    </message>
    <message>
      <source>Error message</source>
      <translation type="TranslatedByGoogleAPI">Fejlmeddelelse</translation>
    </message>
    <message>
      <source>Update</source>
      <translation type="TranslatedByGoogleAPI">Opdater</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation type="TranslatedByGoogleAPI">Fjern</translation>
    </message>
    <message>
      <source>Empty</source>
      <translation type="TranslatedByGoogleAPI">Tomme</translation>
    </message>
  </context>
</TS>
