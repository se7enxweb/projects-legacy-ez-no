[ViewSettings]
GroupedInput[]=ezpublisheddate

[EditSettings]
GroupedInput[]=ezpublisheddate

[CollectionSettings]
GroupedInput[]=ezpublisheddate