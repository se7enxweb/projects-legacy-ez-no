[DataTypeSettings]
ExtensionDirectories[]=publisheddate
AvailableDataTypes[]=ezpublisheddate
