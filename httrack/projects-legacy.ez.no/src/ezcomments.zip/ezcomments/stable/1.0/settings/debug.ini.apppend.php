<?php /*

[GeneralCondition]
extension-ezcomments=enabled

*/ ?>