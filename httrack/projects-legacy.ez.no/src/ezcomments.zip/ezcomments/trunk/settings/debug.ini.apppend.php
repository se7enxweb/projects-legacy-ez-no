<?php /*

[GeneralCondition]
extension-ezcomments=disabled

*/ ?>