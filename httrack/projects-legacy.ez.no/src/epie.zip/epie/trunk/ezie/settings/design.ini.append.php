<?php /*
       
[ExtensionSettings]
DesignExtensions[]=ezie

*/ ?>