<?php /*

[RegionalSettings]
TranslationExtensions[]=ezie

*/ ?>
