<?php /*

# This is here for development purposes only and example.
# The settings must not be overriden in the extension.
#
[eZIE]
watermarks[]=elephpant.png
watermarks[]=ez-logo.png

*/ ?>