<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezie
ModuleList[]=ezie

*/ ?>
