<!DOCTYPE TS><TS>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Current image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MIME type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There is no image file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New image file for upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alternative image text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/ezie</name>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZ Image Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save and Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save &amp;amp; Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close without saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thumbnail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dimensions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Free</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actual pixels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Watermarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal Flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertical Flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Perform Crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Effects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pixelate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black and White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sepia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
