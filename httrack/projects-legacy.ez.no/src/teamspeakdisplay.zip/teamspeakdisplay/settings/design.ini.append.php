<?php /*

[ExtensionSettings]
DesignExtensions[]=teamspeakdisplay

[StylesheetSettings]
CSSFileList[]=teamspeakdisplay.css

*/
?>