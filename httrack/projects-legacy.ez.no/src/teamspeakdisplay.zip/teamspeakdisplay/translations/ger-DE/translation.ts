<!DOCTYPE TS><TS>
<defaultcodec></defaultcodec>
<context>
    <name>extension/teamspeakdisplay</name>
    <message>
        <source>ping</source>
        <translation>ping</translation>
    </message>
    <message>
        <source>totaltime</source>
        <translation>gesamt Zeit</translation>
    </message>
    <message>
        <source>password protected</source>
        <translation>passwort geschützt</translation>
    </message>
    <message>
        <source>Server Name</source>
        <translation>Server Name</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Willkommensmeldung</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Addresse</translation>
    </message>
    <message>
        <source>Uptime</source>
        <translation>Uptime</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Teilnehmer</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Channels</translation>
    </message>
    <message>
        <source>TS Server currently offline or could not connect.</source>
        <translation>Der TS Server ist offline oder nicht erreichbar</translation>
    </message>
</context>
</TS>
