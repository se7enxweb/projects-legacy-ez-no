<?php /*

[ExtensionSettings]
ExtensionDirectories[]=xajax_keywordsuggest

AvailableFunctions[keywordSuggest]=keywordsuggest

*/ ?>