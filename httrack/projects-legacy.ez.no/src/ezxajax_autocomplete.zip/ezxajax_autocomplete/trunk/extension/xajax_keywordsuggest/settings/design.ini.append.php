<?php /*

[ExtensionSettings]
DesignExtensions[]=xajax_keywordsuggest

[JavaScriptSettings]
JavaScriptList[]=xajax_keywordsuggest.js

[StylesheetSettings]
CSSFileList[]=suggest.css

*/ ?>