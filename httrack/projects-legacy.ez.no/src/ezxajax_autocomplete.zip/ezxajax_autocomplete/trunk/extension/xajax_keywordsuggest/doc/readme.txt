This extension was based on http://ez.no/community/contribs/applications/xajax_autosuggest
Due to reuse of existing function names it can not be used together with it.
A project has been started to develop a generic xajax-ed autocomplete feature: http://projects.ez.no/ezxajax_autocomplete

Requirements:
- eZ publish xajax extension with xajax library 0.2.4