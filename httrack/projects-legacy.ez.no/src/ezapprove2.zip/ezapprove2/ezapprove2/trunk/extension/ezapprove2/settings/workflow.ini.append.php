<?php /*

[EventSettings]
ExtensionDirectories[]=ezapprove2
AvailableEventTypes[]=event_ezxapprove2

*/ ?>
