<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezapprove2

*/ ?>
