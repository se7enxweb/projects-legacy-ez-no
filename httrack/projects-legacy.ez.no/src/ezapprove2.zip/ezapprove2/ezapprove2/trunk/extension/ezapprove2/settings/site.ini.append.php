<?php /*

[RegionalSettings]
TranslationExtensions[]=ezapprove2

*/ ?>
