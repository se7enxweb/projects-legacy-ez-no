<?php

class Audioplayerinfo 
{
    /*! 
 *      Constructor
 *          */
    function info()
    {   
        return array( 'name' => 'Audio Player',
                      'version' => '1.0',
                      'copyright' => 'Copyright © 2007 Michael Maclean',
                      'license' => 'GPL version 2' );
    }   
}

?>
