<?php /* #?ini charset="utf-8"?

[CreateSettings]
MimeClassMap[audio/mpeg]=mp3_audio

[mp3_audio_ClassSettings]
FileAttribute=file
NameAttribute=name
NamePattern=<original_filename_base>
?>
