<?php /* #?ini charset="iso-8859-1"?

[SubTreeRelationFilter]
ExtensionName=ezsubtreerelationfilter
ClassName=eZSubTreeRelationFilter
MethodName=createSqlParts
FileName=classes/ezsubtreerelationfilter.php

*/ ?>