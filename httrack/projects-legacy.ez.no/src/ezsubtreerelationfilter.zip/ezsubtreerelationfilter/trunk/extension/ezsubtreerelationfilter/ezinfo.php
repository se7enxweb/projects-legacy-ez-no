<?php

class ezsubtreerelationfilterInfo
{
    static function info()
    {
        return array(
            'Name' => "eZ Subtree Relation Filter",
            'Version' => "2.x",
            'Copyright' => "Copyright (C) 2007-2008 Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}

?>