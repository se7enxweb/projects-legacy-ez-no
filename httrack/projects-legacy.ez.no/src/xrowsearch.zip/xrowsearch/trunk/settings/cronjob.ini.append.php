<?php /* #?ini charset="utf8"?

[CronjobSettings]
ExtensionDirectories[]=xrowsearch

[CronjobPart-xrowsearch]
Scripts[]=xrowsearch.php

*/ ?>