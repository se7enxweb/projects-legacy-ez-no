<?php

$res = eZFunctionHandler::execute('sqligeoloc', 'remote_ip', array());
var_dump($res);
