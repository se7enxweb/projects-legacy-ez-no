<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=ca_ezflow_enhanced
*/ ?>
