<?php 

class xrowRSSOutputHandler extends eZXHTMLXMLOutput
{
    function prefetch()
    {

    }
}