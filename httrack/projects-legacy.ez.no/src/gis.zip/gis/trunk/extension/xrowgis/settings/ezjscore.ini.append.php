<?php /*

[ezjscServer]
FunctionList[]=xrowGIS_page

[ezjscServer_xrowGIS_page]
Class=xrowGISServerfunctions

[eZJSCore]
# Disables/enables js / css packer (for debugging Apache rewrite rules)
# Normally controlled by [TemplateSettings]DevelopmentMode for convenience,
# but can also be specifically controlled by this setting if set.
# Force packer level by setting integer from 0 to 3 instead of [dis|en]abled
Packer=disabled

*/ ?>