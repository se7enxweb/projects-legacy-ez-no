<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=xrowgis

[StylesheetSettings]
FrontendCSSFileList[]=xrowgis_core.css

[JavaScriptSettings]
FrontendJavaScriptList[]=proj4js-combined.js
BackendJavaScriptList[]=OpenLayers/OpenLayers.js
FrontendJavaScriptList[]=OpenLayers/OpenLayers.js
FrontendJavaScriptList[]=XROWMap.js
FrontendJavaScriptList[]=POIMap.js
BackendJavaScriptList[]=xrowgis.js

*/?>