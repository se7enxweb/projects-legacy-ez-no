<?php /* #?ini charset="utf-8"?
#[openlayer]
#PageLayout=openlayer_pagelayout.tpl
*/ ?>