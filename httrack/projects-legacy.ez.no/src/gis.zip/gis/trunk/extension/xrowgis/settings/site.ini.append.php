<?php /* #?ini charset="utf-8"?

[RegionalSettings]
TranslationExtensions[]=xrowgis

[TemplateSettings]
ExtensionAutoloadPath[]=xrowgis

[SiteAccessSettings]
AnonymousAccessList[]=xrowgis/georss

[RoleSettings]
PolicyOmitList[]=xrowgis/georss

[RSSSettings]
AvailableVersionList[]=GEORSS 2.0
NumberOfObjectsList[]=100
NumberOfObjectsList[]=500

*/ ?>