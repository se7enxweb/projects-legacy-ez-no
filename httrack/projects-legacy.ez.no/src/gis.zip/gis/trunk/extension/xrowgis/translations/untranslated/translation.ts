<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Latitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Longitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Street</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowgis</name>
    <message>
        <source>Geographic location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Longitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Location from Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Street</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resolve information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this link to find location based on an address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lookup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current location</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <location filename="xrowgistype.php" line="9"/>
        <source>Geographic Information Systems</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="xrowgistype.php" line="80"/>
        <source>Latitude is no floating point figure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="xrowgistype.php" line="86"/>
        <source>Longitude is no floating point figure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="xrowgistype.php" line="111"/>
        <source>Missing data.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
