<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=xrowgis
AvailableDataTypes[]=xrowgis

[CustomTagSettings]
# You can use custom tags through the <custom> tag in XML fields.
# Example: <custom name="map">Sub text</custom>
#AvailableCustomTags[]=map
#IsInline[map]=true

#[map]
#AvailableClasses[]
#AllowEmpty=true
#CustomAttributes[]=node_id
#CustomAttributes[]=classes
#CustomAttributes[]=width
#CustomAttributes[]=height
#CustomAttributes[]=centerposition
#CustomAttributes[]=zoom
#CustomAttributes[]=icon

#[RelationGroupSettings]
#DefaultGroup=articles
#Groups[]=articles
#ArticlesClassList[]
#ArticlesClassList[]=article

*/ ?>