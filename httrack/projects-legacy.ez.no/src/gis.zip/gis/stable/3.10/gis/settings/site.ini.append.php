[SiteAccessSettings]
AnonymousAccessList[]=gis/georssserver

[RoleSettings]
PolicyOmitList[]=gis/georssserver

[RSSSettings]
AvailableVersionList[]=GEORSS 2.0
NumberOfObjectsList[]=100
NumberOfObjectsList[]=500