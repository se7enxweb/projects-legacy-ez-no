[ModuleSettings]
ExtensionRepositories[]=gis
