[yahoomap]
PageLayout=yahoomap_pagelayout.tpl

[googlemap]
PageLayout=googlemap_pagelayout.tpl