<?php /* #?ini charset="utf-8"?

[gis_full]
Source=node/view/full.tpl
MatchFile=full/gis.tpl
Subdir=templates
Match[class_identifier]=gis

[gis_line]
Source=node/view/full.tpl
MatchFile=line/gis.tpl
Subdir=templates
Match[class_identifier]=gis
*/ ?>