<?php

$eZTemplateOperatorArray   = array();
$eZTemplateOperatorArray[] = array( 'script'         => 'extension/ezspellchecker/autoloads/ezspellcheckertemplateoperator.php',
                                    'class'          => 'eZSpellcheckerTemplateOperator',
                                    'operator_names' => array( 'spellchecker_language' ) );

?>
