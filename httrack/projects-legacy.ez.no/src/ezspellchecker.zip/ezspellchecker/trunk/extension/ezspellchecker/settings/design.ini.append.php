<?php /* #?ini charset="utf8"?

[ExtensionSettings]
DesignExtensions[]=ezspellchecker

[StylesheetSettings]
CSSFileList[]=spellchecker.css

[JavaScriptSettings]
JavaScriptList[]=debug.js
JavaScriptList[]=spellcheckerbase.js
JavaScriptList[]=spellchecker.js

*/ ?>
