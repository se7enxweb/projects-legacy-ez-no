<?php /*

[RegionalSettings]
TranslationExtensions[]=ezspellchecker

[TemplateSettings]
ExtensionAutoloadPath[]=ezspellchecker

*/ ?>
