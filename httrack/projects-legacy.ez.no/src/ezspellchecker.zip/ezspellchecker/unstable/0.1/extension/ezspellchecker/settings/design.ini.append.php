<?php /* #?ini charset="utf8"?

[ExtensionSettings]
DesignExtensions[]=ezspellchecker

[StylesheetSettings]
CSSFileList[]=spell_checker.css

[JavaScriptSettings]
JavaScriptList[]=cpaint2.inc.js
JavaScriptList[]=spell_checker.js


*/ ?>
