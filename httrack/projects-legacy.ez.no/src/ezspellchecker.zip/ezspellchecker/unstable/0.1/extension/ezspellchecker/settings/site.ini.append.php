<?php /*

[RegionalSettings]
TranslationExtensions[]=ezspellchecker

*/ ?>
