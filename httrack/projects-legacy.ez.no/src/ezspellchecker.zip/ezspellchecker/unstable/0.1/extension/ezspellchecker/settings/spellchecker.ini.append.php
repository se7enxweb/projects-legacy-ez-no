<?php /*

[SpellcheckerSettings]
AllowedHTMLTags[]=strong
AllowedHTMLTags[]=small
AllowedHTMLTags[]=p
AllowedHTMLTags[]=br
AllowedHTMLTags[]=a
AllowedHTMLTags[]=b
AllowedHTMLTags[]=u
AllowedHTMLTags[]=i
AllowedHTMLTags[]=img
AllowedHTMLTags[]=code
AllowedHTMLTags[]=ul
AllowedHTMLTags[]=ol
AllowedHTMLTags[]=li
NumberOfMaxSuggestions=10
DefaultLanguage=de

# Not implemented yet!
# Not implemented yet!
[PersonalDictionarySettings]
PersonalDictionary=disabled
EditablePersonalDictionary=disabled

# perUser, perGroup, global
PersonalDictionary=perUser

# file, attribute
PersonalDictionary=perUser
DictionaryAttributeName=
DictionaryFileName=


*/ ?>
