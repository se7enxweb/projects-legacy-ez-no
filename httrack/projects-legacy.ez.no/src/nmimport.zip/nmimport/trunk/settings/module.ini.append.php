<?php /*

[ModuleSettings]
ExtensionRepositories[]=nmimport

*/ ?>