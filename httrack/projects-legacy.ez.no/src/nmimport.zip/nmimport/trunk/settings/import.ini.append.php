<?php /*

[Import]
ImportFormats[]
ImportFormats[]=company

*/ ?>