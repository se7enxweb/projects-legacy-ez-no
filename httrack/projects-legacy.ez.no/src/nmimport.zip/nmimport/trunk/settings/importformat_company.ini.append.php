<?php /*

[Import]
# The node ID of the parent element under which the nodes should be stored
ParentNodeID=160

# The identifier of the class of which objects should be created
ClassIdentifier=firma

# The columns which appear in the Excel spreadsheet. Each column should consist of the column number
# (A is 1, B is 2 and so on) and the attribute idenifier which the data should be mapped to
Columns[]
Columns[]=1;name
Columns[]=2;address
Columns[]=3;zip
Columns[]=4;city
Columns[]=5;phone
Columns[]=6;email

CreatorObjectID=14

SectionID=1

TitleAttribute=name

*/ ?>