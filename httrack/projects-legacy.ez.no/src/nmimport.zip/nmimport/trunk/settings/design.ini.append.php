<?php /*

[ExtensionSettings]
DesignExtensions[]=nmimport

*/ ?>