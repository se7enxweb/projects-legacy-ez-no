<?php

$Module = array( "name" => "Import" );

$ViewList = array();
$ViewList["input"] 		= array('functions' => array( 'input' ),
								"script" => "input.php" );

$FunctionList['input'] 			= array( );

?>
