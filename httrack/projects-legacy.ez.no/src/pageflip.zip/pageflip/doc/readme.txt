****************************************
PageFlip
Author : Bartek Olewi�ski
Date : May 2011

****************************************


1/ Unzip file in your extension directory
2/ Import and install package pageflip-1.0-1.ezpkg from 'packages' directory (in admin interface: Setup -> Packages)
3/ Activate the extension in the admin interface
4/ Change name of 'extension/pageflip/settings/siteaccess/<your_siteaccess>' directory to appropriate siteacces name
5/ Clear cache

to use:
1/ Create new object using 'pageflip' class
2/ put some jpg images as its child
3/ best way to use PageFlip it to put it in 'line' view

 
