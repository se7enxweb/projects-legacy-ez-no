<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="pl_PL">
<context>
    <name>design/pageflip</name>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Do strony</translation>
    </message>
    <message>
        <source>To view the book, you need the latest</source>
        <translation>Aby zobaczyć prezentację, potrzebujesz najnowszej wersji</translation>
    </message>
</context>
</TS>
