<?php /* #?ini charset="iso-8859-1"?

[SiteAccessSettings]
AnonymousAccessList[]=pageflip/getxml
AnonymousAccessList[]=pageflip/show

[RoleSettings]
PolicyOmitList[]=pageflip/getxml
PolicyOmitList[]=pageflip/show

[RegionalSettings]
TranslationExtensions[]=pageflip

*/ ?>