<?php /* #?ini charset="utf-8"?

[pageflip_view_full]
Source=node/view/full.tpl
MatchFile=full/pageflip.tpl
Subdir=templates
Match[class_identifier]=pageflip

[pageflip_view_embed]
Source=content/view/embed.tpl
MatchFile=embed/pageflip.tpl
Subdir=templates
Match[class_identifier]=pageflip

[pageflip_line]
Source=node/view/line.tpl
MatchFile=line/pageflip.tpl
Subdir=templates
Match[class_identifier]=pageflip

*/ ?>
