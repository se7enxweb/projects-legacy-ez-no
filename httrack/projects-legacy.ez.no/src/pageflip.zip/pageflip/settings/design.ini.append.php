<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=pageflip

[JavaScriptSettings]
JavaScriptList[]=swfobject.js

[StylesheetSettings]
CSSFileList[]=pageflip.css

*/
?>