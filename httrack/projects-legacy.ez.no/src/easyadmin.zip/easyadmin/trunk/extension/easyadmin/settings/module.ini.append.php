[ModuleSettings]
ExtensionRepositories[]=easyadmin

[SetSectionSettings]
# clear extra nodes after changing the section (beside the "normal ones", current, parent, related and what else on the viewcache settings
ClearExtraNodes[]
ClearExtraNodes[]=2
