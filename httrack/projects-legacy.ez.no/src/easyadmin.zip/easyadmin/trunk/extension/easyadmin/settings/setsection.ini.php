# Alter the default section of the object before publishing

[BeforePublish]
#7 is your "submited for publication/waiting for approval" section
#Section[acticle]=7
#Section[comment]=7
