<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=novenimagecropper

[JavaScriptSettings]
JavaScriptList[]=jquery-1.3.2.min.js
JavaScriptList[]=jquery-ui-novenimagecropper.min.js
JavaScriptList[]=jquery.Jcrop.min.js
JavaScriptList[]=ajaxupload.3.5.js
JavaScriptList[]=novenimagecropper.js

[StylesheetSettings]
CSSFileList[]=novenimagecropper.css
CSSFileList[]=jquery-ui-novenimagecropper.css
CSSFileList[]=jquery.Jcrop.css

*/
