<!DOCTYPE TS><TS>
<context>
    <name>extension/novenimagecropper</name>
    <message>
        <source>Crop image</source>
        <translation>Rogner l'image</translation>
    </message>
    <message>
        <source>Image cropping interface</source>
        <translation>Interface de rognage</translation>
    </message>
    <message>
        <source>Aspect Ratio</source>
        <translation>Échelle d'aspect</translation>
    </message>
    <message>
        <source>No aspect ratio</source>
        <translation>Pas d'échelle</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Prévisualiser</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Back to selection</source>
        <translation>Retour à la sélection</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Enregistrer</translation>
    </message>
</context>
<context>
    <name>extension/novenimagecropper/error</name>
    <message>
        <source>Invalid crop mode</source>
        <translation>Mode crop invalide</translation>
    </message>
    <message>
        <source>Please make a selection to crop your image</source>
        <translation>Faites une sélection pour rogner votre image</translation>
    </message>
    <message>
        <source>Uploaded file is not a supported image file (PNG/JPG/GIF)</source>
        <translation>Le fichier chargé n'est pas un fichier image supporté (PNG/JPG/GIF)</translation>
    </message>
</context>
</TS>
