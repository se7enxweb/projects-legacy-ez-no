<?php /* #?ini charset="utf-8"?

[eZJSCore]
PreferredLibrary=jquery

[ezjscServer_novimgcrop]
# Url to test this server function(return current time):
# <root>/ezjscore/call/novimgcrop::imageReference::<AttributeID>::<ContentObjectVersion>::<ContentObjectID>
Class=NovImgCropServerFunctions

*/
