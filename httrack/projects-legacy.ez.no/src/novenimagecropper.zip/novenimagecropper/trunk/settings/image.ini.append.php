<?php /* #?ini charset="utf-8"?

[AliasSettings]
AliasList[]=novenimagecropper_reference

[novenimagecropper_reference]
Filters[]
Filters[]=geometry/scaledownonly=600;600

