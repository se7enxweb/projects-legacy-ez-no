<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR" sourcelanguage="en">
<context>
    <name>extension/novenimagecropper</name>
    <message>
        <source>Crop image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image cropping interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back to selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/novenimagecropper/error</name>
    <message>
        <source>Invalid crop mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please make a selection to crop your image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uploaded file is not a supported image file (PNG/JPG/GIF)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Neither ImageMagick nor GD image handler is enabled ! Please check your image.ini configuration</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
