<?php /*

[General]
AllowedTypes[]=GMapItem

[GMapItem]
Name=Google Map item
ManualAddingOfItems=disabled
CustomAttributes[]=parent_node_id
CustomAttributes[]=classes
CustomAttributes[]=limit
UseBrowseMode[parent_node_id]=true
ViewList[]=gmap_item_large
ViewName[gmap_item_large]=GMap Item (large)

*/ ?>