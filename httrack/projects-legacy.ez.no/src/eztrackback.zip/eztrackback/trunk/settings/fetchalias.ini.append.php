<?php /*

[trackbacks]
Constant[sort_by]=published;0
Constant[class_filter_type]=include
Constant[class_filter_array]=trackback
Parameter[parent_node_id]=parent_node_id
Module=content
FunctionName=list

*/ ?>