<?php /*

[trackback_line]
Source=node/view/line.tpl
MatchFile=line/trackback.tpl
Subdir=templates
Match[class_identifier]=trackback

*/ ?>