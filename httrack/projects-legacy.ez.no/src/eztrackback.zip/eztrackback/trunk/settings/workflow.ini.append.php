<?php /*

[EventSettings]
ExtensionDirectories[]=eztrackback
AvailableEventTypes[]=event_eztrackback

*/ ?>