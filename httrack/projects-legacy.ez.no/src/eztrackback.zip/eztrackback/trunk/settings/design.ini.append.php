<?php /*

[ExtensionSettings]
DesignExtensions[]=eztrackback

*/ ?>