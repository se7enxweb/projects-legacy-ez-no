<?php /*

[ModuleSettings]
ExtensionRepositories[]=eztrackback

*/
?>
