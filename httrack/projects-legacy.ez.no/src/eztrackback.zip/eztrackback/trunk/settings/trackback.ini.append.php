<?php /*

[TrackbackSettings]
BlogName=eZ weblog
BlogClassIdentifier=blog_post
TrackbackAttribute=trackback_urls
FetchLines=1000

[BlogClassSettings]
TitleAttribute=title
ExcerptAttribute=body

*/ ?>