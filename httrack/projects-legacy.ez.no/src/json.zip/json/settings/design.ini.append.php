<?php
/*
[ExtensionSettings]
DesignExtensions[]=json
*/
?>
