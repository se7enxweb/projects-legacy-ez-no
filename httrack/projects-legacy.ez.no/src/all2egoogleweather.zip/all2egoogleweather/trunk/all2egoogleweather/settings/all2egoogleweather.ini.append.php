<?php /* #?ini charset="utf-8"?

[GoogleSettings]
# RequestURL=http://www.google.de/ig/api?weather=59755+Deutschland
RequestURL=http://www.google.de/ig/api

RequestAPI=weather


*/ ?>
