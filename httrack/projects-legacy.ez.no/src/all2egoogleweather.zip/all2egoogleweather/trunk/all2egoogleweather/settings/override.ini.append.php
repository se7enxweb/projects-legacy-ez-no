<?php /* #?ini charset="utf-8"?

[all2egoogleweather_full]
Source=node/view/full.tpl
MatchFile=full/all2eweather.tpl
Subdir=templates
Match[class_identifier]=all2eweather


*/ ?>
