<!DOCTYPE TS><TS>
<context>
    <name>design/standard/ezpm</name>
    <message>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Store draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recipient</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private messaging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blacklist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to blacklist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to contacts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PM menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create new message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Re: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to read this message</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
