<?php /* #?ini charset="iso-8859-1"?

[GeneralSettings]
# Set email notification enabled or disabled
EmailNotification=disabled

*/?>