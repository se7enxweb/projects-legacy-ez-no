<?php /* #?ini charset="utf-8"?

[CompressSettings]
DirectoryPath[]=extension/my_extension1/design/standard/javascript/
DirectoryPath[]=extension/my_extension1/design/mydesign/javascript/
DirectoryPath[]=extension/my_extension1/design/mydesign/stylesheets/
DirectoryPath[]=extension/my_extension2/design/mydesign/javascript/
DirectoryPath[]=extension/my_extension2/design/mydesign/stylesheets/
Extension[]=css
Extension[]=js

**/ ?>
