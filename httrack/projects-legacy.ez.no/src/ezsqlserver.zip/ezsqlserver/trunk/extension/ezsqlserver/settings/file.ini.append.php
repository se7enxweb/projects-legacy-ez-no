<?php /*
[ClusteringSettings]
ExtensionDirectories[]=ezsqlserver
*/ ?>
