<?php /*
[DatabaseSettings]
ImplementationAlias[sqlserver]=ezsqlserver
*/ ?>
