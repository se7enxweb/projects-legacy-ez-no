<?php

class ezsqlserverInfo
{
    function info()
    {
        return array( 'Name' => "eZ SQL Server",
                      'Version' => "0.1",
                      'Copyright' => "Copyright (C) 2009 Gaetano Giunta",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}

?>