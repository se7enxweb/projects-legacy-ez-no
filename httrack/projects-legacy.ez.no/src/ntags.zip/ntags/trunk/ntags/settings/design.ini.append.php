<?php /*
[ExtensionSettings]
DesignExtensions[]=ntags

[StylesheetSettings]
CSSFileList[]=jquery/redmond/jquery-ui-1.7.2.custom.css
CSSFileList[]=ntags.css

[JavaScriptSettings]
JavaScriptList[]=namespace.js
JavaScriptList[]=jquery-1.3.2.min.js
JavaScriptList[]=ntags.js
JavaScriptList[]=labs_json.js
*/ ?>
