<?php /*
[RegionalSettings]
TranslationExtensions[]=ntags

[TemplateSettings]
ExtensionAutoloadPath[]=ntags
*/ ?>
