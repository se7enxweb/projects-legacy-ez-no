<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US" sourcelanguage="en_US">
<context>
    <name>ntags/content/edit</name>
    <message>
        <source>Free tags</source>
        <translation>Additional tags</translation>
   </message>
   <message>
        <source>Show predefined tags</source>
        <translation>View predefined tags</translation>
   </message>
</context>
<context>
    <name>ntags/utils/taglist</name>
    <message>
        <source>Remove selected</source>
        <translation>Remove selected tags</translation>
    </message>
</context>
</TS>
