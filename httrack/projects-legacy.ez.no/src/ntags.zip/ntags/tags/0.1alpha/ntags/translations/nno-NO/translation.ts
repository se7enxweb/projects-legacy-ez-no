<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="nn_NO" sourcelanguage="en_US">
<context>
    <name>design/admin/setup/cache</name>
    <message>
        <source>Invert selection.</source>
        <translation>Byt om utval.</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
</context>
<context>
    <name>kernel/navigationpart</name>
    <message>
        <source>Tags</source>
        <comment>Navigation part</comment>
        <translation>Stikkord</translation>
    </message>
</context>
<context>
    <name>ntags</name>
    <message>
        <source>Tags</source>
        <translation>Stikkord</translation>
    </message>
</context>
<context>
    <name>ntags/content/edit</name>
    <message>
        <source>Show predefined tags</source>
        <translation>Syn hovudstikkord</translation>
    </message>
    <message>
        <source>Free tags</source>
        <translation>Tilleggsstikkord</translation>
    </message>
</context>
<context>
    <name>ntags/utils/taglist</name>
    <message>
        <source>Please clear the template cache</source>
        <translation>Ver vensam tøm malcachen</translation>
    </message>
    <message>
        <source>Your changes to predefined tags will take effect after the template cache has been cleared.</source>
        <translation>Endringane av hovudstikkordlista vil trå i kraft etter at malcachen er tømd.</translation>
    </message>
    <message>
        <source>Predefined tags</source>
        <translation>Hovudstikkord</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>Fjern valde stikkord</translation>
    </message>
    <message>
        <source>Define new tag</source>
        <translation>Laga nytt stikkord</translation>
    </message>
    <message>
        <source>Create new tag:</source>
        <translation>Lag nytt stikkord:</translation>
    </message>
    <message>
        <source>Create new</source>
        <translation>Lag nytt</translation>
    </message>
</context>
</TS>
