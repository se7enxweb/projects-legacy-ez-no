<?php /*
[RegionalSettings]
TranslationExtensions[]=ntags
*/ ?>
