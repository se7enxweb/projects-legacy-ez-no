<?php /* #?ini charset="utf-8"?
# uncomment to apply a special su line view template
#[user_line_tpl]
#Source=node/view/line.tpl
#MatchFile=user_line.tpl
#Subdir=templates
#Match[class_identifier]=user
*/ ?>