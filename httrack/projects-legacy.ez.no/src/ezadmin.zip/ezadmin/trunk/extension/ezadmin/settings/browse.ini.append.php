<?php /* #?ini charset="utf-8"?
[BrowseNewOwner]
StartNode=users
SelectionType=single
ReturnType=ObjectID
Class[]
Class[]=user
#Class[]=folder
#TopLevelNodes[]
#TopLevelNodes[]=users
*/ ?>