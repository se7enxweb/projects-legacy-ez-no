<?php /* #?ini charset="utf-8"?

#[Settings]
#RemoteURL=UrlToTheSiteForReading
#ContentDevider[1]=<!--CONTENT-->

*/ ?>