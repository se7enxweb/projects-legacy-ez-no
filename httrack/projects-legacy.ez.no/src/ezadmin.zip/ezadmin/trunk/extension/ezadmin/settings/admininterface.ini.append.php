<?php /* #?ini charset="utf-8"?
[AdditionalMenuSettings]
ContextMenuTemplateArray[]=node/ownercontextmenu.tpl
SubitemsContextMenuTemplateArray[]=node/ownersubitemscontextmenu.tpl
*/ ?>