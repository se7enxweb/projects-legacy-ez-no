<?php /* #?ini charset="utf-8"?
[Maintance]
PageLayout=ezadmin/maintance_pagelayout.tpl
*/ ?>