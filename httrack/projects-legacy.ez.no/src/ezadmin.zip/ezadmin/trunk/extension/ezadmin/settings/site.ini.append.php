<?php /* #?ini charset="utf-8"?

[DesignSettings]
AdditionalSiteDesignList[]=admin2
AdditionalSiteDesignList[]=admin
AdditionalSiteDesignList[]=standard

[RegionalSettings]
TranslationExtensions[]=ezadmin

[RoleSettings]
PolicyOmitList[]=test/html
PolicyOmitList[]=remote/content
PolicyOmitList[]=remote/loadpage

*/ ?>
