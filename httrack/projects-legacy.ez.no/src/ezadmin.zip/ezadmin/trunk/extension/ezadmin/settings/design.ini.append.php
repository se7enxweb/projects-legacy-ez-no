<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=ezadmin

[JavaScriptSettings]
BackendJavaScriptList[]=ezadmin.js
FrontendJavaScriptList[]=ezadmin.js

*/ ?>