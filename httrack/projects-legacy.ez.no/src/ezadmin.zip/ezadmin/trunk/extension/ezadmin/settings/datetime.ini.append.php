<?php /* #?ini charset="utf-8"?
[ClassSettings]
Formats[ISO8601]=%Y-%m-%dT%H:%i:%s %O
*/ ?>