<?php /*

[ezjscServer]
FunctionList[]=ezadmin

[ezjscServer_ezadmin]
Class=ezAdminServerFunctions
Functions[]=ezadmin

*/ ?>