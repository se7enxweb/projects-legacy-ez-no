[PHP]
PHPOperatorList[function_exists]=function_exists
