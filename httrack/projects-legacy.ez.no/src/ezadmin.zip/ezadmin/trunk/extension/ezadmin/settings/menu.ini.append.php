<?php /* #?ini charset="utf-8"?
[NavigationPart]
Part[ezadmin]=Admin

[TopAdminMenu]
Tabs[]=ezadmin

[Topmenu_ezadmin]
NavigationPartIdentifier=ezadmin
Name=Admin
Tooltip=Helps Administrating your System
URL[]
URL[default]=/admin/menu
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=false
*/ ?>