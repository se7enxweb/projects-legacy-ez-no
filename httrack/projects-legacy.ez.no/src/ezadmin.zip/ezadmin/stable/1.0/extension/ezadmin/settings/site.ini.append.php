<?php /* #?ini charset="utf-8"?
[RoleSettings]
PolicyOmitList[]=admin/maintance
PolicyOmitList[]=admin/recalluser
PolicyOmitList[]=admin/menu
PolicyOmitList[]=admin/changeuserview
PolicyOmitList[]=admin/frame
*/ ?>
