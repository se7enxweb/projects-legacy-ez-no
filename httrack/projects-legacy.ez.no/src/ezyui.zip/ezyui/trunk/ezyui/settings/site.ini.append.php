<?php /* #?ini charset="utf-8"?


[TemplateSettings]
ExtensionAutoloadPath[]=ezyui


[SSLZoneSettings] 
ModuleViewAccessMode[ezyui/*]=keep

[RoleSettings]
PolicyOmitList[]=ezyui/hello
PolicyOmitList[]=ezyui/call

[SiteAccessSettings]
AnonymousAccessList[]=ezyui/hello
AnonymousAccessList[]=ezyui/call



*/ ?>