<?php /*

[RoleSettings]
PolicyOmitList[]=ezrest/login

*/ ?>
