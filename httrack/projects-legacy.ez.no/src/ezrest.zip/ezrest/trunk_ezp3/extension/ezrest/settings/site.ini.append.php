<?php /*

[RoleSettings]
PolicyOmitList[]=ezrest/login

[SiteAccessSettings]
AnonymousAccessList[]=ezrest/login

*/ ?>
