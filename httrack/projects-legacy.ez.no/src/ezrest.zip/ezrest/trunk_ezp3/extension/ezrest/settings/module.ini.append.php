<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezrest

*/ ?>
