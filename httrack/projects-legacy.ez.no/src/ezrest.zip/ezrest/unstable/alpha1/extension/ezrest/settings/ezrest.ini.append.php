<?php /*


[RESTSettings]
# List of eZ REST handlers. The handlers listed are
# class names extending the eZRestHandler class.
# HandlerList[]

# Login handler is provided by this extension.
HandlerList[]=eZRESTLoginHandler

[RESTClientSettings]
# REST client connection timeout
ConnectionTimeout=30


*/ ?>
