<?php /*?ini charset="iso-8859-1"?

[ModuleSettings]
# A list of extensions which have modules
# It's common to create a settings/module.ini.append file
# in your extension and add the extension name to automatically
# get modules from the extension when it's turned on.
ExtensionRepositories[]=ezflippingbook


# An array of known modules in the system, extensions should
# append to this array.
# This is currently used to avoid URL aliases overriding
# existing module names
ModuleList[]=flippingbookxml

?>
