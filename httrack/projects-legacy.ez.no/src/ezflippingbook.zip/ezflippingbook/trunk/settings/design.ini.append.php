<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=ezflippingbook

[StylesheetSettings]
CSSFileList[]=smoothgallery/jd.gallery.css
CSSFileList[]=smoothgallery/layout.css

[JavaScriptSettings]
JavaScriptList[]=smoothgallery/mootools.js
JavaScriptList[]=smoothgallery/jd.gallery.js

*/

?>
