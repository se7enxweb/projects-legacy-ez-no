<?php /* #?ini charset="utf-8"?

[flippingbook_view_full]
Source=node/view/full.tpl
MatchFile=view/full/flippingbook.tpl
Subdir=templates
Match[class_identifier]=flippingbook

[flippingbook_view_xml]
Source=node/view/xml.tpl
MatchFile=view/xml/flippingbook.tpl
Subdir=templates
Match[class_identifier]=flippingbook

[flippingbook_image_view]
Source=node/view/xml.tpl
MatchFile=view/xml/image.tpl
Subdir=templates
Match[class_identifier]=image

*/ ?>
