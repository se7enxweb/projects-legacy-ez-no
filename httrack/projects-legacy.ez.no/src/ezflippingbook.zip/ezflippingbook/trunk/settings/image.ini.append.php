<?php /* #?ini charset="utf-8"?

[AliasSettings]
AliasList[]=flippingbook
#AliasList[]=vignette_galerie
# Vignette = Thumb

[flippingbook]
Reference=original

#[vignette_galerie]
#Reference=original
#Filters[]=geometry/scaledownonly=150;150

*/ ?>
