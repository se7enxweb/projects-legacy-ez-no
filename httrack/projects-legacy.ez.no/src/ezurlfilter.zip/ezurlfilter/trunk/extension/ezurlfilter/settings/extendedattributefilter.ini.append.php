<?php /*

[eZURLFilter]
ExtensionName=ezurlfilter
ClassName=eZURLFilter
MethodName=createSqlParts
FileName=classes/ezurlfilter.php
*/ ?>