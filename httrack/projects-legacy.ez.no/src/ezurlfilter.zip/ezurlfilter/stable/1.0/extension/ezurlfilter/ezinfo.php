<?php

class ezurlfilterInfo
{
    function info()
    {
        return array(
            'Name' => '<a href="http://projects.ez.no/ezurlfilter">eZURL Filter</a>',
            'Version' => "1.x",
            'Copyright' => "Copyright (C) 2006-2008 Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}

?>