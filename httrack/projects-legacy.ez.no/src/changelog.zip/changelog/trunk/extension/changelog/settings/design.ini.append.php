<?php
/*

[ExtensionSettings]
DesignExtensions[]=changelog

*/
?>
