<?php
/*

[DataTypeSettings]
ExtensionDirectories[]=changelog
AvailableDataTypes[]=changelog

*/
?>
