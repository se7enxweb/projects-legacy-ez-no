<?php
class html5boilerplateInfo
{
    static function info()
    {
        return array(
            'Name' => '<a href="http://projects.ez.no/html5boilerplate">html5boilerplate</a>',
            'Version' => "1.0",
            'Copyright' => "All respective parties",
            'Author' => "Jani Tarvainen",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>