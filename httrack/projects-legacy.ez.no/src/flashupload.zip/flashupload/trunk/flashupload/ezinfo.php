<?php
class flashuploadInfo
{
    function info()
    {
        return array(
            'Name' => "Flashupload extension",
            'Version' => "1.0",
            'Copyright' => "Copyright (C) 2007 STEVOLAND LTD",
            'License' => "GNU General Public License v2.0",
            'Includes the following third-party software' => array( 'Name' => 'SWFUpload R5',
                                                                    'Version' => '0.8.3',
                                                                    'License' => 'MIT - Lars Huring and Mammon Media - 2006',
                                                                    'For more information' => '<a href="http://linebyline.blogspot.com">linebyline.blogspot.com</a>' )
     );
    }
}
?>