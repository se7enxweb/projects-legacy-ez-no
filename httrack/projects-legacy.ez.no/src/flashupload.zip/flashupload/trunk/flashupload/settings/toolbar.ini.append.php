<?php /* #?ini charset="iso-8859-1"?

[Tool]
AvailableToolArray[]=flashupload

[Toolbar_flashupload]
#Tool[]
Tool[]=flashupload

*/ ?>