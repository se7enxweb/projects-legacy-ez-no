<?php /* #?ini charset="utf-8"?

[PHP]

PHPOperatorList[session_name]=session_name

*/ ?>