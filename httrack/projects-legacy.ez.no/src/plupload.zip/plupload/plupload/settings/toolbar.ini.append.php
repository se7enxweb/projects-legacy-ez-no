<?php /* #?ini charset="iso-8859-1"?

[Toolbar_admin_right]
Tool[]=admin_ezplupload

?>
