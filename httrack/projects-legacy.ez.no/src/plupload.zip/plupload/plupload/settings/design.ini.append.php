<?php /* #?ini charset="iso-8859-1"?

[ExtensionSettings]
DesignExtensions[]=plupload

[StylesheetSettings]
CSSFileList[]=plupload.queue.css
*/ ?>
