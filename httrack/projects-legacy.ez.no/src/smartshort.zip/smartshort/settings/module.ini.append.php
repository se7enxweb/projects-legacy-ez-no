<?php /* #?ini charset="iso-8859-1"?
[ModuleSettings]
#The percentage of a strings length that is allowable to go over before switching to the next lowest level breakpoint (end punctuation, space, char).
AllowedDeviation=20

HangingTags[]=<p
HangingTags[]=<a
HangingTags[]=<b
HangingTags[]=<i
HangingTags[]=<br
HangingTags[]=<table
HangingTags[]=<tr
HangingTags[]=<td
HangingTags[]=<ol
HangingTags[]=<ul
HangingTags[]=<li
HangingTags[]=<h1
HangingTags[]=<h2
HangingTags[]=<h3
HangingTags[]=<h3
HangingTags[]=<h4
HangingTags[]=<h5
HangingTags[]=<h6

*/ ?>
