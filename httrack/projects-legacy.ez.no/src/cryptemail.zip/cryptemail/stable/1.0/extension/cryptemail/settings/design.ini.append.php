[ExtensionSettings]
DesignExtensions[]=cryptemail

[JavaScriptSettings]
JavaScriptList[]=email.js
