[TemplateSettings]
ExtensionAutoloadPath[]=cryptemail