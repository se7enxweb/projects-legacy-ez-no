<?php /*

[CustomTagSettings]
AvailableCustomTags[]=crypt_email

*/ ?>