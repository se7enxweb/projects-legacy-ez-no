<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezonrails

ModuleList[]=ezonrails

*/ ?>
