<?php /*

# Cache item entry (for eZ Publish 4.3 and up)
[Cache]
CacheItems[]=ezonrails

[Cache_ezonrails]
name=eZOnRails extension cache
path=ezonrails

*/ ?>