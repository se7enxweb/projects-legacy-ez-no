<?php
$viewdesc = array (
  'desc' => 'Provides an interface for generating an overview of all URLs.',
);
?>