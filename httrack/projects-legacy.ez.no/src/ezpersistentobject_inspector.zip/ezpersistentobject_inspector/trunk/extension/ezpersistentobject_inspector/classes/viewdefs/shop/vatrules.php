<?php
$viewdesc = array (
  'desc' => 'Provides an interface for generating an overview of the VAT charging rules.',
);
?>