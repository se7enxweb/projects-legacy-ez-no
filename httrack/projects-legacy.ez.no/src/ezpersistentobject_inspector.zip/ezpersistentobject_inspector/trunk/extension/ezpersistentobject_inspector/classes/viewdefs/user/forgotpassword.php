<?php
$viewdesc = array (
  'desc' => 'Provides an interface for situations where a user forgets his/her password.',
);
?>