<?php
$viewdesc = array (
  'desc' => 'Provides an interface for displaying the information that was collected.',
);
?>