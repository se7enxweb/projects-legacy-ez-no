<?php

// Empty file needed for this module to officially 'exist'
$ViewList = array();

?>