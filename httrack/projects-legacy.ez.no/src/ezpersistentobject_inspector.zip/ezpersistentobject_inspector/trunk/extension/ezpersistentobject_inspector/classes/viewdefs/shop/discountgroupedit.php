<?php
$viewdesc = array (
  'desc' => 'Provides an interface for editing a discount group.',
);
?>