<?php
$viewdesc = array (
  'desc' => 'Provides an interface for viewing the reverse related objects of a node and it\'s children (recursively).',
);
?>