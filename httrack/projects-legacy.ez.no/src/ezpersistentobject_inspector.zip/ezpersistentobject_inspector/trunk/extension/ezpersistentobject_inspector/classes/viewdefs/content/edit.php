<?php
$viewdesc = array (
  'desc' => 'Provides an interface for editing and translating the contents of objects.',
);
?>