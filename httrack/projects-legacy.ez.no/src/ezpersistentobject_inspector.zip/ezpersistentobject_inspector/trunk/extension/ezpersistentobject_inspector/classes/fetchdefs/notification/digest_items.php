<?php
$fetchdesc = array (
  'desc' => 'Fetches notification items that should be sent as digest to the current user.',
);
?>