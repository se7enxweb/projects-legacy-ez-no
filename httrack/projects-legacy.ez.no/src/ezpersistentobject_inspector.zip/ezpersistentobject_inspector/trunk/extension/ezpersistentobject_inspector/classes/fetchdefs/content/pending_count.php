<?php
$fetchdesc = array (
  'return' => 'An integer revealing the number of pending objects.',
  'desc' => 'Fetches the number of pending objects for the current user.',
);
?>