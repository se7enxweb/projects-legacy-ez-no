<?php
$viewdesc = array (
  'desc' => 'Provides an interface for moving an event to a lower position.',
);
?>