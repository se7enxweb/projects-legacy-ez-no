<?php
$viewdesc = array (
  'desc' => 'Provides an interface for managing content translations.',
);
?>