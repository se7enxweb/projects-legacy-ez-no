<?php
$fetchdesc = array (
  'return' => 'An array of notification handler objects.',
  'desc' => 'Fetches the available notification handlers.',
);
?>