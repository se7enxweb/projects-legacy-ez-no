<?php
$viewdesc = array (
  'desc' => 'Provides an interface for generating a class overview for a class group.',
);
?>