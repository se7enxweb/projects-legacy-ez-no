<?php
$viewdesc = array (
  'desc' => 'Provides an interface for viewing and managing the current user\'s wishlist.',
);
?>