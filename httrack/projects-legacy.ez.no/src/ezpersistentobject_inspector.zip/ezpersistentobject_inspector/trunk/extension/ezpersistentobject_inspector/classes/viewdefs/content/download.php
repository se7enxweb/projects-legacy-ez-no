<?php
$viewdesc = array (
  'desc' => 'Provides an interface for downloading files stored by the "File" datatype.',
);
?>