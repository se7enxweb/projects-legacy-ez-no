<?php
$viewdesc = array (
  'desc' => 'Provides a mechanism that adds a new subtree notification.',
);
?>