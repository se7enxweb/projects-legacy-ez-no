<?php
$viewdesc = array (
  'desc' => 'Provides an interface for viewing an order.',
);
?>