<?php
$viewdesc = array (
  'desc' => 'Provides an interface for viewing information the orders of a customer.',
);
?>