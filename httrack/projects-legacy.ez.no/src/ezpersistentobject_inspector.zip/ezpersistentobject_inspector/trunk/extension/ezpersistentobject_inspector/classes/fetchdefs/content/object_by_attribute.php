<?php
$fetchdesc = array (
  'desc' => 'DEPRECATED',
);
?>