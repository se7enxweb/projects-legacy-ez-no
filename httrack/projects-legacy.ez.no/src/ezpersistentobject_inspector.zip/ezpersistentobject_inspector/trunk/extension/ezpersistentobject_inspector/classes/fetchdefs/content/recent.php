<?php
$fetchdesc = array (
  'return' => 'An array of ezcontentbrowserecent objects or FALSE.',
  'desc' => 'Fetches nodes where the current user recently published something.',
);
?>