<?php
$viewdesc = array (
  'desc' => 'Provides an overview of the current user\'s pending items.',
);
?>