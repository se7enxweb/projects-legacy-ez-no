<?php
$fetchdesc = array (
  'return' => 'The number of logged in users (as an integer).',
  'desc' => 'Fetches the number of users that are logged in.',
);
?>