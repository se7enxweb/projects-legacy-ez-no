<?php
$fetchdesc = array (
  'desc' => 'Not documented yet.',
);
?>