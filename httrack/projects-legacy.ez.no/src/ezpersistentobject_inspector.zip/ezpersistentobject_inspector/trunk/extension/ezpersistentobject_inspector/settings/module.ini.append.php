<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezpersistentobject_inspector
ModuleList[]=internaldocumentation

*/ ?>