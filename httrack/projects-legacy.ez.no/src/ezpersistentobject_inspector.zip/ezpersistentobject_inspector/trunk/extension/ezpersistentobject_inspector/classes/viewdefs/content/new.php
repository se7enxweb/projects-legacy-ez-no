<?php
$viewdesc = array (
  'desc' => 'Loads a template that can be used to display new content since last visit.',
);
?>