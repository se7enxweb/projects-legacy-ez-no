<?php
$fetchdesc = array (
  'return' => 'An ezuser object.',
  'desc' => 'Fetches the user that is currently logged in.',
);
?>