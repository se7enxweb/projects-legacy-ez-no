<?php
$viewdesc = array (
  'desc' => 'Loads a template that can fetch objects which use keyword.',
);
?>