<?php
$ezpodesc = array (
  'desc' => 'Contains information about a group of multi-options.',
  'persistent' => false,
  'attributes' => 
  array (
  ),
);
?>