<?php
$fetchdesc = array (
  'return' => 'An ezbasket object.',
  'desc' => 'Fetches the current user\'s shopping basket.',
);
?>