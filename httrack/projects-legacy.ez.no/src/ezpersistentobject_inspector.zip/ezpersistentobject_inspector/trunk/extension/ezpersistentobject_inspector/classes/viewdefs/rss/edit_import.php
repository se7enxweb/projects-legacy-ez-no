<?php
$viewdesc = array (
  'desc' => 'Provides an interface for editing an RSS import.',
);
?>