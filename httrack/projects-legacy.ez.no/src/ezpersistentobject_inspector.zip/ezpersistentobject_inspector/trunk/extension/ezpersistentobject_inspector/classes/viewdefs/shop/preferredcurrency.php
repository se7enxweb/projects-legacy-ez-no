<?php
$viewdesc = array (
  'desc' => 'Provides an interface for setting the user\'s preferred currency.',
);
?>