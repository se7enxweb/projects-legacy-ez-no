<?php
$fetchdesc = array (
  'return' => 'An array of hashes (see below).',
  'desc' => 'Fetches all available navigation parts.',
);
?>