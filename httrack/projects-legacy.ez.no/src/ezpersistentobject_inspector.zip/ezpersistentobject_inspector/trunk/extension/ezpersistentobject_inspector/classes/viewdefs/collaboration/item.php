<?php
$viewdesc = array (
  'desc' => 'Not documented yet.',
);
?>