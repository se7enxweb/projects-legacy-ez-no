<?php
$viewdesc = array (
  'desc' => 'Provides an interface for assigning roles to users and user groups.',
);
?>