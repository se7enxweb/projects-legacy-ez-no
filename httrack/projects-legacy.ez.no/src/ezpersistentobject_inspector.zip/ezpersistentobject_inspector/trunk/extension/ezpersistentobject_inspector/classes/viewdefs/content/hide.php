<?php
$viewdesc = array (
  'desc' => 'Provides an interface for hiding and revealing nodes.',
);
?>