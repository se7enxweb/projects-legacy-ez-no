<?php
$viewdesc = array (
  'desc' => 'Provides an interface for launching the main notification processing script and for generating a new time event.',
);
?>