<?php
$viewdesc = array (
  'desc' => 'Provides an interface for selecting node(s) by browsing the node tree.',
);
?>