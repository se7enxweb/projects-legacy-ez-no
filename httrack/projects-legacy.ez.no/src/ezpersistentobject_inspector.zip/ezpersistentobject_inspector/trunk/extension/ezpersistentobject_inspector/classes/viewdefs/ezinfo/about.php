<?php
$viewdesc = array (
  'desc' => 'Provides information about the system (version number, etc.).',
);
?>