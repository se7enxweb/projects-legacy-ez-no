<?php
$fetchdesc = array (
  'params' => 
  array (
    'user_id' => 
    array (
      'type' => 'integer',
      'required' => true,
      'desc' => 'The user to fetch policies from',
    ),
  ),
  'return' => 'An array of hashes or FALSE.',
  'desc' => 'Fetches the policies that are available for a user.',
);
?>