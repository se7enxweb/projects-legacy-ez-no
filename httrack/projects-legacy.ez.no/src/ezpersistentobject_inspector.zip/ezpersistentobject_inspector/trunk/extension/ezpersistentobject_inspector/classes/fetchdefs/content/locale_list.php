<?php
$fetchdesc = array (
  'return' => 'An array of ezlocale objects.',
  'desc' => 'Fetches the available locales.',
);
?>