<?php
$fetchdesc = array (
  'desc' => 'Fetches the notification handlers for the notification items that should be sent as digest to the current user.',
);
?>