<?php
$viewdesc = array (
  'desc' => 'Provides the checkout interface.',
);
?>