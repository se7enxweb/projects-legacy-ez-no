<?php
$viewdesc = array (
  'desc' => 'Provides an interface to the class group removal mechanism.',
);
?>