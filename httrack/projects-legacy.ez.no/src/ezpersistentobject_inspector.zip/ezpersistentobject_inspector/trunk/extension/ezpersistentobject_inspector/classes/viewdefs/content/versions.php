<?php
$viewdesc = array (
  'desc' => 'Provides an interface for managing the versions of an object (DEPRECATED).',
);
?>