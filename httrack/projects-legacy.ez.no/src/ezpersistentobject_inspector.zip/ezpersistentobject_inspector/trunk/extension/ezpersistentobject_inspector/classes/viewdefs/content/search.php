<?php
$viewdesc = array (
  'desc' => 'Provides the standard search interface.',
);
?>