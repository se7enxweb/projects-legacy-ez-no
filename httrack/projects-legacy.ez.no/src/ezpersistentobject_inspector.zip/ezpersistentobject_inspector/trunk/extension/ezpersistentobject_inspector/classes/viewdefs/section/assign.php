<?php
$viewdesc = array (
  'desc' => 'Provides an interface for assigning objects to a section.',
);
?>