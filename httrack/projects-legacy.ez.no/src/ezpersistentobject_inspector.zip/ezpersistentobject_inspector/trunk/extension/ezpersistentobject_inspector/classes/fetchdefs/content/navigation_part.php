<?php
$fetchdesc = array (
  'params' => 
  array (
    'identifier' => 
    array (
      'type' => 'string',
      'required' => true,
      'desc' => 'The identifier of the desired navigation part.',
    ),
  ),
  'return' => 'An associative array (see below) or FALSE.',
  'desc' => 'Fetches information about a navigation part.',
);
?>