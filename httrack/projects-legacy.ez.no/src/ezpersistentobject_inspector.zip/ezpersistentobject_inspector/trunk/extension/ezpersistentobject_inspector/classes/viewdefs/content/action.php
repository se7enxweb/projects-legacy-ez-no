<?php
$viewdesc = array (
  'desc' => 'Provides an interface to different actions (AddToBasket, SwapNode, etc.).',
);
?>