<?php
$viewdesc = array (
  'desc' => 'Forces the system to use an alternate pagelayout.',
);
?>