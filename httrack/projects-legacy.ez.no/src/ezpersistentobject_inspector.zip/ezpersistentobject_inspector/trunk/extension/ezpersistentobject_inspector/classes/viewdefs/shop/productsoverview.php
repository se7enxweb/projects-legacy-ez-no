<?php
$viewdesc = array (
  'desc' => 'Provides an interface for generating an overview of products and allows sorting by product\'s name or price.',
);
?>