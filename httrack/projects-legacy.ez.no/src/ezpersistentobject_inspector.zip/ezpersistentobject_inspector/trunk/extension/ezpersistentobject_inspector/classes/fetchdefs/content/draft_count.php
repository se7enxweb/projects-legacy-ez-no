<?php
$fetchdesc = array (
  'return' => 'The number of drafts (as an integer) that belong to the current user.',
  'desc' => 'Fetches the number of drafts that belong to the current user.',
);
?>