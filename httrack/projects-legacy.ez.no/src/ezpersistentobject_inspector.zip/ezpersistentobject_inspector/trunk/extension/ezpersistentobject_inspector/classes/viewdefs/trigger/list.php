<?php
$viewdesc = array (
  'desc' => 'Provides an interface for viewing and managing the workflow triggers.',
);
?>