<?php
$viewdesc = array (
  'desc' => 'Provides an interface for viewing and removing the collections of an object.',
);
?>