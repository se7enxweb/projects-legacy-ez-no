<?php
$viewdesc = array (
  'desc' => 'Provides an interface for viewing currencies and makes it possible to edit some of the currency\'s attributes for several currencies at the same time. Allows to update auto rates for all currencies.',
);
?>