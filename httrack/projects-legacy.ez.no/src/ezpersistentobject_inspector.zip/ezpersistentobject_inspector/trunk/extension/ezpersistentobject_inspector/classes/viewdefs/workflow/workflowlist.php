<?php
$viewdesc = array (
  'desc' => 'Provides an interface for generating a list of workflows that belong to a group.',
);
?>