<?php /*

[CronjobSettings]
ExtensionDirectories[]=dbi_contentreviewdate

[CronjobPart-contentreviewnotify]
Scripts[]
Scripts[]=contentreviewnotify.php

*/ ?>
