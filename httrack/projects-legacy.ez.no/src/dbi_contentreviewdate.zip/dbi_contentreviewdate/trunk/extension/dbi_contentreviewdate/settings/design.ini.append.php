<?php /*

[ExtensionSettings]
DesignExtensions[]=dbi_contentreviewdate

*/ ?>