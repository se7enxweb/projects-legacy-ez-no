<?php /* #?ini charset="utf-8"?
[ProxySettings]
SocketTimeout=3

#[vars]
#name[]
#name[]=xrow
#name[]=ez

#[xrow]
#URL=http://www.xrow.de/home/xrow_gbr/contact
#ID=maincontent-design
#Comment=xrows contact-form

#[ez]
#URL=http://ez.no/company/contact
#ID=main
*/ ?>