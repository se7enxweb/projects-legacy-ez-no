<?php

class cmsxBrDataTypesInfo
{
    static function info()
    {
        return array( 'Name'      => 'Brazilian datatypes extension',
                      'Version'   => '1.0-0',
                      'Copyright' => "CMSXpert (C) 2010 <a href='//www.cmsxpert.com.br' title='CMSXpert'>CMSXpert</a>",
                      'License'   => 'GNU General Public License v2.0' );
    }
}


?>