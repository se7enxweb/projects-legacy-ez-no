<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=cmsxbrdatatypes
AvailableDataTypes[]=cmsxcpfcnpj
AvailableDataTypes[]=cmsxbrstate
AvailableDataTypes[]=cmsxbrphone

*/ ?>