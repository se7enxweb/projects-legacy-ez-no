<?php /*
#
# $Id: design.ini.append.php 43 2011-06-27 20:38:05Z dpobel $
# $HeadURL: http://svn.projects.ez.no/autostatus/trunk/extension/autostatus/settings/design.ini.append.php $
#

[ExtensionSettings]
DesignExtensions[]=autostatus

[StylesheetSettings]
BackendCSSFileList[]=autostatus.css

*/ ?>
