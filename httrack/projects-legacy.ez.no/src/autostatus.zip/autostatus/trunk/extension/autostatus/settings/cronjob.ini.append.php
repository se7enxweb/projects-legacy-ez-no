<?php /*
#
# $Id: cronjob.ini.append.php 54 2011-06-29 20:05:34Z dpobel $
# $HeadURL: http://svn.projects.ez.no/autostatus/trunk/extension/autostatus/settings/cronjob.ini.append.php $
#

[CronjobSettings]
ExtensionDirectories[]=autostatus

[CronjobPart-infrequent]
Scripts[]=clean_events.php

*/ ?>
