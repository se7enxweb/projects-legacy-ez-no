[ExtensionSettings]
DesignExtensions[]=menustring
