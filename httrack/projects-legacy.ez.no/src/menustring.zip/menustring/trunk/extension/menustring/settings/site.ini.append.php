[TemplateSettings]
ExtensionAutoloadPath[]=menustring