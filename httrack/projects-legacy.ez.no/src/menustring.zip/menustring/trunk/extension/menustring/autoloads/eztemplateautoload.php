<?php

// Operator autoloading

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/menustring/autoloads/str_replace.php',
                                    'class' => 'strReplaceOperator',
                                    'operator_names' => array( 'str_replace' ) );

?>