[DataTypeSettings]
ExtensionDirectories[]=menustring
AvailableDataTypes[]=menustring
