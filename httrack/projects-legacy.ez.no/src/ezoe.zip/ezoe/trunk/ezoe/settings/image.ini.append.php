<?php /* #?ini charset="utf-8"?
# eZ publish configuration file for images


## Example for making image size name more human readable in OE gui
#[medium]
#GUIName=Medium Size (200 x 290)
#Reference=
#Filters[]
#Filters[]=geometry/scaledownonly=200;290

## Example for hiding image size from OE gui drop down list
#[large]
#HideFromRelations=enabled
#Reference=
#Filters[]
#Filters[]=geometry/scaledownonly=360;440

*/ ?>