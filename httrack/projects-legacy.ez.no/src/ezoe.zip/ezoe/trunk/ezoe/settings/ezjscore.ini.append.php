<?php /* #?ini charset="utf-8"?
# eZ publish configuration file for images


[ezjscServer_ezoe]
Class=ezoeServerFunctions
#File=extension/ezoe/classes/ezoeserverfunctions.php

*/ ?>