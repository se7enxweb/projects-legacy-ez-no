<?php /* #?ini charset="utf-8"?
# eZ Publish configuration file for ezxml

[HandlerSettings]
ExtensionRepositories[]=ezoe

[InputSettings]
Alias[ezsimplified]=ezoe

# For eZ Publish 4.1 and higher (above settings are for 4.0.x)
AliasClasses[eZSimplifiedXMLInput]=eZOEXMLInput


*/ ?>