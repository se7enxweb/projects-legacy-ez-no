Looking for older versions or svn history prior to eZOE 5.0.1 ?

* [5.0] svn history for versions older then 5.0.1 in the 5.x series can be found at:
http://svn.ez.no/svn/extensions/eztinymce/

* [3.x & 4.x] svn repo for older versions can be found at:
http://svn.ez.no/svn/extensions/ezdhtml/
(the stable php5 versions is placed under /unstable/ezdhtml_php5)
 