[EventSettings]
ExtensionDirectories[]=recurringorders

[OperationSettings]
AvailableOperationList[]=recurringorders_checkout