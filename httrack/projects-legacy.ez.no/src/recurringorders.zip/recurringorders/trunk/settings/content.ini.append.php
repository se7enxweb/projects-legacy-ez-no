[DataTypeSettings]
ExtensionDirectories[]=recurringorders
AvailableDataTypes[]=ezcreditcard
AvailableDataTypes[]=xrowbillingcycle
