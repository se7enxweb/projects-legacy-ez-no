[ModuleSettings]
ExtensionRepositories[]=recurringorders