<?php /* #?ini charset="utf8"?

[ExtensionSettings]
DesignExtensions[]=recurringorders

[JavaScriptSettings]
JavaScriptList[]=yui/yahoo/yahoo-min.js
JavaScriptList[]=yui/event/event-min.js
JavaScriptList[]=yui/dom/dom-min.js
JavaScriptList[]=yui/container/container-min.js
JavaScriptList[]=yui/calendar/calendar-min.js
JavaScriptList[]=yui/dragdrop/dragdrop-min.js
JavaScriptList[]=yui/logger/logger-min.js
*/ ?>
