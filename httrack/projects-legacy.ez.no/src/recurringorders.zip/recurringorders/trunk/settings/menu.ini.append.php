[NavigationPart]
Part[recurringorders]=Recurring orders

[TopAdminMenu]
Tabs[]=recurringorders

[Topmenu_recurringorders]
NavigationPartIdentifier=ezrecurringorders
Name=Recurring orders
Tooltip=Recurring orders adn subscriptions
URL[]
URL[default]=/recurringorders/forecast
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=false