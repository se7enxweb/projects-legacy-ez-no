<?php /* #?ini charset="utf-8"?
[GeneralSettings]
DaysAfterRetryOnError=2

[RecurringOrderSettings]
InstalledCardArray[]
InstalledCardsArray[1]=MasterCard
InstalledCardsArray[2]=Visa
InstalledCardsArray[3]=Amex
DefaultCycle=3
DisabledCycles[]
DisabledCycles[]=0
DisabledCycles[]=1
FailuresTillPause=3

[SubscriptionSettings]
# Name of the extension which has subscription handlers
SubscriptionHandlerRepository[]=recurringorders

# Installed subscription handlers
#SubscriptionHandlerArray[]=xrowexample

*/ ?>