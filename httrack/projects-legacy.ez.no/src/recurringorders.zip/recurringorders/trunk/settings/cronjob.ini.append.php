[CronjobSettings]
ScriptDirectories[]=extension/recurringorders/bin

#[CronjobPart-daily]
#Scripts[]=recurringorders.php

[CronjobPart-recurringorders]
Scripts[]=recurringorders.php
