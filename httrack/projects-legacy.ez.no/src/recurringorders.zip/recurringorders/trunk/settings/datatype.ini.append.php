[ViewSettings]
GroupedInput[]=ezcreditcard
GroupedInput[]=xrowbillingcycle

[EditSettings]
GroupedInput[]=ezcreditcard
GroupedInput[]=xrowbillingcycle

[CollectionSettings]
GroupedInput[]=ezcreditcard
GroupedInput[]=xrowbillingcycle