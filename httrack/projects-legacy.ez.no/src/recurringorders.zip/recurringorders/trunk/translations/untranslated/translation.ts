<!DOCTYPE TS><TS>
<context>
    <name>content/datatype/edit/xrowbillingcycle</name>
    <message>
        <source>Quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Period</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/parts/visual/menu</name>
    <message>
        <source>Recurring orders</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/customerlist</name>
    <message>
        <source>Forecast [%forecast]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The forecast list is empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages [%history]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collection ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The message list is empty.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/discountgroupmembershipview</name>
    <message>
        <source>Total recurring forecast on revenue</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>using payment gateway</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disabled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Current stored card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bank code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove debit card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>expires</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Card type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name on card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Security Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name of account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No card stored.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove credit card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Credit card number</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/shop</name>
    <message>
        <source>Billing Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping and Billing Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zip code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipping Address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/recurringorders</name>
    <message>
        <source>Your input has been stored.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>We have encountered problems with your credit card. Please update your profile.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(period %startdate% till %enddate%)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>Input required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mastercard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>American Express</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debit card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billing cycle</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Credit card</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input is required, if you have active subscriptions or recurring orders.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/classes/recurringordercollection</name>
    <message>
        <source>one time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>day(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>weeks(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>month(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>quarter(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>year(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>daily</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>weekly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>monthly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>quarterly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>yearly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>weeks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>quarters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>quarter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>standard/datatype/ezcreditcard</name>
    <message>
        <source>Not used</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
