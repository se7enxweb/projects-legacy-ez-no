<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=ezflickr
ModuleList[]=flickr

*/ ?>