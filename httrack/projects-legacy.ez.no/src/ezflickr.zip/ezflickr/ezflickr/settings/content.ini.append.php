<?php /*

[DataTypeSettings]
ExtensionDirectories[]=ezflickr
AvailableDataTypes[]=ezflickrimage

*/ ?>