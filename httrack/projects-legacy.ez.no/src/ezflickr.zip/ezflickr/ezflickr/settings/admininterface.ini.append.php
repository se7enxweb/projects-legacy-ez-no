<?php /* #?ini charset="iso-8859-1"?

[AdditionalMenuSettings]
ContextMenuTemplateArray[]=node/flickrcontextmenu.tpl
SubitemsContextMenuTemplateArray[]=node/flickrsubcontextmenu.tpl

*/ ?>
