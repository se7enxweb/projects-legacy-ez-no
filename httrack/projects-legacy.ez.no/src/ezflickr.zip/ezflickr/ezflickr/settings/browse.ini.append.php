<?php /* #?ini charset="iso-8859-1"?

[FlickrImportPlace]
StartNode=media
SelectionType=single
ReturnType=NodeID

*/ ?>
