<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ezflickr

*/ ?>