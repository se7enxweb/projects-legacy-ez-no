<?php

class eZFlickrException extends Exception
{

}

?>