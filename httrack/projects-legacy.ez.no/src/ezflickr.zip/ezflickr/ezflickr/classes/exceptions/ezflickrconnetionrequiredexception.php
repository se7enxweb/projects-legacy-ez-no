<?php

class eZFlickrConnectionRequiredException extends eZFlickrException
{

}

?>