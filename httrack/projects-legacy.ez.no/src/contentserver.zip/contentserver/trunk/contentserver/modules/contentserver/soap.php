<?php
include_once( 'extension/contentserver/classes/ezsoapcontentserver.php' );
?>
