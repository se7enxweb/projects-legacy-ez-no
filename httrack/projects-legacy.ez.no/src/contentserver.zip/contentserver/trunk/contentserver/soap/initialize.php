<?php

$server->registerObject( 
    'eZSOAPcontentserver', 
    'extension/contentserver/classes/ezsoapcontentserver.php' );

?>