<?php

class ContentServerInfo
{
    /*!
     Constructor
    */
    function info()
    {
        return array( 'name' => 'Contentserver',
                      'version' => '3.8',
                      'copyright' => 'Copyright © 2007 xrow GBR',
                      'info_url' => 'http://ez.no/products/partner_products/content_server',
                      'license' => 'Commercial' );
    }
}

?>
