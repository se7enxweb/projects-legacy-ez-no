Please read everything from the folder doc/*.

For installation read INSTALL.txt.