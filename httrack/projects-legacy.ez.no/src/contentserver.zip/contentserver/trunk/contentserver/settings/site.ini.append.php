[ExtensionSettings]
ActiveExtensions[]=contentserver

[SiteAccessSettings]
AnonymousAccessList[]=contentserver/soap

[RoleSettings]
PolicyOmitList[]=contentserver/soap