[GeneralSettings]
EnableSOAP=true

[ExtensionSettings]
SOAPExtensions[]=contentserver