[ModuleSettings]
ExtensionRepositories[]=contentserver