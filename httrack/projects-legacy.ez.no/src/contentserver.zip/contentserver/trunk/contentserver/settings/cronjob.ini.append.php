[CronjobSettings]
ScriptDirectories[]=extension/contentserver/bin

[CronjobPart-contentserver]
Scripts[]=contentserver.php