Part[ezcontentservernavigationpart]=Content Server


[TopAdminMenu]
Tabs[]=contentserver

[Topmenu_contentserver]
NavigationPartIdentifier=ezcontentservernavigationpart
Name=Content Server
Tooltip=Content Server for eZ publish
URL[]
URL[default]=contentserver/menu
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=false