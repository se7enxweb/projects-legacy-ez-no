[PackageSettings]
RepositoryDirectories[]=kernel/classes
ExtensionDirectories[]=contentserver

HandlerAlias[contentserver]=ezcontentserver

TypeList[contentserver]=Content Server SOAP Object

[CreationSettings]
HandlerList[]=ezcontentserver

[InstallerSettings]
HandlerList[]=ezcontentserver