[EventSettings]
ExtensionDirectories[]=contentserver
AvailableEventTypes[]=event_ezcontentserverapprove