<?php /* #?ini charset="utf8"?

[node_incomming_view_full]
Source=node/view/full.tpl
MatchFile=contentserver/incomming_node.tpl
Subdir=templates
Match[node]=4

[node_incomming_view_full_new]
Source=node/view/full.tpl
MatchFile=contentserver/incomming_node.tpl
Subdir=templates
Match[url_alias]=incoming

*/ ?>