[ExtensionSettings]
DesignExtensions[]=contentserver