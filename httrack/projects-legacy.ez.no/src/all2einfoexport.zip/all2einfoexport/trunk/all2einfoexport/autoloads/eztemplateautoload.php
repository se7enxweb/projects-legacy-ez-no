<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/all2einfoexport/autoloads/all2einfoexporttemplateoperators.php',
                                    'class' => 'all2eInfoExportOperators',
                                    'operator_names' => array( 'lastexport','countcollections' ) );


?>
