<?php /* #?ini charset="utf-8"?

[NavigationPart]
Part[all2enavigationpart]=Collected Information Export

[TopAdminMenu]
Tabs[]=all2einfoexport

[Topmenu_all2einfoexport]
NavigationPartIdentifier=all2enavigationpart
Name=Collected Information Export
Tooltip=Export you collected information
URL[]
URL[default]=all2einfoexport/select_export
Enabled[]
Enabled[default]=false
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=false
Shown[edit]=false
Shown[navigation]=true
Shown[browse]=false

*/ ?>
