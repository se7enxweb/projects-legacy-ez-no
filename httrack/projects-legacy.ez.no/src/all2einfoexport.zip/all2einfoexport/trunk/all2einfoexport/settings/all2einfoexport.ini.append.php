<?php /*

[GeneralSettings]
ExportDir=var/export

*/ ?>
