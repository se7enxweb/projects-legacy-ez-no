<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=all2einfoexport

*/ ?>
