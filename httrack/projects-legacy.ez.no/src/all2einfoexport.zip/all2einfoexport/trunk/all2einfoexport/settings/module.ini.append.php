<?php /*

[ModuleSettings]
ModuleList[]=all2einfoexport
ExtensionRepositories[]=all2einfoexport



*/ ?>
