<?php
class all2eInfoExportInfo
{
    function info()
    {
        return array( 'Name' => "all2e Information export",
                      'Version' => "1.0.0",
                      'Copyright' => 'Copyright (C) 2008 <a href="http://www.all2e.com" title="eZ Publish">all2e GmbH</a>'
                     );
    }
}
?>
