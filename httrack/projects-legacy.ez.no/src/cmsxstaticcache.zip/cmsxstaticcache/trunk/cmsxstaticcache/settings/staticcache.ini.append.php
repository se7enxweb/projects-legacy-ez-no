<?php /* #?ini charset="utf-8"?

[CacheSettings]
CompactHTML=enabled

*/ ?>