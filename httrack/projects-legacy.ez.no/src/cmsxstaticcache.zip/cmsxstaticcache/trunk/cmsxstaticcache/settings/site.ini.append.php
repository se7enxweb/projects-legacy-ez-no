<?php /* #?ini charset="utf-8"?

[OutputSettings]
#OutputFilterName=cmsxStaticCacheFilter

*/ ?>
