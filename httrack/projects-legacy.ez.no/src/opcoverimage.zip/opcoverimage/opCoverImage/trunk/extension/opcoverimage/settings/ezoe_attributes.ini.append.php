<?php /* #?ini charset="utf-8"?

[CustomAttribute_imageamazon_size]
Name=Size
Default=medium
Type=select
## Optional, lets you disable the html control so users can't change the value
#Disabled=true
## Optional, forces user to fill out the html form element
##Required=true
Selection[]
Selection[thumbnail]=Thumbnail
Selection[small]=Small
Selection[medium]=Medium
Selection[large]=Large

[CustomAttribute_imageamazon_pcode]
Name=Product code
Default=1740598504
Type=text
Maximum=12

[CustomAttribute_imageamazon_align]
Name=Align
Default=left
Type=select
## Optional, lets you disable the html control so users can't change the value
#Disabled=true
## Optional, forces user to fill out the html form element
##Required=true
Selection[]
Selection[left]=Left
Selection[center]=Center
Selection[right]=Right

[CustomAttribute_imageamazon_shadow]
Name=Shadow
Type=select
Selection[]
Selection[]=none
Selection[botleft]=Bottom left
Selection[botright]=Bottom right

[CustomAttribute_imageamazon_discount]
Name=Discount
Type=int
Default=0


[CustomAttribute_imageamazon_sticker]
Name=Sticker
Type=checkbox
Default=1


*/ ?>