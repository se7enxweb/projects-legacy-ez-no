<?php /* #?ini charset="utf-8"?

[CustomTagSettings]
AvailableCustomTags[]=imageamazon

[imageamazon]
CustomAttributes[]=align
CustomAttributes[]=size
CustomAttributes[]=pcode
CustomAttributes[]=shadow
CustomAttributes[]=discount
CustomAttributes[]=sticker




*/ ?>