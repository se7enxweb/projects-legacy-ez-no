<?php /* #?ini charset="utf-8"?

[openx_banner]
Source=block/view/view.tpl
MatchFile=block/openx_banner.tpl
Subdir=templates
Match[type]=OpenX_Banner

*/ ?>