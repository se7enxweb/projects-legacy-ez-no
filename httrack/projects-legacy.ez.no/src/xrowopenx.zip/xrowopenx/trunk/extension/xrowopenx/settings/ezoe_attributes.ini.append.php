[CustomAttribute_openx_banner_heading]
Name=Heading
AllowEmpty=true

[CustomAttribute_openx_banner_zone_override]
Name=Zone Override
Title=Chose another named identifier for the banner
AllowEmpty=true

[CustomAttribute_openx_banner_banner]
Name=Banner
Title=Choose type of banner
Default=banner_300x250
Type=select
Selection[]
Selection[banner_300x250]=OVK: Medium Rectangle (300x250)
Selection[banner_400x400]=OVK: Universal Flash Layer (400x400)
Selection[banner_468x60]=OVK/IAB: Fullsize Banner (468x60)
Selection[banner_234x60]=OVK/IAB: Halfsize Banner (234x60)
Selection[banner_80x15]=OVK: Microbutton (80x15)
Selection[banner_240x400]=IAB: Vertical Rectangle (240x400)
Selection[banner_336x280]=IAB: Large Rectangle (336x280)
Selection[banner_180x150]=IAB: Rectangle (180x150)
Selection[banner_400x400]=OVK/IAB: Universal Layer (400x400)
Selection[banner_88x31]=IAB: Micro Bar (88x31)
Selection[banner_120x90]=IAB: Button 1 (120x90)
Selection[banner_120x60]=IAB: Button 2 (120x60)
Selection[banner_120x240]=IAB: Vertical Banner (120x240)
Selection[banner_125x125]=IAB: Square Button (125x125)
Selection[banner_160x600]=IAB: Wide Skyscraper (160x600)
Selection[banner_120x600]=IAB: Skyscraper (120x600)
Selection[banner_300x600]=IAB: Half Page Ad (300x600)
Selection[banner_728x90]=OVK/IAB: Superbanner (728x90)