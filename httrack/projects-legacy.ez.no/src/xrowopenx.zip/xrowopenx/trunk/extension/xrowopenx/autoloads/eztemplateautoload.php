﻿<?php

$eZTemplateOperatorArray = array();

$eZTemplateOperatorArray[] = array( 'script' => 'extension/xrowopenx/autoloads/xrowopenxadoperator.php',
                                    'class' => 'xrowOpenxAdOperator',
                                    'operator_names' => array( 'show_ad' ) );
?>