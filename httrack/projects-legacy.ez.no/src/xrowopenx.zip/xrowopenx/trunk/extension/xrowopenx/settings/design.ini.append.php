<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=xrowopenx

[JavaScriptSettings]
FrontendJavaScriptList[]=xrowopenx::oa_zones
FrontendJavaScriptList[]=xrowopenx::swf
FrontendJavaScriptList[]=ezjsc::jquery
FrontendJavaScriptList[]=jQuery.pagePeel.js
FrontendJavaScriptList[]=general.js


*/ ?>