[CustomTagSettings]
AvailableCustomTags[]=openx_banner
IsInline[openx_banner]=true

[openx_banner]
CustomAttributes[]=heading
CustomAttributes[]=banner
CustomAttributes[]=zone_override
CustomAttributesDefaults[type]=banner_300x250