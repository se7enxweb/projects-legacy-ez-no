<?php /*

[ezjscServer_xrowopenx]
Class=xrowopenxServerFunctions
File=extension/xrowopenx/classes/xrowopenxserverfunctions.php

*/ ?>