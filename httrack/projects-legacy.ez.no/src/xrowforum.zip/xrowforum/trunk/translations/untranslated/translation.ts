<!DOCTYPE TS><TS>
<context>
    <name>design/ezwebin/content/edit_attribute</name>
    <message>
        <source>Not translatable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/ezwebin/user/register</name>
    <message>
        <source>Register user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input did not validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input was stored successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to register new user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Default value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current date</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter the year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter the month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter the day</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/xrowforum</name>
    <message>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Information collector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send for publishing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit %1 - %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Notify me about updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sticky</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your last login was</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mark all forums as read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>see forum statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New topic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep me updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You need to be logged in to get access to the forums. You can do so %login_link_start%here%login_link_end%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Topic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous topic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next topic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove this item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quote it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Topics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Posts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Module List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>xrowForum Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moderator Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click on the icon to display a context-sensitive menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit &lt;%child_name&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validation Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User Ranks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>add a new rank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rank Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rank Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rank Condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ranklist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forum Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>id settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>general settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BBCodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validation errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Forum reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>origin Topic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deflag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set Session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update modified TS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reply Creation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>xrowForum overview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>xrowForum permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>xrowForum ranks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>xrowForum settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permission to edit &lt;%child_name&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>posts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moderator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mark this forum as read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Topic has been closed while you created a new post, your post has been deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NEW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Overview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Board Started</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Topic Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currently Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no one online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Online In Past 24Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Birthdays Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nobody</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Most User Ever Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Topics Per Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Posts Per Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Registrations Per Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>latest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>registered User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hottest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Topics (by views)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Topics (by replies)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>replies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>activity User (by Comments)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>activity User (by Logins)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please select a Proper value for your ModeratorGroupObjectID settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no Forums to moderate selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The input was successfully safed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normal Rank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Special Rank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>inactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kernel/classes/datatypes</name>
    <message>
        <source>Aries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Taurus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gemini</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Leo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Virgio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Libra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scorpio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sagittarius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Capricorn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aquarius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pisces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Birthday</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing date input.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a correct date.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content required</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
