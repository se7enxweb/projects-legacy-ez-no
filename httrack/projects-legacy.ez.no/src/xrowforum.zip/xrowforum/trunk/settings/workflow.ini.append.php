<?php /* #?ini charset="utf8"?

[EventSettings]
RepositoryDirectories[]=extension/xrowforum/eventtypes
ExtensionDirectories[]=xrowforum
AvailableEventTypes[]=event_flagafterpublish
AvailableEventTypes[]=event_deflagafterread
AvailableEventTypes[]=event_setsessionbeforepublish
AvailableEventTypes[]=event_updateafterpublish

[OperationSettings]
AvailableOperationList[]=content_read

*/ ?>