<?php /* #?ini charset="utf8"?

[DataTypeSettings]
ExtensionDirectories[]=xrowforum
AvailableDataTypes[]=ezbirthday

*/ ?>