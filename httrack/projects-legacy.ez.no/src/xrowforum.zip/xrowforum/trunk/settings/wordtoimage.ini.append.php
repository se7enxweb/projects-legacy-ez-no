<?php /* #?ini charset="utf8"?

[WordToImageSettings]
#path still needs testings maybe even too long
IconRoot=/extension/xrowforum/design/xrowforum/images/smilies

ReplaceText[]=:)
ReplaceIcon[]=happy.gif
ReplaceText[]=:-)
ReplaceIcon[]=happy.gif

ReplaceText[]=;)
ReplaceIcon[]=blunk.gif
ReplaceText[]=;-)
ReplaceIcon[]=blunk.gif

ReplaceText[]=:(
ReplaceIcon[]=sad.gif
ReplaceText[]=:-(
ReplaceIcon[]=sad.gif

ReplaceText[]=:@
ReplaceIcon[]=mad.gif
ReplaceText[]=:-@
ReplaceIcon[]=mad.gif

ReplaceText[]=:|
ReplaceIcon[]=confused.gif
ReplaceText[]=:-|
ReplaceIcon[]=confused.gif

ReplaceText[]=:D
ReplaceIcon[]=big-smile.gif
ReplaceText[]=:-D
ReplaceIcon[]=big-smile.gif

ReplaceText[]=:O
ReplaceIcon[]=omg.gif
ReplaceText[]=:o
ReplaceIcon[]=omg.gif
ReplaceText[]=:-O
ReplaceIcon[]=omg.gif
ReplaceText[]=:-o
ReplaceIcon[]=omg.gif

ReplaceText[]=:-/
ReplaceIcon[]=suspicious.gif

*/ ?>