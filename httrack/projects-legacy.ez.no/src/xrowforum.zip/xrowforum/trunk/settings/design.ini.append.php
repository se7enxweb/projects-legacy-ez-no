<?php /* #?ini charset="utf8"?

[ExtensionSettings]
DesignExtensions[]=xrowforum

[StylesheetSettings]
CSSFileList[]=xrowforum_frontend.css
CSSFileList[]=shadowbox.css

[JavaScriptSettings]
JavaScriptList[]=yahoo-min.js
JavaScriptList[]=cookie-min.js
JavaScriptList[]=ezjsc::jquery
JavaScriptList[]=ezjsc::jqueryio
JavaScriptList[]=shadowbox.js

*/ ?>