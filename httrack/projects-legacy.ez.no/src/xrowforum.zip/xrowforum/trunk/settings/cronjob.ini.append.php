<?php /* #?ini charset="utf8"?

[CronjobSettings]
ExtensionDirectories[]=xrowforum

[CronjobPart-mostuser]
Scripts[]=most_user_online.php

[CronjobPart-cleanflags]
Scripts[]=clean_flag.php

*/ ?>