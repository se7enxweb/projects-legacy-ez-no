<?php /* #?ini charset="utf-8"?

#[forum_index]
#Source=node/view/full.tpl
#MatchFile=forum_index.tpl
#Subdir=templates
#Match[node]="NODE ID FROM FORUM INDEX NUMERIC"

*/ ?>