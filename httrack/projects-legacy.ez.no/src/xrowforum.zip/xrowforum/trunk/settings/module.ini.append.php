﻿<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=xrowforum
ModuleList[]=xrowforum
ModuleList[]=pm

*/ ?>