<?php
class ezbeanstreamInfo
{
    function info()
    {
        return array( 'Name' => "Data Import",
                      'Version' => "1.5",
                      'Copyright' => "Copyright (C) 2008 Mugo Web",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>