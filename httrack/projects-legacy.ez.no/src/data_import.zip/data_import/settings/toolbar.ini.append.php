<?php /* #?ini charset="utf-8"?

[Tool]
AvailableToolArray[]=remote_id

[Toolbar_admin_developer]
Tool[]=remote_id

*/ ?>