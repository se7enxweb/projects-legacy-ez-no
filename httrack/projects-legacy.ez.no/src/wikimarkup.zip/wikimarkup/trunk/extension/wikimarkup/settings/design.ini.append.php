<?php /*
#
# $Id: design.ini.append.php 2 2010-09-28 07:34:04Z dpobel $
# $HeadURL: http://svn.projects.ez.no/wikimarkup/trunk/extension/wikimarkup/settings/design.ini.append.php $
#

[ExtensionSettings]
DesignExtensions[]=wikimarkup


*/ ?>
