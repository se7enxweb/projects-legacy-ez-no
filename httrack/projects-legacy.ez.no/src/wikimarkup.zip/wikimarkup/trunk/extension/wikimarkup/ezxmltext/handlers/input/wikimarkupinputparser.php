<?php
/*
 * $Id: wikimarkupinputparser.php 2 2010-09-28 07:34:04Z dpobel $
 * $HeadURL: http://svn.projects.ez.no/wikimarkup/trunk/extension/wikimarkup/ezxmltext/handlers/input/wikimarkupinputparser.php $
 *
 */

class wikiMarkupInputParser
{
    function __construct()
    {

    }

    function process( $text, $createRootNode = true )
    {
        $wiki = new ezcDocumentWiki();
        $wiki->loadString( $text );
        $docbook = $wiki->getAsDocbook();
        
        $converter = new ezcDocumentDocbookToEzXmlConverter();
        $converter->options->linkConverter = new wikiMarkupLinkConverter();
        $ezdoc = $converter->convert( $docbook );

        return $ezdoc->getDomDocument();
    }

}


?>
