<?php /*
#
# $Id: ezxml.ini.append.php 2 2010-09-28 07:34:04Z dpobel $
# $HeadURL: http://svn.projects.ez.no/wikimarkup/trunk/extension/wikimarkup/settings/ezxml.ini.append.php $
#

[HandlerSettings]
ExtensionRepositories[]=wikimarkup

[InputSettings]
AliasClasses[eZSimplifiedXMLInput]=wikiMarkupInput

*/ ?>
