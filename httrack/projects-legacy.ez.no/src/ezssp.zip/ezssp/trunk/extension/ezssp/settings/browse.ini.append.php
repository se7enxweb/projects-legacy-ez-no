<?php /*

[SelectSkeleton]
StartNode=content
SelectionType=single
ReturnType=NodeID

[AddSkeletonUserGroups]
SelectionType=multiple
ReturnType=NodeID
Class[]
Class[]=user_group

*/ ?>