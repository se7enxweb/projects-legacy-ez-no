<?php /* #?ini charset="iso-8859-1"?

[EventSettings]
ExtensionDirectories[]=ezssp
AvailableEventTypes[]=event_subtreeskeletonpublish

*/ ?>