<?php /*

# Cache item entry (for eZ Publish 4.3 and up)
[Cache]
CacheItems[]=ezwebservicesapi

[Cache_ezwebservicesapi]
name=eZWebservicesAPI extension cache (fetch/view webservices list)
path=ezwebservicesapi

*/ ?>