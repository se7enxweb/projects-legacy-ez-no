<?php /*

[ExtensionSettings]
DesignExtensions[]=ezwebservicesapi

*/ ?>