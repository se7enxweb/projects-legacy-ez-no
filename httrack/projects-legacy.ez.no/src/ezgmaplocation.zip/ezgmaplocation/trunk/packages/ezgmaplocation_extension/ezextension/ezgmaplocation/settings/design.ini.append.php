<?php /*

[ExtensionSettings]
DesignExtensions[]=ezgmaplocation

*/ ?>