<?php /*

[EditSettings]
GroupedInput[]=ezgmaplocation

*/ ?>