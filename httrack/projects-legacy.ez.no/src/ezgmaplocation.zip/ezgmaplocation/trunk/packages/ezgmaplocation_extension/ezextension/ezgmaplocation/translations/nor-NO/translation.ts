<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS>
<context>
    <name>extension/ezgmaplocation/datatype</name>
    <message>
        <location filename="ezgmaplocationtype.php" line="48"/>
        <source>GMap Location</source>
        <comment>Datatype name</comment>
        <translation>GMap lokasjon</translation>
    </message>
    <message>
        <location filename="ezgmaplocationtype.php" line="77"/>
        <source>Missing Latitude/Longitude input.</source>
        <translation>Mangler Lengdegrad/Breddegrad verdier.</translation>
    </message>
    <message>
        <location filename="ezgmaplocationtype.php" line="84"/>
        <source>Invalid Latitude/Longitude input.</source>
        <translation>Ugyldig Lengdegrad/Breddegrad verdier.</translation>
    </message>
    <message>
        <source>Latitude</source>
        <translation>Breddegrad</translation>
    </message>
    <message>
        <source>Longitude</source>
        <translation>Lengdegrad</translation>
    </message>
    <message>
        <source>Update Location</source>
        <translation>Oppdater lokasjon</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Gjenopprett</translation>
    </message>
    <message>
        <source>Update values</source>
        <translation>Oppdater verdier</translation>
    </message>
    <message>
        <source>Find address</source>
        <translation>Finn adresse</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Map</source>
        <translation>Kart</translation>
    </message>
    <message>
        <source>My current location</source>
        <translation>Min nåværende lokasjon</translation>
    </message>
</context>
</TS>