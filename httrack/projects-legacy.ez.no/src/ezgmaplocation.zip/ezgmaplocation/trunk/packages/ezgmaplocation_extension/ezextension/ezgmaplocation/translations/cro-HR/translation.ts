<!DOCTYPE TS>
<TS>
<context>
    <name>extension/ezgmaplocation/datatype</name>
    <message>
        <location filename="ezgmaplocationtype.php" line="48"/>
        <source>GMap Location</source>
        <translation>GMap Lokacija</translation>
    </message>
    <message>
        <location filename="ezgmaplocationtype.php" line="77"/>
        <source>Missing Latitude/Longitude input.</source>
        <translation>Nedostaje geografska širina/duljina.</translation>
    </message>
    <message>
        <location filename="ezgmaplocationtype.php" line="84"/>
        <source>Invalid Latitude/Longitude input.</source>
        <translation>Neispravna geografska širina/duljina.</translation>
    </message>
    <message>
        <source>Latitude</source>
        <translation>Geografska širina</translation>
    </message>
    <message>
        <source>Longitude</source>
        <translation>Geografska duljina</translation>
    </message>
    <message>
        <source>Update Location</source>
        <translation>Ažuriraj lokaciju</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Početne vrijednosti</translation>
    </message>
    <message>
        <source>Update values</source>
        <translation>Ažuriraj vrijednosti</translation>
    </message>
    <message>
        <source>Find address</source>
        <translation>Pronađi adresu</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <source>Map</source>
        <translation>Karta</translation>
    </message>
    <message>
        <source>My current location</source>
        <translation>Moja trenutna lokacija</translation>
    </message>
</context>
</TS>
