<?php /*

[oracle]
ColumnTypeTranslation[ezgmaplocation.latitude]=double;float
ColumnTypeTranslation[ezgmaplocation.longitude]=double;float

*/ ?>
