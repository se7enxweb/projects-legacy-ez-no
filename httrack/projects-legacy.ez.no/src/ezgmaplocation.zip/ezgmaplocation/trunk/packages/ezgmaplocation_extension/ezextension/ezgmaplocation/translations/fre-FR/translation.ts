<!DOCTYPE TS><TS>
<context>
    <name>extension/ezgmaplocation/datatype</name>
    <message>
        <source>GMap Location</source>
        <comment>Datatype name</comment>
        <translation>Emplacement Google Map</translation>
    </message>
    <message>
        <source>Missing Latitude/Longitude input.</source>
        <translation>Latitude/Longitude non renseignée(s)</translation>
    </message>
    <message>
        <source>Invalid Latitude/Longitude input.</source>
        <translation>Latitude/Longitude invalide(s)</translation>
    </message>
    <message>
        <source>Latitude</source>
        <translation>Latitude</translation>
    </message>
    <message>
        <source>Longitude</source>
        <translation>Longitude</translation>
    </message>
    <message>
        <source>Update Location</source>
        <translation>Mettre à jour l'emplacement</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Restaurer</translation>
    </message>
    <message>
        <source>Update values</source>
        <translation>Mettre à jour les valeurs</translation>
    </message>
    <message>
        <source>Find address</source>
        <translation>Trouver une adresse</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Map</source>
        <translation>Carte</translation>
    </message>
</context>
</TS>
