<?php /*

[DataTypeSettings]
ExtensionDirectories[]=ezgmaplocation
AvailableDataTypes[]=ezgmaplocation

*/ ?>