<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ja_JP">
<context>
    <name>extension/ezgmaplocation/datatype</name>
    <message>
        <source>GMap Location</source>
        <comment>Datatype name</comment>
        <translation type="unfinished">Googleマップロケーション</translation>
    </message>
    <message>
        <source>Missing Latitude/Longitude input.</source>
        <translation type="unfinished">緯度/軽度は入力されていません。</translation>
    </message>
    <message>
        <source>Invalid Latitude/Longitude input.</source>
        <translation type="unfinished">緯度/軽度は無効です。</translation>
    </message>
    <message>
        <source>Latitude</source>
        <translation type="unfinished">緯度</translation>
    </message>
    <message>
        <source>Longitude</source>
        <translation type="unfinished">軽度</translation>
    </message>
    <message>
        <source>Update Location</source>
        <translation type="unfinished">位置を更新</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation type="unfinished">戻す</translation>
    </message>
    <message>
        <source>Update values</source>
        <translation type="unfinished">値を更新</translation>
    </message>
    <message>
        <source>Find address</source>
        <translation type="unfinished">住所を検索</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">住所</translation>
    </message>
    <message>
        <source>Map</source>
        <translation type="unfinished">地図</translation>
    </message>
    <message>
        <source>My current location</source>
        <translation type="unfinished">現在の位置</translation>
    </message>
</context>
</TS>
