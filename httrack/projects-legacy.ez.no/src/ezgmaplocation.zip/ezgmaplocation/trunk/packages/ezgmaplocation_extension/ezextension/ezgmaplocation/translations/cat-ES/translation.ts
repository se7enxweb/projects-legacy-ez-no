<!DOCTYPE TS><TS>
<context>
    <name>extension/ezgmaplocation/datatype</name>
    <message>
        <source>GMap Location</source>
        <comment>Datatype name</comment>
        <translation>Adreça GMap</translation>
    </message>
    <message>
        <source>Missing Latitude/Longitude input.</source>
        <translation>Has d&apos;introduir una longitud i una latitud.</translation>
    </message>
    <message>
        <source>Invalid Latitude/Longitude input.</source>
        <translation>Longitud/Latitud incorrecta.</translation>
    </message>
    <message>
        <source>Find address</source>
        <translation>Cerca adreça</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Restaura</translation>
    </message>
    <message>
        <source>Restores location and address values to what it was on page load.</source>
        <translation>Restaura la ubicació i l&apos;adreça.</translation>
    </message>
    <message>
        <source>Latitude</source>
        <translation>Latitud</translation>
    </message>
    <message>
        <source>Longitude</source>
        <translation>Longitud</translation>
    </message>
    <message>
        <source>My current location</source>
        <translation>La meva ubicació actual</translation>
    </message>
    <message>
        <source>Gets your current position if your browser support GeoLocation and you grant this website access to it! Most accurate if you have a built in gps in your Internet device! Also note that you might still have to type in address manually!</source>
        <translation>Troba la teva posició actual si el teu navegador suporta i té permisos per accedir a GeoLocation. Serà encara més acurat si el teu dispositiu d&apos;Internet té sistema gps integrat. Tingues en compte que es possible que tinguis que introduir l&apos;adreça manualment!</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adreça</translation>
    </message>
    <message>
        <source>Map</source>
        <translation>Mapa</translation>
    </message>
</context>
</TS>
