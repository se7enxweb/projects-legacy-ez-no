<?php /* #?ini charset="utf-8"?


[TemplateSettings]
ExtensionAutoloadPath[]=ezgmaplocation

[RegionalSettings]
TranslationExtensions[]=ezgmaplocation

*/ ?>