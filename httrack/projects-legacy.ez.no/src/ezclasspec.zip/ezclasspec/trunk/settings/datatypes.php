<?php 

$additionalClassGroups = array(); // e.g. array('Sidebar','Frontpage')

$additionalDatatypes = array('ezgmaplocation' => 'Google maps location');

?>