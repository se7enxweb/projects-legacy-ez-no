<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezmultivalue

*/ ?>
