<?php /*

# A list of directories to check for datatypes
[DataTypeSettings]
ExtensionDirectories[]=ezmultivalue
AvailableDataTypes[]=ezmultivalue

*/ ?>