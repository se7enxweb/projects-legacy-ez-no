<?php /*

[SolrFieldMapSettings]
CustomMap[ezmultivalue]=ezfMultiValueCollection

*/ ?>
