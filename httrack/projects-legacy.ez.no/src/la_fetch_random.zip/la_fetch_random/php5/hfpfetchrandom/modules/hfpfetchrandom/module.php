<?php
/**
// Created on: <2007-12-20 by LIU Bin bin.liu@lagardere-active.com>
 *
 */
$Module = array( "name" => "hfpfetchrandom",
                 "variable_params" => true );
?>