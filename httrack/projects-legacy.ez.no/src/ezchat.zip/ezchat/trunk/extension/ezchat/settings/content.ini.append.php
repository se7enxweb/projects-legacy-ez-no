<?php /*

[DataTypeSettings]
ExtensionDirectories[]=ezchat
AvailableDataTypes[]=ezchatroom

*/ ?>