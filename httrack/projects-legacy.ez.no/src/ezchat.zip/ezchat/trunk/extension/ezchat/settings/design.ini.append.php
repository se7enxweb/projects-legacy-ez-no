<?php /* #?ini charset="iso-8859-1"?

[ExtensionSettings]
DesignExtensions[]=ezchat

[StylesheetSettings]
CSSFileList[]=ezchat/core.css
CSSFileList[]=ezchat/gmaps.css

*/ ?>