<!DOCTYPE TS><TS>
<context>
    <name>ezchat/datatypes/chatroom</name>
    <message>
        <source>Chatroom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The channel name is too long. The maximum number of characters allowed is %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The channel name contains forbidden characters or spaces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow private channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow registered users to delete their own messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(without special character)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow private messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show channel messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Request messages prior channel enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opening hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opening days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sunday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tuesday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wednesday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thursday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Friday</source>
        <translation type="unfinished"></translation>
    </message>
	<message>
        <source>Saturday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opened from %1h00 to %2h00.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deactivate Google Maps tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messaging parameters</source>
        <translation type="unfinished"></translation>
    </message>

</context>
<context>
	<name>design/standard/ezchat</name>
    <message>
        <source>Chatroom access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Javascript capabilities are required to enter this chatroom.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You just sign out from chatroom. You can login back or logout from site.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sign in back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are currently not logged in. You can use a registered account and login, or enter chat room as a guest user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sign in as a guest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Guest nickname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sign in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit this marker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove this marker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle marker visibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send this marker trough chatroom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send directly trough chatroom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy to my markers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My markers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add a marker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View all markers on map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chatroom markers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show/hide all markers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter marker title:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change marker title:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 shows a point on the map: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This functionality is disabled for this moment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Google Maps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Google Maps tools</source>
        <translation type="unfinished"></translation>
    </message>

</context>
<context>
	<name>design/admin/ezchat</name>
    <message>
        <source>Chatroom window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>deploy/shrink tools</source>
        <translation type="unfinished"></translation>
    </message>
	<message>
        <source>deploy/shrink settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>deploy chatroom window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shrink chatroom window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>deploy/shrink online users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Found chatrooms</source>
        <translation type="unfinished"></translation>
    </message>

</context>
<context>
	<name>design/admin/parts/ezchat/menu</name>
    <message>
        <source>eZchat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter chatroom</source>
        <translation type="unfinished"></translation>
    </message>
	<message>
        <source>Available chatrooms</source>
        <translation type="unfinished"></translation>
    </message>

</context>
<context>
	<name>kernel/navigationpart</name>
    <message>
        <source>eZchat</source>
        <comment>Navigation part</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>eZchat</source>
        <comment>Navigation path</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chatroom</source>
        <comment>Navigation path</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Available chatrooms</source>
        <comment>Navigation path</comment>
        <translation type="unfinished"></translation>
    </message>

</context>
<context>
	<name>design/admin/ezchatinfo</name>
    <message>
        <source>Detected errors and warnings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No class with ezchatroom datatype found. Only static chatrooms will be available. You have to create a class with ezchatroom datatype to be able to use content chatrooms.</source>
        <translation type="unfinished"></translation>
    </message>

</context>
</TS>
