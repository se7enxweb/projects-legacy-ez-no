<?php /* #?ini charset="iso-8859-1"?

[TopAdminMenu]
Tabs[]=ezchat

[NavigationPart]
Part[ezchatnavigationpart]=eZchat

[Topmenu_ezchat]
NavigationPartIdentifier=ezchatnavigationpart
Name=eZchat
Tooltip=Administrate eZchat from here
URL[]
URL[default]=ezchat/welcome
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
# We don't show it in browse mode
Shown[browse]=false

*/ ?>