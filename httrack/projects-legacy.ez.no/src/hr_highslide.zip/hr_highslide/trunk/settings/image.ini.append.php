<?php /* #?ini charset="iso-8859-1"?

[AliasSettings]
AliasList[]=gallerythumbnail
AliasList[]=imagelarge

[imagelarge]
Reference=original
Filters[]=geometry/scaledownonly=800;600

[gallerythumbnail]
Reference=imagelarge
Filters[]=geometry/scaledownonly=100;100
           
*/ ?>
