<?php
/*
[ExtensionSettings]
DesignExtensions[]=hr_highslide

[StylesheetSettings]
CSSFileList[]=highslide.css

[JavaScriptSettings]
JavaScriptList[]=highslide.js
JavaScriptList[]=highslide.config.js

*/
?>
