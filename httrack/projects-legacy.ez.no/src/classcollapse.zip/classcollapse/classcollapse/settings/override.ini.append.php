<?php /* #?ini charset="utf-8"?

[class_view]
Source=class/view.tpl
MatchFile=class/view.tpl
Subdir=templates

[class_edit]
Source=class/edit.tpl
MatchFile=class/edit.tpl
Subdir=templates


*/ ?>
