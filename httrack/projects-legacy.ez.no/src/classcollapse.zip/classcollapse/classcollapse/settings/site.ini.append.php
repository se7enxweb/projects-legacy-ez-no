<?php /* #?ini charset="utf-8"? 

[DesignSettings]
AdditionalSiteDesignList[]=classcollapse

[TemplateSettings]
ExtensionAutoloadPath[]=classcollapse

*/ ?>