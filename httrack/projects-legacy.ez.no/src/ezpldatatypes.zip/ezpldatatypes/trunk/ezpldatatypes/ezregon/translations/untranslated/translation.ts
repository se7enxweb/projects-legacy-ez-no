<!DOCTYPE TS><TS>
<context>
    <name>extension/ezregon</name>
    <message>
        <source>REGON</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The REGON number is not correct. Please check the input for mistakes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>