<?php /*

[RegionalSettings]
TranslationExtensions[]=ezregon

*/ ?>