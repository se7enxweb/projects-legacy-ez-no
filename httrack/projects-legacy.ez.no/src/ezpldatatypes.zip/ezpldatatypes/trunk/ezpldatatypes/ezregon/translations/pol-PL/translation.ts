<!DOCTYPE TS><TS>
<context>
    <name>extension/ezregon</name>
    <message>
        <source>REGON</source>
        <comment>Datatype name</comment>
        <translation>REGON</translation>
    </message>
    <message>
        <source>The REGON number is not correct. Please check the input for mistakes.</source>
        <translation>Nieprawidłowy numer REGON. Popraw wprowadzoną wartość.</translation>
    </message>
</context>
</TS>
