<?php /*

[DataTypeSettings]
ExtensionDirectories[]=ezregon
AvailableDataTypes[]=ezregon

*/ ?>