<?php /*

[DataTypeSettings]
ExtensionDirectories[]=ezpesel
AvailableDataTypes[]=ezpesel

*/ ?>