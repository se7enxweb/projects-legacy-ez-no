<!DOCTYPE TS><TS>
<context>
    <name>extension/ezpesel</name>
    <message>
        <source>PESEL</source>
        <comment>Datatype name</comment>
        <translation>PESEL</translation>
    </message>
    <message>
        <source>The PESEL number is not correct. Please check the input for mistakes.</source>
        <translation>Nieprawidłowy numer PESEL. Popraw wprowadzoną wartość.</translation>
    </message>
</context>
</TS>
