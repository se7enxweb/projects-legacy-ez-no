<?php /*

[ExtensionSettings]
DesignExtensions[]=ezpesel

*/ ?>
