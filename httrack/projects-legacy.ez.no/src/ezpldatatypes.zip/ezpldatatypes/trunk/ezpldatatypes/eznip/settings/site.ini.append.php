<?php /*

[RegionalSettings]
TranslationExtensions[]=eznip

*/ ?>