<!DOCTYPE TS><TS>
<context>
    <name>extension/eznip</name>
    <message>
        <source>NIP</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The NIP number is not correct. Please check the input for mistakes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>