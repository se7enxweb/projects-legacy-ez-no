<?php /* #?ini charset="utf-8"?

[CronjobSettings]
Scripts[]=xrow_cdn_upload.php
ExtensionDirectories[]=xrowcdn

[CronjobPart-xrowcdn]
Scripts[]=xrow_cdn_upload.php


*/ ?>