<!DOCTYPE TS><TS>
<context>
    <name>design/nvnewsletter/example_template</name>
    <message>
        <source>nvNewsletter example template created by</source>
        <translation>nvNewsletter esimerkkisivupohja, toteuttaja</translation>
    </message>
    <message>
        <source>View newsletter in browser</source>
        <translation>Näytä uutiskirje selaimessa</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Peru tilaus</translation>
    </message>
    <message>
        <source>Articles</source>
        <translation>Artikkelit</translation>
    </message>
</context>
</TS>
