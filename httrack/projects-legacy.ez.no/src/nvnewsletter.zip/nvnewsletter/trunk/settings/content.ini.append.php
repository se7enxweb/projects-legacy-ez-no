<?php /*

[CustomTagSettings]
AvailableCustomTags[]=nvnewslettersubscribe
IsInline[nvnewslettersubscribe]=false

[EditSettings]
ExtensionDirectories[]=nvnewsletter

[DataTypeSettings]
ExtensionDirectories[]=nvnewsletter
AvailableDataTypes[]=nvnewslettersender
AvailableDataTypes[]=nvnewslettergroups
AvailableDataTypes[]=nvnewslettersiteselect

[link]
AvailableClasses[]=tracker

*/ ?>
