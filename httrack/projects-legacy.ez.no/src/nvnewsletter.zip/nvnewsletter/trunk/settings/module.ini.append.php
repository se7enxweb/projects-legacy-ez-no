<?php /*

[ModuleSettings]
ExtensionRepositories[]=nvnewsletter
ModuleList[]=nvnewsletter

*/ ?> 