<?php /*

[DataTypeSettings]
ExtensionDirectories[]=eztreeselection
AvailableDataTypes[]=eztreeselection

*/ ?>