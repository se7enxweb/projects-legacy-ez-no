<?php /*

[ExtensionSettings]
DesignExtensions[]=eztreeselection

[StylesheetSettings]
CSSFileList[]=treeview/assets/skins/ez/treeview.css

[JavaScriptSettings]
JavaScriptList[]=yahoo/yahoo-min.js
JavaScriptList[]=event/event-min.js
JavaScriptList[]=treeview/treeview-min.js
JavaScriptList[]=eztreeselection.js

*/ ?>