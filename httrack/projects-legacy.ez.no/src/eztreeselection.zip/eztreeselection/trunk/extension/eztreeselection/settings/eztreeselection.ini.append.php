<?php /*

[GeneralSettings]
## the color code applied to the label of a selected node
#  when an eztreeselection attribute is viewed at the object level.
#ColorOfSelectedItem=#FF4499
ColorOfSelectedItem=orange

[ImageSettings]
# The four directives below allows you to modify the images used 
# to build the edition widget, beside every taxonomy element. 
RenameImage=ezwt-icon-edit.gif
AddChildImage=ezwt-icon-new.gif
RemoveChildImage=ezwt-icon-remove.gif
ValidateLabelModificationImage=ezwt-icon-publish.gif


*/ ?>