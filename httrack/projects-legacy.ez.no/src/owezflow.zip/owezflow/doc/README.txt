-------------------------
owEZFlow :
-------------------------

owEZFlow extends ezFlow extension.

With owEZFlow, you can :
 - set a worflow to update view cache of objects containing eZFlow blocks relating to the published object.
 - define custom attributes even if ManualAddingOfItems is enabled.
 - define custom labels for custom attributes
 - define "object relation" custom attributes
 
 
-------------------------
Usage
-------------------------
See "settings/block.ini.append.php" for instructions.



---------------------------------------------
Hope you find it useful! 

Simon Boyer

