<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=accessibility_improvements

[JavaScriptSettings]
JavaScriptList[]=editcheck.js
JavaScriptList[]=yui/build/yahoo-dom-event/yahoo-dom-event.js

[StylesheetSettings]
CSSFileList[]=editcheck.css


*/ ?>

