<?php

$Module = array( "name" => "all2eCoupon" );

?>
