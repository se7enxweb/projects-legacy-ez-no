<?php /* #?ini charset="utf-8"?

[DataTypeSettings]
ExtensionDirectories[]=all2ecoupon
AvailableDataTypes[]=all2ecoupon

*/ ?>
