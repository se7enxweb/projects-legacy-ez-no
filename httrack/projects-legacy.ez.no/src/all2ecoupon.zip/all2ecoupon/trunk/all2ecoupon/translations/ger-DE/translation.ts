<!DOCTYPE TS><TS>
<defaultcodec></defaultcodec>
<context>
    <name>extension/all2ecoupon</name>
    <message>
        <source>Incorrect input. Please try again.</source>
        <translation>Fehlerhafte Eingabe. Bitte versuchen Sie es erneut.</translation>
    </message>
</context>
</TS>
