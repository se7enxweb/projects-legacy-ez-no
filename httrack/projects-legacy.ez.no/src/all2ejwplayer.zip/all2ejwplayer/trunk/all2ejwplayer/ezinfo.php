<?php
class all2ejwplayerInfo
{
    /*!
     Constructor
    */
	function info()
    {
        return array( 'Name' => "JW Player integration",
                      'Version' => "1.0",
                      'Copyright' => "Copyright (C) 2008 <a href='http://all2e.com'>all2e GmbH</a>",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}    

?>
