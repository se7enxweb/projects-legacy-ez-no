<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=all2ejwplayer

[SiteAccessSettings]
AnonymousAccessList[]=jwplayer/createurl


*/ ?>
