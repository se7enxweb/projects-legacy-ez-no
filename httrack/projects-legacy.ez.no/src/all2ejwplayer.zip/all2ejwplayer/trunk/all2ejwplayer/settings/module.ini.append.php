<?php /*

[ModuleSettings]
ExtensionRepositories[]=all2ejwplayer

ModuleList[]=jwplayer

*/ ?>
