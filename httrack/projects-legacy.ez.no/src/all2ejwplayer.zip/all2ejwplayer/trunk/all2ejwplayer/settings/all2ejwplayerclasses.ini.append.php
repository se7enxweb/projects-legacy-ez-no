<?php /*

[Standard]
Height=450
Width=720
Source=http://nocache.all2e.com/var/plain_site/storage/original/video/player.swf
BgColor=#cccccc
Skin=http://nocache.all2e.com/var/plain_site/storage/original/video/schoon.swf
DefaultVideo=http://nocache.all2e.com/var/plain_site/storage/original/video/example.flv
Fullscreen=false
Autostart=true


[Inline]
Height=260
Width=290
Source=http://nocache.all2e.com/var/plain_site/storage/original/video/player.swf
BgColor=#cccccc
Skin=http://nocache.all2e.com/var/plain_site/storage/original/video/schoon.swf
DefaultVideo=http://nocache.all2e.com/var/plain_site/storage/original/video/example.flv
Fullscreen=true
Autostart=false


*/ ?>
