<?php

$Module = array( 'name' => 'jwplayer' );

$ViewList = array();
$ViewList['getsettings'] = array('script' => 'getsettings.php',
                                 'functions' => array( 'getsettings' ),
                                 'params' => array( 'class' )
                                );

$FunctionList = array();
$FunctionList['getsettings'] = array();

?>
