<?php
/*
[TemplateSettings]
ExtensionAutoloadPath[]=nmleasingprice
*/
?>