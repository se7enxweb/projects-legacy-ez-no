<?php
/*
[Common]
leasingPriceNodeID=3026
#set this to the folder/container with the leasing-objects

leasingPriceClassID=45
#set this tothe classID of the leasingobjects.
*/
?>
