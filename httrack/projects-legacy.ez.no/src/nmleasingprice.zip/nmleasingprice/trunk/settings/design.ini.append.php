<?php
/*
[ExtensionSettings]
DesignExtensions[]=nmleasingprice
*/
?>