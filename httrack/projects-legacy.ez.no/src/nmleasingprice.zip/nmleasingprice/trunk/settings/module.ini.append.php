<?php
/*
[ModuleSettings]
ExtensionRepositories[]=nmleasingprice
*/
?>
