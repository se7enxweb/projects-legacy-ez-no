<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/nmleasingprice/operators/templateleasingpriceoperator.php',
                                    'class' => 'TemplateLeasingPriceOperator',
                                    'operator_names' => array( 'leasing' ) );

?>