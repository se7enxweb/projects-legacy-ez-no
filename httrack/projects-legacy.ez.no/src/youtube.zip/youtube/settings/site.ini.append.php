<?php

[TemplateSettings]
ExtensionAutoloadPath[]=youtube

?>