<?
/*
[ExtensionSettings]
DesignExtensions[]=nmstrictfixes
*/
?>