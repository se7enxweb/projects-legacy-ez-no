<?php
class ggxmlviewInfo
{
    static function info()
    {
        return array(
            'Name' => "gg XML View extension",
            'Version' => "0.4-dev",
            'Copyright' => "Copyright (C) 2008-2010 G. Giunta",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>
