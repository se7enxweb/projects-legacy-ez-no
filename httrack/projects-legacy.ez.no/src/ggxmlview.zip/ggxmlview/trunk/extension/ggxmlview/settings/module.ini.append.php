<?php /*

[ModuleSettings]
ExtensionRepositories[]=ggxmlview
ModuleList[]=xml

*/ ?>