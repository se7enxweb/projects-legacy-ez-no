<?php /*

[xml]
PageLayout=xml_pagelayout.tpl
ContentType=text/xml
UseAccessPass=false

[json]
PageLayout=json_pagelayout.tpl
ContentType=application/json
UseAccessPass=false

*/ ?>