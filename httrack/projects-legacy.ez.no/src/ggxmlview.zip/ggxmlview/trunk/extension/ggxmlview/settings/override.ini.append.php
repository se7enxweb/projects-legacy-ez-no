<?php /*

# Example of how to turn the default view of node XXX into xml

#[node_xml]
#Source=node/view/full.tpl
#MatchFile=node/view/xml.tpl
#Subdir=templates
#Match[node]=XXX

#[pagelayout_xml]
#Source=pagelayout.tpl
#MatchFile=pagelayout_xml.tpl
#Subdir=templates
#Match[node]=XXX

*/ ?>