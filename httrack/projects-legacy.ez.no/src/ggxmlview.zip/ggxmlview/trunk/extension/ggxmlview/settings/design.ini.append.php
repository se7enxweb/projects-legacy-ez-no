<?php /*

[ExtensionSettings]
DesignExtensions[]=ggxmlview

*/ ?>