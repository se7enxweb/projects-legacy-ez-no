<?php
/*
[ModuleSettings]
# A list of extensions which have modules
ExtensionRepositories[]=nmitemcount

*/
?>