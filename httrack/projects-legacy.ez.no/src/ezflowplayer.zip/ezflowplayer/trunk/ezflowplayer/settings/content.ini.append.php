<?php /*

[DataTypeSettings]
ExtensionDirectories[]=ezflowplayer
AvailableDataTypes[]=ezflowmedia

*/ ?>