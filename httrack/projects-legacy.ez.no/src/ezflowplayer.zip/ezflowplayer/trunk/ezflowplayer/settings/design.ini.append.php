<?php /*

[ExtensionSettings]
DesignExtensions[]=ezflowplayer

[JavaScriptSettings]
# List of JavaScript files to include in pagelayout
JavaScriptList[]=flowplayer-3.0.6.min.js

[StylesheetSettings]
CSSFileList[]=flowplayer.css

*/ ?>