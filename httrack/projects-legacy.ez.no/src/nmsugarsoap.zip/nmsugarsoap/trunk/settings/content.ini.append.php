<?php
/*
[DataTypeSettings]
# A list of extensions which have content object datatypes
# It's common to create a settings/content.ini.append file
# in your extension and add the extension name to automatically
# get datatypes from the extension when it's turned on.
ExtensionDirectories[]=nmsugarsoap
AvailableDataTypes[]=nmsugarcontact

*/
?>