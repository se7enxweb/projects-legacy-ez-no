<?php

/*
[ExtensionSettings]
DesignExtensions[]=nmsugarsoap
*/
?>