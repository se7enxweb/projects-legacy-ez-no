<?php
/*

[ModuleSettings]
ExtensionRepositories[]=nmsugarsoap

*/
?>