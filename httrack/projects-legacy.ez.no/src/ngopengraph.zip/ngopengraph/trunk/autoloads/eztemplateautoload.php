<?php
	$eZTemplateOperatorArray = array();

	$eZTemplateOperatorArray[] = array(
		'script' => 'extension/ngopengraph/autoloads/opengraphoperator.php',
		'class' => 'OpenGraphOperator',
		'operator_names' => array( 'opengraph' )
	);
?>