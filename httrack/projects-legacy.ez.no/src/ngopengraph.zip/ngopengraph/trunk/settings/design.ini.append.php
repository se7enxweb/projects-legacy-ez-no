<?php /*

[ExtensionSettings]
DesignExtensions[]=ngopengraph

*/ ?>