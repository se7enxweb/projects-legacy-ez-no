<?php /*

[PHP]
PHPOperatorList[urlencode]=urlencode

*/ ?>