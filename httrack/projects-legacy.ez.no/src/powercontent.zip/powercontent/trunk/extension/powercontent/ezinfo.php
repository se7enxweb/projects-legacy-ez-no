<?php
class powercontentInfo
{
    static function info()
    {
        return array(
            'Name' => "Powercontent",
            'Version' => "2.x",
            'Copyright' => "Copyright (C) 2008 Kristof Coomans",
            'Author' => "Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>