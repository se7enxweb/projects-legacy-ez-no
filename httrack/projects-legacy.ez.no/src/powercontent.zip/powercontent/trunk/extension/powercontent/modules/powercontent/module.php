<?php

$Module = array( 'name' => 'Power Content' );

$ViewList = array();
$ViewList['action'] = array(
    'default_navigation_part' => 'ezcontentnavigationpart',
    'ui_context' => 'edit',
    'script' => 'action.php',
    'params' => array(  ) );

?>
