<?php
class powercontentInfo
{
    function info()
    {
        return array(
            'Name' => "Powercontent",
            'Version' => "1.x",
            'Copyright' => "Copyright (C) 2006-2007 SCK-CEN",
            'Author' => "Kristof Coomans",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>