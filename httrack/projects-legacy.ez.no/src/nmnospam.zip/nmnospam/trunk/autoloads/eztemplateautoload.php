<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/nmnospam/operators/templatenospamoperator.php',
                                    'class' => 'TemplateNoSpamOperator',
                                    'operator_names' => array( 'nospam' ) );
?>