$(document).ready(function(){
    $('a.nospam').nospam({
      replaceText: true, 
      filterLevel: 'normal'
    });
  });
