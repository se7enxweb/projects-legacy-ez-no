<?php

class ezwebinInfo
{
    static function info()
    {
        return array( 'Name' => "Netmaking No Spam",
                      'Version' => "1.0.0",
                      'Copyright' => "Copyright (C) 2008 Netmaking AS",
                      'License' => "GNU"
                     );
    }
}
?>
