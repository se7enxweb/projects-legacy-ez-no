<?php
/*
[TemplateSettings]
ExtensionAutoloadPath[]=nmnospam
*/
?>