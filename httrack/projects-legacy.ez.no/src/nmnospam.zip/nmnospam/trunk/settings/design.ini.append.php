<?php /* #?ini charset="iso-8859-1"?

[ExtensionSettings]
DesignExtensions[]=nmnospam

[JavaScriptSettings]
JavaScriptList[]=nospam.js
JavaScriptList[]=nospam_config.js
*/ ?>