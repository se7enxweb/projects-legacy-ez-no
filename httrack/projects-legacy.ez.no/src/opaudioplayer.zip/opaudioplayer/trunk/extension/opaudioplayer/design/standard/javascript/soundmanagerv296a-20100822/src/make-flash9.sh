#!/bin/bash
/Applications/flexsdk/bin/mxmlc -use-network=false -optimize=true -o ../swf/soundmanager2_flash9_debug.swf -file-specs "SoundManager2_AS3.as"
