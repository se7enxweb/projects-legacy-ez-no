<?php /* #?ini charset="utf-8"?


[embed_audio_flash_player]
Source=content/view/embed.tpl
MatchFile=embed/audio_flash_player.tpl
Subdir=templates
Match[class_identifier]=audio_flash_player

*/ ?>