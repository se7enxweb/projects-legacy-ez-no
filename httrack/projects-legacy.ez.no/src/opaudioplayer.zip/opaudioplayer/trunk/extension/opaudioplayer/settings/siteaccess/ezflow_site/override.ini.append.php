<?php /* #?ini charset="utf-8"?

[full_audio_flash_player]
Source=node/view/full.tpl
MatchFile=full/audio_flash_player.tpl
Subdir=templates
Match[class_identifier]=audio_flash_player

*/ ?>