<?php /* #?ini charset="iso-8859-1"?

[ModuleSettings]
ExtensionRepositories[]=nxc_cmisserver
ModuleList[]=cmis

*/ ?>
