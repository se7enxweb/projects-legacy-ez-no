<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR" sourcelanguage="en">
<context>
    <name>extension/jvmonitoring</name>
    <message>
        <source>eZ Publish application monitoring for '%sitename'</source>
        <translation>Monitoring de l'application eZ Publish '%sitename'</translation>
    </message>
    <message>
        <source>General Status</source>
        <translation>Statut général</translation>
    </message>
</context>
</TS>
