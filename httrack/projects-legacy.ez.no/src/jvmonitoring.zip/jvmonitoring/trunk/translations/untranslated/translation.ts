<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR" sourcelanguage="en">
<context>
    <name>extension/jvmonitoring</name>
    <message>
        <source>eZ Publish application monitoring for '%sitename'</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General Status</source>
		<translation type="unfinished"></translation>
    </message>
</context>
</TS>
