<?php /* #?ini charset="utf-8"?

[RoleSettings]
PolicyOmitList[]=jvmonitoring

[RegionalSettings]
TranslationExtensions[]=jvmonitoring

*/ ?>