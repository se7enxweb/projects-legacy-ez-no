function runTask(params)
{
    jQuery('div.loader').show();
    jQuery.ez( 'xmlinstaller::runTask', params,
                function( data )
                {
                    jQuery("div.loader").hide();
                    jQuery("div#task-results").html(data.content);
                } );
}