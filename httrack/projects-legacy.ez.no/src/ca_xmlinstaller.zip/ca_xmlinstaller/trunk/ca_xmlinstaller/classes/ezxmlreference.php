<?php

/**
 * eZXMLReference persistent object class definition
 * 
 */

class eZXMLReference extends eZPersistentObject
{
    /**
     * Construct, use {@link eZXMLReference::create()} to create new objects.
     * 
     * @param array $row
     */
    public function __construct( $row )
    {
        parent::__construct( $row );
    }

    /**
     * Fields definition.
     * 
     * @static
     * @return array
     */
    public static function definition()
    {
        static $def = array( 'fields' => array( 'id' => array( 'name' => 'ID',
                                                               'datatype' => 'integer',
                                                               'default' => 0,
                                                               'required' => true ),
                                                'task_id' => array( 'name' => 'taskId',
                                                                 'datatype' => 'integer',
                                                                 'default' => '',
                                                                 'required' => true ),
                                                'identifier' => array( 'name' => 'identifier',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => true ),
                                                'value' => array( 'name' => 'value',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => false )
                                               ),
                             'keys' => array( 'id' ),
                             'function_attributes' => array(),
                             'increment_key' => 'id',
                             'class_name' => 'eZXMLReference',
                             'name' => 'ezxmlreference' );
        return $def;
    }
    
    /**
     * Creates new eZXMLReference object
     * 
     * @static
     * @param array $row
     * @return eZXMLReference
     */
    public static function create( $row = array() )
    {
        $object = new self( $row );
        return $object;
    }

    /**
     * Fetch eZXMLReference by given id.
     * 
     * @param int $id
     * @return null|eZXMLReference
     */
    static function fetch( $id )
    {
        $cond = array( 'id' => $id );
        $return = eZPersistentObject::fetchObject( self::definition(), null, $cond );
        return $return;
    }
    
    static function updateFields( $fields, $conditions )
    {
        $parameters = array();
        $parameters['definition'] = self::definition();
        $parameters['update_fields'] = $fields;
        $parameters['conditions'] = $conditions;
        //use try to catch the error
        eZPersistentObject::updateObjectList( $parameters );
    }

    public function remove( $conditions = null, $extraConditions = null )
    {
        parent::remove( $conditions, $extraConditions );
    }
    
}

?>