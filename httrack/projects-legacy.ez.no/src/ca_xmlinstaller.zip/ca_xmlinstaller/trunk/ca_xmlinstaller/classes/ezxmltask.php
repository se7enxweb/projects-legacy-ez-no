<?php

/**
 * ezxmltasks persistent object class definition
 * 
 */

class eZXMLTask extends eZPersistentObject
{
    /**
     * Construct, use {@link eZXMLTask::create()} to create new objects.
     * 
     * @param array $row
     */
    public function __construct( $row )
    {
        parent::__construct( $row );
    }

    /**
     * Fields definition.
     * 
     * @static
     * @return array
     */
    public static function definition()
    {
        static $def = array( 'fields' => array( 'id' => array( 'name' => 'ID',
                                                               'datatype' => 'integer',
                                                               'default' => 0,
                                                               'required' => true ),
                                                'name' => array( 'name' => 'name',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => true ),
                                                'task_id' => array( 'name' => 'taskIdentifier',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => true ),
                                                'is_task_set' => array( 'name' => 'isTaskSet',
                                                                 'datatype' => 'integer',
                                                                 'default' => '0',
                                                                 'required' => false )
                                               ),
                             'keys' => array( 'id' ),
                             'function_attributes' => array(),
                             'increment_key' => 'id',
                             'class_name' => 'eZXMLTask',
                             'name' => 'ezxmltask' );
        return $def;
    }
    
    /**
     * Creates new eZXMLTask object
     * 
     * @static
     * @param array $row
     * @return eZXMLTask
     */
    public static function create( $row = array() )
    {
        $object = new self( $row );
        return $object;
    }

    /**
     * Fetch eZXMLTask by given id.
     * 
     * @param int $id
     * @return null|eZXMLSettings
     */
    static function fetch( $id )
    {
        $cond = array( 'id' => $id );
        $return = eZPersistentObject::fetchObject( self::definition(), null, $cond );
        return $return;
    }
    
    static function updateFields( $fields, $conditions )
    {
        $parameters = array();
        $parameters['definition'] = self::definition();
        $parameters['update_fields'] = $fields;
        $parameters['conditions'] = $conditions;
        //use try to catch the error
        eZPersistentObject::updateObjectList( $parameters );
    }

    public function remove( $conditions = null, $extraConditions = null )
    {       
        if ( $this->attribute('is_task_set') )
        {
            $taskSetDef = eZTaskSet::definition();
            $conds = array( 'task_set_id' => $this->attribute('id') );
            $createdChildrenTasks = eZTaskSet::fetchObjectList($taskSetDef, null, $conds);

            foreach ( $createdChildrenTasks as $childTask )
            {
                if ( is_object($childTask) )
                {
                    $taskDef = eZXMLTask::definition();
                    $conds = array( 'id' => $childTask->attribute('task_id') );
                    $task = eZXMLTask::fetchObject($taskDef, null, $conds);
                    if ( is_object($task) )
                    {
                        $task->remove();
                    }

                    $childTask->remove();
                }
            }
        }

        $settingsDef = eZXMLSettings::definition();
        $conds = array( 'persistent_task_id' => $this->attribute('id') );
        $settings= eZXMLSettings::fetchObjectList($settingsDef, null, $conds);

        foreach ( $settings as $item )
        {
            $item->remove();
        }

        $referenceDef = eZXMLReference::definition();
        $conds = array( 'task_id' => $this->attribute('id') );
        $references= eZXMLReference::fetchObjectList($referenceDef, null, $conds);

        foreach ( $references as $reference )
        {
            $reference->remove();
        }

        parent::remove( $conditions, $extraConditions );
    }
    
}

?>