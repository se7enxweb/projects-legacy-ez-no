<?php

/**
 * Implements methods called remotely by sending XHR calls
 * 
 */
class XMLInstallerServerCallFunctions
{
    /**
     * Run task
     * 
     * @param mixed $args
     * @return array
     */
    public static function runTask( $args )
    {
        $http = eZHTTPTool::instance();
        $xmlInstallerIni = eZIni::instance('xmlinstaller.ini');
        $task_identifier = $http->postVariable( 'task_identifier' );
        $tpl_info = $http->postVariable( 'tpl_info' );
        $taskSetId = false;
        
        $persistentTaskId = false;
        if ( $http->hasPostVariable( 'persistent_task_id' ) )
        {
            $persistentTaskId = $http->postVariable( 'persistent_task_id' );
            $taskSetDef = eZTaskSet::definition();
            $conds = array( 'task_id' => $persistentTaskId );
            $taskSetBind = eZTaskSet::fetchObject( $taskSetDef, null, $conds);
            if ( is_object($taskSetBind) )
            {
                $taskSetBind->setAttribute('done',1);
                $taskSetBind->store();
                $taskSetId = $taskSetBind->attribute('task_set_id');
            }
        }
        
        $templateFile = $xmlInstallerIni->variable($task_identifier,'TemplateFile');

        $xml = eZPrepareXML::prepareXMLFromTemplate( $templateFile, false, $tpl_info, $taskSetId );
        $dom = new DOMDocument( '1.0', 'utf-8' );
        $dom->loadXML( $xml );

        $path = '/var/factory.xml';
        $handler = eZClusterFileHandler::instance( $path );
        $handler->storeContents( $dom->saveXML(), 'text', 'text/plain' );
        
        $xmlInstaller = new eZXMLInstaller( $dom, $persistentTaskId );
        eZLog::write('Start processing XML','factory.log');
        $messages = $xmlInstaller->proccessXML();

        $html_results = "<h2>Summary</h2>";
        $html_results .= "<p><b>" . count($messages['notice']) . " notices</b></p>";
        if ( count($messages['notice']) )
        {
            $html_results .= "<ul>";
            foreach ( $messages['notice'] as $msg )
            {
                $html_results .= "<li>" . $msg . "</li>";
                eZLog::write('$msg','factory.log');
            }
            $html_results .= "</ul>";
        }
        $html_results .= "<p><b>" . count($messages['warning']) . " warnings</b></p>";
        if ( count($messages['warning']) )
        {
            $html_results .= "<ul>";
            foreach ( $messages['warning'] as $msg )
            {
                $html_results .= "<li>" . $msg . "</li>";
            }
            $html_results .= "</ul>";
        }
        $html_results .= "<p><b>" . count($messages['error']) . " errors</b></p>";
        if ( count($messages['error']) )
        {
            $html_results .= "<ul>";
            foreach ( $messages['error'] as $msg )
            {
                $html_results .= "<li>" . $msg . "</li>";
            }
            $html_results .= "</ul>";
        }
        
        return $html_results;
    }
}

?>