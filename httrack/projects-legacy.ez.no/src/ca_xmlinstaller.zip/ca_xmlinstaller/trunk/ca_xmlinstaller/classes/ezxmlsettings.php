<?php

/**
 * eZXMLSettings persistent object class definition
 * 
 */

class eZXMLSettings extends eZPersistentObject
{
    /**
     * Construct, use {@link eZXMLSettings::create()} to create new objects.
     * 
     * @param array $row
     */
    public function __construct( $row )
    {
        parent::__construct( $row );
    }

    /**
     * Fields definition.
     * 
     * @static
     * @return array
     */
    public static function definition()
    {
        static $def = array( 'fields' => array( 'id' => array( 'name' => 'ID',
                                                               'datatype' => 'integer',
                                                               'default' => 0,
                                                               'required' => true ),
                                                'persistent_task_id' => array( 'name' => 'persistentTaskId',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => true ),
                                                'identifier' => array( 'name' => 'identifier',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => true ),
                                                'value' => array( 'name' => 'value',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => false )
                                               ),
                             'keys' => array( 'id' ),
                             'function_attributes' => array(),
                             'increment_key' => 'id',
                             'class_name' => 'eZXMLSettings',
                             'name' => 'ezxmlsettings' );
        return $def;
    }
    
    /**
     * Creates new eZXMLSettings object
     * 
     * @static
     * @param array $row
     * @return eZXMLSettings
     */
    public static function create( $row = array() )
    {
        $object = new self( $row );
        return $object;
    }

    /**
     * Fetch eZXMLSettings by given id.
     * 
     * @param int $id
     * @return null|eZXMLSettings
     */
    static function fetch( $id )
    {
        $cond = array( 'id' => $id );
        $return = eZPersistentObject::fetchObject( self::definition(), null, $cond );
        return $return;
    }
    
    static function updateFields( $fields, $conditions )
    {
        $parameters = array();
        $parameters['definition'] = self::definition();
        $parameters['update_fields'] = $fields;
        $parameters['conditions'] = $conditions;
        //use try to catch the error
        eZPersistentObject::updateObjectList( $parameters );
    }

    public function remove( $conditions = null, $extraConditions = null )
    {
        parent::remove( $conditions, $extraConditions );
    }
    
}

?>