<?php 
/**
 * Manage state of XML Task
 */

class eZTaskManager
{
    
    public function __construct()
    {
    }
    
    static public function createTask( $task_identifer )
    {
        return eZTask::instance( $task_identifer );
    }
    
    static public function getCurrentTask()
    {
        $http = eZHTTPTool::instance();
        $serializedTask = $http->sessionVariable('currentXMLTask');
        $task = unserialize($serializedTask);
        
        $GLOBALS['eZTaskInstance'] = $task;
        return $task;
    }
    
    static public function saveTaskState()
    {
        $task = eZTask::instance();
        $serializedTask = serialize($task);
        
        $http = eZHTTPTool::instance();
        $http->setSessionVariable('currentXMLTask',$serializedTask);
    }
    
    static public function loadPersistentTaskAsCurrent( $taskID )
    {
        $taskDef = eZXMLTask::definition();
        $conds = array( 'id' => $taskID );
        $persistentTask = eZXMLTask::fetchObject($taskDef, null, $conds);
        
        $task = self::createTask( $persistentTask->attribute('task_id') );
        $task->setPersistentTaskId( $persistentTask->attribute('id') );
        $task->loadPersistentInfo();
        
        $GLOBALS['eZTaskInstance'] = $task;
        return $task;
    }
}