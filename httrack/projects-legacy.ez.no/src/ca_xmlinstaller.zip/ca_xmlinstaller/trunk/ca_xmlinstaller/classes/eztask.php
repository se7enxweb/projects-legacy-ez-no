<?php 
/**
 * Wrapper for XML tasks
 */

class eZTask
{
    public $task_identifier = '';
    public $tpl_info = array();
    public $name = '';
    public $persistent_task_id = false;
    
    public function __construct( $task_identifier )
    {
        $this->task_identifier = $task_identifier;
        $this->loadTemplateInfo();
        $this->setName();
    }
    
    /**
     * Returns a shared instance of the eZTask class.
     *
     * @return eZTask
     */
    static function instance( $task_identifier = false )
    {
        if ( $task_identifier )
        {
            $GLOBALS['eZTaskInstance'] = new eZTask( $task_identifier );
        }
        elseif ( (!isset( $GLOBALS['eZTaskInstance'] ) ||
             !( $GLOBALS['eZTaskInstance'] instanceof eZTask ))
            )
        {
            $GLOBALS['eZTaskInstance'] = new eZTask();
        }

        return $GLOBALS['eZTaskInstance'];
    }
    
    /**
     * Returns true if there is an instance of eZTask
     * @return boolean
     */
    static function hasInstance()
    {
        return isset( $GLOBALS['eZCLIInstance'] ) && $GLOBALS['eZCLIInstance'] instanceof eZCLI;
    }
    
    /**
     * Load needed parameters from XML template
     */
    private function loadTemplateInfo()
    {
        $xmlInstallerIni = eZINI::instance('xmlinstaller.ini');
        
        if ( $xmlInstallerIni->hasVariable($this->task_identifier,'TemplateFile') )
        {
            $templateFile = $xmlInstallerIni->variable($this->task_identifier,'TemplateFile');
    
            $XMLtpl = eZTemplate::factory();
            $template = 'design:' . $templateFile . '.tpl';
            
            $XMLtpl->setVariable( 'tpl_info', false );
            $content = $XMLtpl->fetch( $template );
            
            if ( $XMLtpl->variable( "tpl_info" ) !== false )
            {
                $this->tpl_info = $XMLtpl->variable( "tpl_info" );
            }
        }
    }
    
    /**
     * @return $tpl_info
     */
    public function getTemplateInfo( $withoutValue = false )
    {
        $templateInfo = $this->tpl_info;
        
        if ( $withoutValue )
        {
            $templateInfo = array();
            foreach ( $this->tpl_info as $infoId => $variable )
            {
                $templateInfo[$infoId] = array(  'info' => $variable['info'],
                                                 'type' => $variable['type'],
                                                 'default' => $variable['default']
                                                 );
            }
        }
        return $templateInfo;
    }
    
    private function setName()
    {
        $xmlInstallerIni = eZINI::instance('xmlinstaller.ini');
        $availableTasks = $xmlInstallerIni->variable('Tasks','AvailableTasks');
        $availableTasksSet = $xmlInstallerIni->variable('Tasks','AvailableTasksSet');
        if ( isset($availableTasks[ $this->task_identifier ]) )
        {
            $this->name = $availableTasks[ $this->task_identifier ];
        }
        elseif ( isset($availableTasksSet[ $this->task_identifier ]) )
        {
            $this->name = $availableTasksSet[ $this->task_identifier ];   
        }        
        else
        {
            $this->name = $this->task_identifier;
        }
    }
    
    public function getName()
    {
        return $this->name;
    }
    
    public function getTaskIdentifier()
    {
        return $this->task_identifier;
    }
    
    public function getPersistentTaskId()
    {
        return $this->persistent_task_id;
    }
    
    public function getPersistentObject()
    {
        $taskDef = eZXMLTask::definition();
        $conds = array( 'id' => $this->persistent_task_id );
        $persistentTask = eZXMLTask::fetchObject($taskDef, null, $conds);
        
        return $persistentTask;
    }
    
    public function setPersistentTaskId( $taskID )
    {
        $this->persistent_task_id = $taskID;
    }
    
    /**
     * Check if all parameters are filled and save in self::tpl_info if okay
     * @param eZHTTP instance $http
     */
    public function validateAndSaveHTTPInput( $http )
    {
        $warnings = array();
        $tplInfoDefined = array();
        foreach ( $this->tpl_info as $infoId => $variable )
        {
            if ( !$http->hasPostVariable($infoId) && !in_array( $variable['type'], array('checkbox','browse') )
                    || $http->postVariable($infoId) == ''  && !in_array( $variable['type'], array('checkbox','browse') ) )
            {
                $warnings[] = ezi18n( 'xmlinstaller', '%id is required', null, array( '%id' => $variable['info'] ) );
            }
            else
            {
                $tplInfoDefined[$infoId] = array(  'info' => $variable['info'],
                                                   'type' => $variable['type'],
                                                   'default' => $http->postVariable($infoId)
                                                 );
                if ( isset($variable['value']) )
                {
                    $tplInfoDefined[$infoId]['value'] = $variable['value'];
                }                                                 
            }
        }
        
        if ( !count($warnings) )
        {
            $this->tpl_info = $tplInfoDefined;
            
            if ( $this->isPersistent() )
            {
                $this->savePersistentInfo();
            }
        }
        
        return $warnings;
    }
    
    public function isPersistent()
    {
        return $this->persistent_task_id;
    }
    
    public function createPersistentTask( $name, $task_identifier, $is_task_set = false )
    {
        $newTask = eZXMLTask::create();
        $newTask->setAttribute('name', $name);
        $newTask->setAttribute('task_id', $task_identifier);
        if ( $is_task_set )
        {
            $newTask->setAttribute('is_task_set', 1);
        }
        $newTask->store();
        
        $this->persistent_task_id = $newTask->attribute('id');
    }
    
    /**
     * If Task is persistent save template info in DB
     */
    public function savePersistentInfo()
    {
        foreach( $this->tpl_info as $identifier => $settings )
        {
            $settingsDef = eZXMLSettings::definition();
            $conds = array( 'persistent_task_id' => $this->persistent_task_id,
                            'identifier' => $identifier);
            $existingSettings = eZXMLSettings::fetchObject($settingsDef, null, $conds);
            
            if ( $existingSettings )
            {
                $existingSettings->setAttribute('value', $settings['default']);
                $existingSettings->store();
            }
            else
            {
                $settingsObject = eZXMLSettings::create();
                $settingsObject->setAttribute('persistent_task_id', $this->persistent_task_id);
                $settingsObject->setAttribute('identifier', $identifier);
                $settingsObject->setAttribute('value', $settings['default']);
                $settingsObject->store();
            }
        }
    }
    
    public function loadPersistentInfo() 
    {        
        $tplInfoDefined = array();
        $xmlSettingsDef = eZXMLSettings::definition();
        
        foreach ( $this->tpl_info as $infoId => $variable )
        {
            $conds = array('persistent_task_id' => $this->persistent_task_id,
                           'identifier' => $infoId);
            $settings = eZXMLSettings::fetchObject($xmlSettingsDef, null, $conds);
            
            if ( $settings )
            {
                $tplInfoDefined[$infoId] = array(  'info' => $variable['info'],
                                                   'type' => $variable['type'],
                                                   'default' => $settings->attribute('value')
                                                 );
                if ( isset($variable['value']) )
                {
                    $tplInfoDefined[$infoId]['value'] = $variable['value'];
                }                                                   
            }
            else
            {
                $tplInfoDefined[$infoId] = array(  'info' => $variable['info'],
                                                   'type' => $variable['type'],
                                                   'default' => $variable['default']
                                                 );
                if ( isset($variable['value']) )
                {
                    $tplInfoDefined[$infoId]['value'] = $variable['value'];
                }                                                   
            }
        }
        
        $this->tpl_info = $tplInfoDefined;
    }
    
    public function removePersistentObject()
    {
        $xmlTaskDef = eZXMLTask::definition();
        $conds = array('id' => $this->persistent_task_id);
        $persistentTask = eZXMLTask::fetchObject($xmlTaskDef, null, $conds);
        
        $xmlSettingsDef = eZXMLSettings::definition();
        $conds = array('persistent_task_id' => $this->persistent_task_id);
        $settings = eZXMLSettings::fetchObjectList($xmlSettingsDef, null, $conds);
        
        $xmlReferenceDef = eZXMLReference::definition();
        $conds = array('persistent_task_id' => $this->persistent_task_id);
        $references = eZXMLReference::fetchObjectList($xmlReferenceDef, null, $conds);
        
        $taskSetDef = eZTaskSet::definition();
        $conds = array('task_id' => $this->persistent_task_id);
        $taskSetBind = eZTaskSet::fetchObject($taskSetDef, null, $conds);
        if ( is_object($taskSetBind) )
        {
            $taskSetBind->remove();
        }
        
        foreach( $settings as $settings_item )
        {
            $settings_item->remove();
        }
        
        foreach( $references as $reference )
        {
            $reference->remove();
        }
        
        $persistentTask->remove();
    }
    
    public function getArrayOfPersistentSettings()
    {        
        $xmlSettingsDef = eZXMLSettings::definition();
        $conds = array('persistent_task_id' => $this->persistent_task_id);
        $settings = eZXMLSettings::fetchObjectList($xmlSettingsDef, null, $conds);
    
        $values = array();
        foreach ( $settings as $settings_item )
        {
            $values[$settings_item->attribute('identifier')] = $settings_item->attribute('value'); 
        }
        
        return $values;
    }
    
    public function bindTaskwithSet( $task_set_id )
    {
        $newTaskSet = eZTaskSet::create();       
        $newTaskSet->setAttribute('task_set_id', $task_set_id);
        $newTaskSet->setAttribute('task_id', $this->getPersistentTaskId());
        $newTaskSet->setAttribute('task_identifier', $this->getTaskIdentifier());
        $newTaskSet->setAttribute('done', 0);
        $newTaskSet->store();
    }
}