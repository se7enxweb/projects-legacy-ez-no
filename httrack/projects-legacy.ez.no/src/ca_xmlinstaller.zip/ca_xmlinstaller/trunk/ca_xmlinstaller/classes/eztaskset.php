<?php

/**
 * eztaskset persistent object class definition
 * 
 */

class eZTaskSet extends eZPersistentObject
{
    /**
     * Construct, use {@link eZTaskSet::create()} to create new objects.
     * 
     * @param array $row
     */
    public function __construct( $row )
    {
        parent::__construct( $row );
    }

    /**
     * Fields definition.
     * 
     * @static
     * @return array
     */
    public static function definition()
    {
        static $def = array( 'fields' => array( 'id' => array( 'name' => 'ID',
                                                               'datatype' => 'integer',
                                                               'default' => 0,
                                                               'required' => true ),
                                                'task_set_id' => array( 'name' => 'taskSetId',
                                                                 'datatype' => 'integer',
                                                                 'default' => '',
                                                                 'required' => true ),
                                                'task_id' => array( 'name' => 'taskId',
                                                                 'datatype' => 'integer',
                                                                 'default' => '',
                                                                 'required' => true ),
                                                'task_identifier' => array( 'name' => 'taskIdentifier',
                                                                 'datatype' => 'string',
                                                                 'default' => '',
                                                                 'required' => true ),
                                                'done' => array( 'name' => 'done',
                                                                 'datatype' => 'integer',
                                                                 'default' => '0',
                                                                 'required' => false )
                                               ),
                             'keys' => array( 'id' ),
                             'function_attributes' => array(),
                             'increment_key' => 'id',
                             'class_name' => 'eZTaskSet',
                             'name' => 'eztaskset' );
        return $def;
    }
    
    /**
     * Creates new eZTaskSet object
     * 
     * @static
     * @param array $row
     * @return eZTaskSet
     */
    public static function create( $row = array() )
    {
        $object = new self( $row );
        return $object;
    }

    /**
     * Fetch eZTaskSet by given id.
     * 
     * @param int $id
     * @return null|eZTaskSet
     */
    static function fetch( $id )
    {
        $cond = array( 'id' => $id );
        $return = eZPersistentObject::fetchObject( self::definition(), null, $cond );
        return $return;
    }
    
    static function updateFields( $fields, $conditions )
    {
        $parameters = array();
        $parameters['definition'] = self::definition();
        $parameters['update_fields'] = $fields;
        $parameters['conditions'] = $conditions;
        //use try to catch the error
        eZPersistentObject::updateObjectList( $parameters );
    }

    public function remove( $conditions = null, $extraConditions = null )
    {
        parent::remove( $conditions, $extraConditions );
    }
    
}

?>