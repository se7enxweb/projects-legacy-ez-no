<?php

$eZTemplateOperatorArray = array();
$eZTemplateOperatorArray[] = array( 'script' => 'extension/ca_xmlinstaller/autoloads/ca_xmlinstallerautoloads.php',
                                    'class' => 'CAXMLInstallerAutoloads',
                                    'operator_names' => array( 'ezcrc', 'get_reference', 'convert_to_alias' ) );
?>