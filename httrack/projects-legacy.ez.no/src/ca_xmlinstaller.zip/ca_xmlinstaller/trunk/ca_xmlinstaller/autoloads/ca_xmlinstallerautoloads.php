<?php

class CAXMLInstallerAutoloads
{
    private $glossaryArray = array();
    /**
     * Constructor
     *
     */
    function __construct()
    {
    }

    /**
     * operatorList
     *
     * @return array list of template operators hosted by this class
     */
    function operatorList()
    {
        return array( 'ezcrc', 'get_reference', 'convert_to_alias' );
    }

    /**
     * namedParameterPerOperator
     *
     * @return true Indicates that {@link eZGlossary::namedParameterList()} should be used for parameters.
     */
    function namedParameterPerOperator()
    {
        return true;
    }

    /**
     * namedParameterList
     *
     * @return array List of operators and their parameters
     */
    function namedParameterList()
    {
        return array( 'ezcrc' => array(
                                    'value' => array( 'type' => 'text',
                                                      'required' => true,
                                                      'default' => array() )
                                       ),
                      'get_reference' => array(
                                    'identifier' => array( 'type' => 'text',
                                                           'required' => true,
                                                           'default' => array() ),
                                    'task_set_id' => array( 'type' => 'text',
                                                           'required' => true,
                                                           'default' => array() )
                                       ),
                      'convert_to_alias' => array(
                                    'value' => array( 'type' => 'text',
                                                      'required' => true,
                                                      'default' => array() )
                                       ),
                                  );
    }

    /**
     * modify
     * Called by the template system when the registrated operators are called in templates.
     *
     * @param object $tpl tempalte system object
     * @param string $operatorName name of currently called operator
     * @param array $operatorParameters ignored, as pr {@link eZGlossary::namedParameterPerOperator()}
     * @param string $rootNamespace
     * @param string $currentNamespace
     * @param string $operatorValue byref return value for template operator
     * @param string $namedParameters parameters for the names operators
     */
    function modify( $tpl, $operatorName, $operatorParameters, $rootNamespace, $currentNamespace, &$operatorValue, $namedParameters )
    {
        switch ( $operatorName )
        {
            case 'ezcrc':
                {
                    $ret = eZSys::ezcrc32( $namedParameters['value'] );
                } break;
            case 'get_reference':
                {
                    $eZTaskSetDef = eZTaskSet::definition();
                    $conds = array( 'task_set_id' => $namedParameters['task_set_id'] );
                    $filter = array( 'task_id' );
                    $tasksInTaskSet = eZTaskSet::fetchObjectList( $eZTaskSetDef, $filter, $conds );
                    
                    $TaskIdList = array();
                    foreach( $tasksInTaskSet as $task )
                    {
                        $TaskIdList[] = $task->attribute('task_id');
                    }
                    $ezXMLReferenceDef = eZXMLReference::definition();
                    $conds = array( 'task_id' => array( $TaskIdList ),
                                    'identifier' => $namedParameters['identifier']);
                    $reference = eZXMLReference::fetchObject( $ezXMLReferenceDef, null, $conds );                
                    if ( is_object($reference) )
                    {
                        $referenceID = $reference->attribute('value');
                    }
                    $ret = $referenceID;
                } break;
            case 'convert_to_alias':
                {
                    $ret = eZURLAliasML::convertToAlias( $namedParameters['value'] );
                } break;
        }
        $operatorValue = $ret;
    }

    
}

?>
