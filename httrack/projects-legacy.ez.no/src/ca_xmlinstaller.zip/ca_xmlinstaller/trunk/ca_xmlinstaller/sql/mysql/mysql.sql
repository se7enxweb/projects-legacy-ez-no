CREATE TABLE IF NOT EXISTS ezxmltask (
    id int(11) NOT NULL auto_increment,
    name varchar(255) NOT NULL,
    task_id varchar(255) NOT NULL,
    is_task_set int(11) NULL DEFAULT '0',
    PRIMARY KEY(id)
) TYPE=InnoDB;

CREATE TABLE IF NOT EXISTS ezxmlsettings (
    id int(11) NOT NULL auto_increment,
    persistent_task_id varchar(255) NOT NULL,
    identifier varchar(255) NOT NULL,
    value varchar(255) NULL,
    PRIMARY KEY(id)
) TYPE=InnoDB;

CREATE TABLE IF NOT EXISTS eztaskset (
    id int(11) NOT NULL auto_increment,
    task_set_id int(11) NOT NULL,
    task_id int(11) NOT NULL,
    task_identifier varchar(255) NOT NULL,
    done int(11) NULL DEFAULT '0',
    PRIMARY KEY(id)
) TYPE=InnoDB;

CREATE TABLE IF NOT EXISTS ezxmlreference (
    id int(11) NOT NULL auto_increment,
    task_id int(11) NOT NULL,
    identifier varchar(255) NOT NULL,
    value varchar(255) NOT NULL,
    PRIMARY KEY(id)
) TYPE=InnoDB;