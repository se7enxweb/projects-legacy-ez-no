<?php 

include_once('extension/ca_xmlinstaller/classes/ezxmlinstallerhandler.php');

class eZAddUrlAliasWildcard extends eZXMLInstallerHandler
{

    function eZAddUrlAliasWildcard( )
    {
    }

    function execute( $xml )
    {
        $this->proccessAddUrlAliasWildcard( $xml );
    }

    static public function handlerInfo()
    {
        return array( 'XMLName' => 'AddUrlAliasWildcard', 'Info' => 'Create a new url wildcard' );
    }


    function proccessAddUrlAliasWildcard( $xmlNode )
    {
        $objectList = $xmlNode->childNodes;
        $objectInformation = array();
        $objectInformation['source'] = $this->parseAndReplaceStringReferences( $xmlNode->getAttribute( 'source' ) );
        $objectInformation['destination'] = $this->parseAndReplaceStringReferences( $xmlNode->getAttribute( 'destination' ) );
        $objectInformation['type'] = $this->parseAndReplaceStringReferences( $xmlNode->getAttribute( 'type' ) );
        
        $this->addUrlAliasWildcard( $objectInformation );
        unset( $objectInformation );
    }

    function addUrlAliasWildcard( $objectInformation )
    {
        if ( $objectInformation['type'] == 'forward')
        {
            $type = eZURLWildcard::TYPE_FORWARD;
        }
        else
        {
            $type = eZURLWildcard::TYPE_DIRECT;
        }
        
        $row = array(
            'source_url' => $objectInformation['source'],
            'destination_url' => $objectInformation['destination'],
            'type' => $type );

        $wildcard = new eZURLWildcard( $row );
        $wildcard->store();

        eZURLWildcard::expireCache();
        
        return true;
    }
}

?>