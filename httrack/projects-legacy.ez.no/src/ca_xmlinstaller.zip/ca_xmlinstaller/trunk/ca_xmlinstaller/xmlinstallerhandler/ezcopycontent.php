<?php 

include_once('extension/ca_xmlinstaller/classes/ezxmlinstallerhandler.php');

class eZCopyContent extends eZXMLInstallerHandler
{

    function eZCopyContent( )
    {
    }

    function execute( $xml )
    {
        $this->proccessCopyContent( $xml );
    }

    static public function handlerInfo()
    {
        return array( 'XMLName' => 'CopyContent', 'Info' => 'Copy a content object' );
    }


    function proccessCopyContent( $xmlNode )
    {
        $objectList = $xmlNode->childNodes; //getElementsByTagName( 'CopyObject' );
        foreach ( $objectList as $objectNode )
        {            
            $subTreeMode = false;
            if ( $objectNode->nodeName == 'ContentSubtree' )
            {
                $subTreeMode = true;   
            }
            elseif ( $objectNode->nodeName != 'ContentObject' )
            {
                continue;
            }
            $objectInformation = array();
            $objectInformation['parentNode'] = $this->parseAndReplaceStringReferences( $xmlNode->getAttribute( 'parentNode' ) );
            if ( $objectNode->getAttribute( 'excludedNodeIdList' ) )
            {
                $excludedNodeIdList = $objectNode->getAttribute( 'excludedNodeIdList' );
                $objectInformation['excludedNodeIdList'] = explode('|',$excludedNodeIdList);
            }
            if ( $objectNode->getAttribute( 'locale' ) )
            {
                $objectInformation['locale'] = $objectNode->getAttribute( 'locale' );   
            }
            if ( $objectNode->getAttribute( 'removeTranslations' ) )
            {
                $objectInformation['removeTranslations'] = $objectNode->getAttribute( 'removeTranslations' );
            }
            if ( $objectNode->getAttribute( 'objectID' ) )
            {
                $objectInformation['objectID'] = $objectNode->getAttribute( 'objectID' );   
            }
            if ( $objectNode->getAttribute( 'nodeID' ) )
            {
                $objectInformation['nodeID'] = $objectNode->getAttribute( 'nodeID' );   
            }
            
            if ( $subTreeMode )
            {
               $this->copyContentSubtree( $objectInformation );
            }
            else
            {
                $this->copyContentObject( $objectInformation );
            }
            
            unset( $objectInformation );
        }            
    }

    function copyContentObject( $objectInformation )
    {
        $db = eZDB::instance();
        
        if ( $objectInformation['nodeID'] )
        {
            $contentObject = eZContentObject::fetchByNodeID( $objectInformation['nodeID'] );
        }
        elseif ( $objectInformation['objectID'] )
        {
            $contentObject = eZContentObject::fetch( $objectInformation['objectID'] );
        }
        
        if ( !is_object($contentObject) )
        {
            $this->writeMessage( "\tCannot fetch content object" , 'error' );
            return false;
        }
        
        if( ( $newParentNode = eZContentObjectTreeNode::fetch( $objectInformation['parentNode'] ) ) === null )
        {
            $this->writeMessage( "\tCannot fetch parent node" , 'error' );
            return false;
        }
        
        $classID = $contentObject->attribute('contentclass_id');
    
        if ( !$newParentNode->checkAccess( 'create', $classID ) )
        {   
            $this->writeMessage( "\tDo not have permission to copy object to this location" , 'error' );
            return false;
        }
        
        $db->begin();
        $orginalSectionId = $contentObject->attribute('section_id');
        $newObject = $contentObject->copy( false );
        $existingLanguage = $contentObject->availableLanguages();

        // We should reset section that will be updated in updateSectionID().
        // If sectionID is 0 then the object has been newly created
        $newObject->setAttribute( 'section_id', $orginalSectionId );
        $newObject->store();
        
        $curVersion = $newObject->attribute( 'current_version' );
        
        if ( $objectInformation['locale'] && $objectInformation['locale'] != $newObject->initialLanguageCode() )
        {
            $initialLanguageCode = $newObject->initialLanguageCode();
            $newObject->cleanupInternalDrafts();
            $newObject->clearCache();
            
            $newVersion = $newObject->createNewVersionIn( $objectInformation['locale'], $newObject->initialLanguageCode(), $newObject->attribute( 'current_version' ) );
            $newVersion->store();
            
            $language = eZContentLanguage::fetchByLocale( $objectInformation['locale'], false );
            $newObject->setCurrentLanguage( $objectInformation['locale'] );
            $newObject->setAttribute('initial_language_id',$language->attribute( 'id' ));
            $newObject->store();
            
            $newObject->clearCache();
            $curVersion = $newVersion->attribute( 'version' );
        }

        if ( $objectInformation['removeTranslations'] )
        {
            foreach ( $existingLanguage as $lang )
            {
                if ( $lang != $newObject->initialLanguageCode() )
                {
                    $language = eZContentLanguage::fetchByLocale( $lang, false );
                    $newObject->removeTranslation( $language->attribute( 'id' ) );
                }
                elseif ( $objectInformation['locale'] && $objectInformation['locale'] != $newObject->initialLanguageCode() )
                {
                    $language = eZContentLanguage::fetchByLocale( $lang, false );
                    $newObject->removeTranslation( $language->attribute( 'id' ) );
                }
            }
        }
        
        $curVersionObject  = $newObject->version( $curVersion );
        $newObjAssignments = $curVersionObject->attribute( 'node_assignments' );
        unset( $curVersionObject );
        
        // remove old node assignments
        foreach( $newObjAssignments as $assignment )
        {
            $assignment->purge();
        }
    
        // and create a new one
        $nodeAssignment = eZNodeAssignment::create( array(
                                                         'contentobject_id' => $newObject->attribute( 'id' ),
                                                         'contentobject_version' => $curVersion,
                                                         'parent_node' => $objectInformation['parentNode'],
                                                         'is_main' => 1
                                                         ) );
        $nodeAssignment->store();
        
        // publish the newly created object
        eZOperationHandler::execute( 'content', 'publish', array( 'object_id' => $newObject->attribute( 'id' ),
                                                                  'version'   => $curVersion ) );
        // Update "is_invisible" attribute for the newly created node.
        $newNode = $newObject->attribute( 'main_node' );
        $newNode->setCurrentLanguage( $objectInformation['locale'] );
        eZContentObjectTreeNode::updateNodeVisibility( $newNode, $newParentNode );
        
        // upate priority
        eZOperationHandler::execute( 'content', 'updatepriority', array( 'node_id' => $newNode->attribute( 'parent_node_id' ),
                                                                         'priority'   => array( $contentObject->mainNode()->attribute('priority') ),
                                                                         'priority_id' => array( $newNode->attribute('node_id') )
        ) );
        
        $this->writeMessage( "\tObject copied" , 'notice' );
        $db->commit();

        return $newNode->attribute('node_id');
    }
    
    function copyContentSubtree( $objectInformation )
    {
        $db = eZDB::instance();
        
        if ( $objectInformation['nodeID'] )
        {
            $contentNode = eZContentObjectTreeNode::fetch( $objectInformation['nodeID'] );
        }
        elseif ( $objectInformation['objectID'] )
        {
            $contentNode = eZContentObjectTreeNode::fetchByContentObjectID( $objectInformation['objectID'] );
        }
        
        if ( !is_object($contentNode) )
        {
            $this->writeMessage( "\tCannot fetch content node" , 'error' );
            return false;
        }
        
        // copy root node
        $newNodeId = $this->copyContentObject( $objectInformation );
        
        $this->fetchChildrenAndCopy( $contentNode, $newNodeId, $objectInformation );
                
        return true;
    }
    
    function fetchChildrenAndCopy( $contentNode, $parentNodeId, $objectInformation )
    {
        $childrenList = $contentNode->children();
        foreach( array_reverse($childrenList) as $child )
        {
            if ( isset( $objectInformation['excludedNodeIdList'] ) && in_array( $child->attribute('node_id'), $objectInformation['excludedNodeIdList'] ) )
            {
                continue;
            }
            
            $objectInformation['parentNode'] = $parentNodeId;
            $objectInformation['nodeID'] = $child->attribute('node_id');
            
            $newNodeId = $this->copyContentObject( $objectInformation );
            
            $this->fetchChildrenAndCopy( $child, $newNodeId, $objectInformation );
        }
    }
}

?>