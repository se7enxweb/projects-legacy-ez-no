<?php /*

[ezjscServer_xmlinstaller]
Class=XMLInstallerServerCallFunctions

*/ ?>
