<?php /* #?ini charset="utf8"?

[ExtensionSettings]
DesignExtensions[]=ca_xmlinstaller

*/ ?>
