<?php /*

[NavigationPart]
Part[xmltasksnavigationpart]=XML Tasks

[TopAdminMenu]
Tabs[]=xmltasks

[Topmenu_xmltasks]
NavigationPartIdentifier=xmltasksnavigationpart
Name=Tasks
Tooltip=Run & Manage XML Tasks
URL[]
URL[default]=xmlmanage/tasks
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
# We don't show it in browse mode
Shown[browse]=true

*/ ?>
