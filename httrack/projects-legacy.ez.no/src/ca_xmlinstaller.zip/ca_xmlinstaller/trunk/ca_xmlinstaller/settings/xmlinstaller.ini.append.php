<?php /*#?ini charset="utf-8"?
[XMLInstallerSettings]
ExtensionDirectories[]=ca_xmlinstaller

XMLInstallerHandler[]
XMLInstallerHandler[]=ezassignroles
XMLInstallerHandler[]=ezcopycontent
XMLInstallerHandler[]=ezcreatecontent
XMLInstallerHandler[]=ezsetsettings
XMLInstallerHandler[]=ezproccessinformation
XMLInstallerHandler[]=ezaddlocation
XMLInstallerHandler[]=ezhideunhide
XMLInstallerHandler[]=ezcreateclass
XMLInstallerHandler[]=ezcreaterole
XMLInstallerHandler[]=ezcreatesection
XMLInstallerHandler[]=ezcreateworkflow
XMLInstallerHandler[]=ezsendmail
XMLInstallerHandler[]=ezmodifycontent
XMLInstallerHandler[]=ezaddurlaliaswildcard
XMLInstallerHandler[]=eztranslatecontent

[Tasks]
#AvailableTasks[identifier]=Example Name of task
#AvailableTasks[]
#AvailableTasks[demo2]=Demo task

#AvailableTasksSet[]
#AvailableTasksSet[tasksetexample]=Task set Example

#[tasksetexample]
#ChildrenTask[]
#ChildrenTask[]=demo2

[demo2]
TemplateFile=xmlinstaller/demo2
 */?>