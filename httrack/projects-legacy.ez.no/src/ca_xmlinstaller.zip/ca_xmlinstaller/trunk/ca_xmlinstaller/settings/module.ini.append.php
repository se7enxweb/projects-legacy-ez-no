<?php /*

[ModuleSettings]
ExtensionRepositories[]=ca_xmlinstaller
ModuleList[]=xmlmanage

*/ ?>
