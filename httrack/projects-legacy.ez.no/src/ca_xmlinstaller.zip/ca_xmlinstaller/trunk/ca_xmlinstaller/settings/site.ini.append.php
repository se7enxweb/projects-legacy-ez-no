<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=ca_xmlinstaller

[RegionalSettings]
TranslationExtensions[]=ca_xmlinstaller

*/ ?>
