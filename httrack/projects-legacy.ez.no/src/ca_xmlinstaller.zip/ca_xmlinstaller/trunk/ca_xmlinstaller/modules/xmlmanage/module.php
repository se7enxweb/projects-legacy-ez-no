<?php

$Module = array( 'name' => 'CA XML Installer', 'variable_params' => true );

$ViewList = array();
$ViewList['tasks'] = array(
    'functions' => array( 'use' ),
    'default_navigation_part' => 'xmltasksnavigationpart',
    'ui_context' => 'administration',
    'script' => 'tasks.php',
    'params' => array(),
                            );
                            
$ViewList['edit'] = array(
    'functions' => array( 'use' ),
    'default_navigation_part' => 'xmltasksnavigationpart',
    'ui_context' => 'administration',
    'single_post_actions' => array( 'SavedRunButton' => 'SavedRun',
                                    'RemoveButton' => 'Remove',
                                    'UpdateButton' => 'Update',
                                    'DiscardButton' => 'Discard',
                                    'RunOnceButton' => 'RunOnce',
                                    'RunButton' => 'Run',
                                    'SaveButton' => 'Save',
                                    'PersistentButton' => 'Persistent',
                                    'BrowseRequestButton' => 'BrowseRequest',
        ),
    'post_actions' => array( 'BrowseActionName' ),
    'script' => 'edit.php',
    'params' => array('task_id'),
                            );                    

$ViewList['view'] = array(
    'functions' => array( 'use' ),
    'default_navigation_part' => 'xmltasksnavigationpart',
    'ui_context' => 'administration',
    'script' => 'view.php',
    'params' => array('task_id'),   
                            );

$ViewList['remove'] = array(
    'functions' => array( 'use' ),
    'default_navigation_part' => 'xmltasksnavigationpart',
    'ui_context' => 'administration',
    'script' => 'remove.php',
    'params' => array('task_id'),
                            );

$ViewList['run'] = array(
    'functions' => array( 'use' ),
    'default_navigation_part' => 'xmltasksnavigationpart',
    'ui_context' => 'administration',
    'script' => 'run.php',
    'params' => array('task_id'),
                            );

$ViewList['set'] = array(
    'functions' => array( 'use' ),
    'default_navigation_part' => 'xmltasksnavigationpart',
    'ui_context' => 'administration',
    'script' => 'set.php',
    'params' => array('task_id'),
                            );                            

$FunctionList = array();
$FunctionList['use'] = array();
?>
