<?php
require_once( "kernel/common/template.php" );

/*
 * Initialize 
 */
$module = $Params['Module'];
$http = eZHTTPTool::instance();
$xmlInstallerIni = eZINI::instance('xmlinstaller.ini');
$availableTasks = $xmlInstallerIni->variable('Tasks','AvailableTasks');
$tpl = eZTemplate::factory();
$taskID = $Params['task_id'];

// one pushed run from persistent view
if ( $module->isCurrentAction('SavedRun') )
{
    $module->redirectToView('run', array($taskID));
}

// one pushed remove from persistent view
if ( $module->isCurrentAction('Remove') )
{
    $task = eZTaskManager::loadPersistentTaskAsCurrent( $taskID );
    $task->removePersistentObject();
    
    $module->redirectToView('tasks');
}

// one pushed edit from persistent view
if ( $module->isCurrentAction('Update') )
{
    $task = eZTaskManager::loadPersistentTaskAsCurrent( $taskID );
    
    $task_name = $task->getName();
    $tpl->setVariable( 'name', $task_name );
    $tpl->setVariable( 'tpl_info', $task->getTemplateInfo() );
    
    $tpl->setVariable( 'post', $task->getArrayOfPersistentSettings() );
    $tpl->setVariable( 'is_persistent', $task->isPersistent() );
    
    eZTaskManager::saveTaskState();
}

// One pushed cancel : go back to tasks list
if ( $module->isCurrentAction('Discard') )
{
    $module->redirectToView('tasks');
}

// New run once from tasks list
if ( $module->isCurrentAction('RunOnce') )
{
    $task = eZTaskManager::createTask( $http->postVariable('task_identifier') );
    $task_name = $task->getName();
    $tpl->setVariable('name', $task_name );
    $tpl->setVariable('tpl_info', $task->getTemplateInfo() );
    eZTaskManager::saveTaskState();
}

// Run asked, check the parameters first
if ( $module->isCurrentAction('Run') || $module->isCurrentAction('Save') )
{
    $task = eZTaskManager::getCurrentTask();
    $task_name = $task->getName();
    $tpl->setVariable('name', $task_name );
    $tpl->setVariable('tpl_info', $task->getTemplateInfo() );
    $tpl->setVariable( 'is_persistent', $task->isPersistent() );
    
    $warnings = $task->validateAndSaveHTTPInput( $http );
    if ( count($warnings) )
    {
        $tpl->setVariable('warnings', $warnings);
        $tpl->setVariable('post', $_POST);
    }
    else
    {
        eZTaskManager::saveTaskState();
        
        $params = array();
        if ( $task->isPersistent() )
        {
            $params = array( $task->getPersistentTaskId() );
        }
        
        if ( $module->isCurrentAction('Save') )
        {
            $module->redirectToView('view', $params);
        }
        else
        {
            $module->redirectToView('run', $params);
        }
    }
}

// Persistent settings asked
if ( $module->isCurrentAction('Persistent') )
{
    if ( !$http->hasPostVariable('task_name') || $http->postVariable('task_name') == '' )
    {
        $module->redirectToView('tasks');
    }
    else
    {
        $task = eZTaskManager::createTask( $http->postVariable('task_identifier') );
        
        $is_task_set = false;
        if ( $http->hasPostVariable('is_task_set') )
        {
            $is_task_set = true;            
        }
        
        $task->createPersistentTask( $http->postVariable('task_name'), $http->postVariable('task_identifier'), $is_task_set );
        if ( $http->hasPostVariable('task_set_id') )
        {
            $task->bindTaskwithSet( $http->postVariable('task_set_id') );
        }
        
        $task_name = $task->getName();
        $tpl->setVariable('name', $task_name );
        $tpl->setVariable('tpl_info', $task->getTemplateInfo() );
        $tpl->setVariable( 'is_persistent', $task->isPersistent() );        
        eZTaskManager::saveTaskState();
        
        if ( $is_task_set )
        {
            $module->redirectToView('set', array( $task->getPersistentTaskId() ) );
        }
    }
}

if ( $module->isCurrentAction('BrowseRequest') )
{
    $task = eZTaskManager::getCurrentTask();
    $task_name = $task->getName();
    $tpl->setVariable('name', $task_name );
    $tpl->setVariable('tpl_info', $task->getTemplateInfo() );
    $tpl->setVariable( 'is_persistent', $task->isPersistent() );

    $warnings = $task->validateAndSaveHTTPInput( $http );
    if ( count($warnings) )
    {
        $tpl->setVariable('warnings', $warnings);
        $tpl->setVariable('post', $_POST);
    }
    else
    {
        eZTaskManager::saveTaskState();

        // save array to a variable otherwise direct call of key lead to seg fault of php thread on php 5.2.6
        $browseData = $http->postVariable('BrowseRequestButton');
        eZContentBrowse::browse( array( 'action_name' => 'BrowseResult',
                                        'description_template' => 'design:content/browse_placement.tpl',
                                        'start_node' => 2,
                                        'persistent_data' => array( 'ParamsIdentifier' => key($browseData) ),
                                        'cancel_page' => $module->redirectionURIForModule( $module, 'view', array( 'full', 2) ),
                                        'from_page' => "/xmlmanage/edit/" . $task->getPersistentTaskId() ),
                                        $module );
    }
}

if ( $module->isCurrentAction('BrowseResult') )
{
    $task = eZTaskManager::getCurrentTask();

    $task_name = $task->getName();
    $tpl->setVariable( 'name', $task_name );
    $tpl->setVariable( 'tpl_info', $task->getTemplateInfo() );

    $tpl->setVariable( 'post', $task->getArrayOfPersistentSettings() );
    $tpl->setVariable( 'is_persistent', $task->isPersistent() );

    eZTaskManager::saveTaskState();
    
    $tpl->setVariable( 'browse_result', array( $http->postVariable("ParamsIdentifier") => $http->postVariable('SelectedNodeIDArray') ) );
}

$Result = array();
$Result['content'] = $tpl->fetch( "design:xmlinstaller/edit.tpl" );
$Result['left_menu'] = "design:xmlinstaller/parts/index_left_menu.tpl";
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'xmlinstaller', 'XMLInstaller' ) ),
                         array( 'url' => 'xmlmanage/tasks',
                                'text' => ezi18n( 'xmlinstaller', 'Tasks list' ) ),
                         array( 'url' => false,
                                'text' => ezi18n( 'xmlinstaller', 'Edit ' . $task_name ) ) );

?>