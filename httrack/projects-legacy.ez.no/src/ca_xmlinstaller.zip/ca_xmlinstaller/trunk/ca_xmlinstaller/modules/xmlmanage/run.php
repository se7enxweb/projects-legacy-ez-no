<?php
require_once( "kernel/common/template.php" );

$module = $Params['Module'];
$http = eZHTTPTool::instance();
$tpl = templateInit();
$taskID = $Params['task_id'];
$XMLtpl = eZTemplate::factory();
$xmlInstallerIni = eZINI::instance('xmlinstaller.ini');

if ( $taskID )
{
    $task = eZTaskManager::loadPersistentTaskAsCurrent( $taskID );
    $persistentObject = $task->getPersistentObject();
    
    $tpl->setVariable( 'name', $task->getName() );
    $tpl->setVariable( 'tpl_info', $task->getTemplateInfo(true) );
    $tpl->setVariable( 'task_id', $task->getTaskIdentifier() );
    $tpl->setVariable( 'persistent_task_id', $task->getPersistentTaskId() );
}
else
{
    $task = eZTaskManager::getCurrentTask();

    $tpl->setVariable( 'name', $task->getName() );
    $tpl->setVariable( 'tpl_info', $task->getTemplateInfo() );
    $tpl->setVariable( 'task_id', $task->getTaskIdentifier() );
}

$Result = array();
$Result['content'] = $tpl->fetch( "design:xmlinstaller/run.tpl" );
$Result['left_menu'] = "design:xmlinstaller/parts/index_left_menu.tpl";
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'xmlinstaller', 'XMLInstaller' ) ),
                         array( 'url' => false,
                                'text' => ezi18n( 'xmlinstaller', 'Tasks list' ) ) );

?>
