<?php
require_once( "kernel/common/template.php" );

$module = $Params['Module'];
$http = eZHTTPTool::instance();
$tpl = templateInit();

$viewParameters = array();

$viewParameters = array_merge( $viewParameters, array( 'offset' => ( isset( $Params['Offset'] ) and is_numeric( $Params['Offset'] ) ) ? $Params['Offset'] : 0 ) );

$xmlTaskDef = eZXMLTask::definition();
$persistentTasks = eZXMLTask::fetchObjectList($xmlTaskDef);
$taskSetDef = eZTaskSet::definition();

$taskList = array();
foreach( $persistentTasks as $task )
{
    $conds = array( 'task_id' => $task->attribute('id') );
    $isInTask = eZTaskSet::fetchObjectList($taskSetDef, null, $conds);
    
    if ( $isInTask )
    {
        continue;
    }
    $taskList[] = $task;
}

$tpl->setVariable( 'persistent_tasks', $taskList );
$tpl->setVariable( 'view_parameters', $viewParameters );

$Result = array();
$Result['content'] = $tpl->fetch( "design:xmlinstaller/tasks.tpl" );
$Result['left_menu'] = "design:xmlinstaller/parts/index_left_menu.tpl";
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'xmlinstaller', 'XMLInstaller' ) ),
                         array( 'url' => false,
                                'text' => ezi18n( 'xmlinstaller', 'Tasks list' ) ) );

?>
