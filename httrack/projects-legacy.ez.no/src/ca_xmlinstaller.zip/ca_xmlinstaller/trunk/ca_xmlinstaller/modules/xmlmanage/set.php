<?php
require_once( "kernel/common/template.php" );

$module = $Params['Module'];
$http = eZHTTPTool::instance();
$tpl = templateInit();
$taskID = $Params['task_id'];

if ( $taskID )
{
    $task = eZTaskManager::loadPersistentTaskAsCurrent( $taskID );
    $persistentTask = $task->getPersistentObject();
    
    $name = $persistentTask->attribute('name');
    $tpl->setVariable( 'name', $name );
    $tpl->setVariable( 'task_id', $persistentTask->attribute('id') );
    $tpl->setVariable( 'task_identifier', $task->getTaskIdentifier() );
    
    $taskSetDef = eZTaskSet::definition();
    $conds = array( 'task_set_id' => $taskID );
    $createdChildrenTasks = eZTaskSet::fetchObjectList($taskSetDef, null, $conds);
    
    $createdTasksArray = array();
    $savedReferenceArray = array();
    foreach ( $createdChildrenTasks as $childTask )
    {
            $createdTasksArray[ $childTask->attribute('task_identifier') ] = $childTask;
            
            $xmlReferenceDef = eZXMLReference::definition();
            $conds = array( 'task_id' => $childTask->attribute('task_id') );
            $existingReference = eZXMLReference::fetchObjectList($xmlReferenceDef, null, $conds);
            
            if ( count($existingReference) )
            {
                $savedReferenceArray[ $childTask->attribute('task_identifier') ] = $existingReference;
            }
    }
    $tpl->setVariable( 'created_tasks', $createdTasksArray);
    $tpl->setVariable( 'saved_reference', $savedReferenceArray);
}

$Result = array();
$Result['content'] = $tpl->fetch( "design:xmlinstaller/set.tpl" );
$Result['left_menu'] = "design:xmlinstaller/parts/index_left_menu.tpl";
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'xmlinstaller', 'XMLInstaller' ) ),
                         array( 'url' => false,
                                'text' => ezi18n( 'xmlinstaller', $name ) ) );

?>
