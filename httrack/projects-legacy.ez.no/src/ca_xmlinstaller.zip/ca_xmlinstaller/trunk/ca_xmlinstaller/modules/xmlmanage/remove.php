<?php
require_once( "kernel/common/template.php" );

$module = $Params['Module'];
$http = eZHTTPTool::instance();
$tpl = templateInit();
$taskID = $Params['task_id'];

if ( $taskID )
{
    $task = eZTaskManager::loadPersistentTaskAsCurrent( $taskID );
    $persistentTask = $task->getPersistentObject();

    $persistentTask->remove();
}

$module->redirectToView('tasks');

?>