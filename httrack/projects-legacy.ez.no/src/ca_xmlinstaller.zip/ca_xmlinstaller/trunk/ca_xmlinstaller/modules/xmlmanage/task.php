<?php
require_once( "kernel/common/template.php" );

/*
 * Initialize 
 */
$module = $Params['Module'];
$http = eZHTTPTool::instance();
$xmlInstallerIni = eZINI::instance('xmlinstaller.ini');
$taskIdentifier = $Params['identifier'];
$availableTasks = $xmlInstallerIni->variable('Tasks','AvailableTasks');
$tpl = eZTemplate::factory();
$templateFile = $xmlInstallerIni->variable($Params['identifier'],'TemplateFile');

$tpl->setVariable('view',$Params['FunctionName']);
$XMLtpl = eZTemplate::factory();

$template = 'design:' . $templateFile . '.tpl';

// Fetch Task Template to retrieve needed ressources
$XMLtpl->setVariable( 'tpl_info', false );
$content = $XMLtpl->fetch( $template );

if ( $XMLtpl->variable( "tpl_info" ) !== false )
{
    $tplInfo = $XMLtpl->variable( "tpl_info" );
    $tpl->setVariable('tpl_info',$tplInfo);
}

/*
 * Dispatch action depending on button
 */
if ( $http->hasPostVariable('DiscardButton') )
{
    $module->redirectToView('tasks');
}

if ( $http->hasPostVariable('RemoveButton') )
{
    $xmlTaskDef = eZXMLTask::definition();
    $conds = array('id' => $http->postVariable('task_id'));
    $persistentTask = eZXMLTask::fetchObject($xmlTaskDef, null, $conds);
    
    $xmlSettingsDef = eZXMLSettings::definition();
    $conds = array('persistent_task_id' => $http->postVariable('task_id'));
    $settings = eZXMLSettings::fetchObjectList($xmlSettingsDef, null, $conds);
    
    $xmlReferenceDef = eZXMLReference::definition();
    $conds = array('persistent_task_id' => $http->postVariable('task_id'));
    $references = eZXMLReference::fetchObjectList($xmlReferenceDef, null, $conds);
    
    $taskSetDef = eZTaskSet::definition();
    $conds = array('task_id' => $http->postVariable('task_id'));
    $taskSetBind = eZTaskSet::fetchObject($taskSetDef, null, $conds);
    if ( is_object($taskSetBind) )
    {
        $taskSetBind->remove();
    }
    
    foreach( $settings as $settings_item )
    {
        $settings_item->remove();
    }
    
    foreach( $references as $reference )
    {
        $reference->remove();
    }
    
    $persistentTask->remove();
    
    $module->redirectToView('tasks');
}

if ( $http->hasPostVariable('SavedRunButton') )
{
    $module->redirectToView('run', array($http->postVariable('task_id')));
}
if ( $http->hasPostVariable('PersistentButton') )
{
    if ( !$http->hasPostVariable('task_name') || $http->postVariable('task_name') == '' )
    {
        $module->redirectToView('tasks');
    }
    else
    {
        $newTask = eZXMLTask::create();
        $newTask->setAttribute('name',$http->postVariable('task_name'));
        $newTask->setAttribute('task_id',$taskIdentifier);
        $newTask->store();
        $tpl->setVariable('persistent_task_id',$newTask->attribute('id'));
    }
}
if ( $http->hasPostVariable('UpdateButton') )
{
    $xmlTaskDef = eZXMLTask::definition();
    $conds = array('id' => $http->postVariable('task_id'));
    $persistentTask = eZXMLTask::fetchObject($xmlTaskDef, null, $conds);
    $tpl->setVariable('persistent_task_id',$persistentTask->attribute('id'));
    
    $xmlSettingsDef = eZXMLSettings::definition();
    $conds = array('persistent_task_id' => $http->postVariable('task_id'));
    $settings = eZXMLSettings::fetchObjectList($xmlSettingsDef, null, $conds);
    
    $values = array();
    foreach ( $settings as $settings_item )
    {
        $values[$settings_item->attribute('identifier')] = $settings_item->attribute('value'); 
    }
    $tpl->setVariable('post',$values);
}

if ( $http->hasPostVariable('ValidateButton') || $http->hasPostVariable('SaveButton') )
{
    if ( $Params['FunctionName'] == 'persistent_task')
    {
        $tpl->setVariable('persistent_task_id',$http->postVariable('persistent_task_id'));
    }
    
    $warnings = array();
    $tplInfoDefined = array();
    foreach ( $tplInfo as $infoId => $variable )
    {
        if ( !$http->hasPostVariable($infoId) || $http->postVariable($infoId) == '' )
        {
            $warnings[] = ezi18n( 'xmlinstaller', '%id is required', null, array( '%id' => $variable['info'] ) );
        }
        else
        {
            $tplInfoDefined[$infoId] = array(  'info' => $variable['info'],
                                               'type' => $variable['type'],
                                               'default' => $http->postVariable($infoId)
                                             );
        }
    }
    
    if ( count($warnings) > 0 )
    {
        $tpl->setVariable('warnings', $warnings);
        $tpl->setVariable('post', $_POST);
    }
    else
    {
        if ( $Params['FunctionName'] == 'persistent_task')
        {
            foreach( $tplInfoDefined as $identifier => $settings )
            {
                $settingsDef = eZXMLSettings::definition();
                $conds = array( 'persistent_task_id' => $http->postVariable('persistent_task_id'),
                                'identifier' => $identifier);
                $existingSettings = eZXMLSettings::fetchObject($settingsDef, null, $conds);
                
                if ( $existingSettings )
                {
                    $existingSettings->setAttribute('value', $settings['default']);
                    $existingSettings->store();   
                }
                else
                {
                    $settingsObject = eZXMLSettings::create();
                    $settingsObject->setAttribute('persistent_task_id', $http->postVariable('persistent_task_id'));
                    $settingsObject->setAttribute('identifier', $identifier);
                    $settingsObject->setAttribute('value', $settings['default']);
                    $settingsObject->store();   
                }                
            }
        }
        
        if ( $http->hasPostVariable('ValidateButton') )
        {
            $tpl->setVariable('post', $_POST);
            $tpl->setVariable('is_valid', true);
        }
        elseif ( $http->hasPostVariable('SaveButton') )
        {
            $module->redirectToView('view', array( $http->postVariable('persistent_task_id') ) );
        }
    }
}

$tpl->setVariable('identifier', $taskIdentifier);

$tpl->setVariable('name', $availableTasks[$taskIdentifier]);

$viewParameters = array();

$viewParameters = array_merge( $viewParameters, array( 'offset' => ( isset( $Params['Offset'] ) and is_numeric( $Params['Offset'] ) ) ? $Params['Offset'] : 0 ) );
$tpl->setVariable( 'view_parameters', $viewParameters );

$Result = array();
$Result['content'] = $tpl->fetch( "design:xmlinstaller/task.tpl" );
$Result['left_menu'] = "design:xmlinstaller/parts/index_left_menu.tpl";
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'xmlinstaller', 'XMLInstaller' ) ),
                         array( 'url' => 'xmlmanage/tasks',
                                'text' => ezi18n( 'xmlinstaller', 'Tasks list' ) ),
                         array( 'url' => false,
                                'text' => ezi18n( 'xmlinstaller', $availableTasks[$taskIdentifier] ) ) );

?>
