<?php
require_once( "kernel/common/template.php" );

$module = $Params['Module'];
$http = eZHTTPTool::instance();
$tpl = templateInit();
$taskID = $Params['task_id'];

$task = eZTaskManager::loadPersistentTaskAsCurrent( $taskID );
$persistentTask = $task->getPersistentObject();

$tpl->setVariable( 'name', $persistentTask->attribute('name') );
$tpl->setVariable( 'task_id', $persistentTask->attribute('id') );
$tpl->setVariable( 'tpl_info', $task->getTemplateInfo() );
$tpl->setVariable( 'task_identifier', $task->getTaskIdentifier() );

$Result = array();
$Result['content'] = $tpl->fetch( "design:xmlinstaller/view.tpl" );
$Result['left_menu'] = "design:xmlinstaller/parts/index_left_menu.tpl";
$Result['path'] = array( array( 'url' => false,
                                'text' => ezi18n( 'xmlinstaller', 'XMLInstaller' ) ),
                         array( 'url' => false,
                                'text' => ezi18n( 'xmlinstaller', 'Tasks list' ) ) );

?>
