<?php /*

[RegionalSettings]
TranslationExtensions[]=ezclasslists

*/ ?>
