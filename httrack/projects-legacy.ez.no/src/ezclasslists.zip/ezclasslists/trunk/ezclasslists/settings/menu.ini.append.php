<?php /*
#
# $Id: menu.ini.append.php 14 2009-11-11 21:39:38Z dpobel $
# $HeadURL: http://svn.projects.ez.no/ezclasslists/trunk/ezclasslists/settings/menu.ini.append.php $
#

[NavigationPart]
Part[classlists]=Lists by class

[TopAdminMenu]
Tabs[]=classlists

[Topmenu_classlists]
NavigationPartIdentifier=classlists
Name=Lists by class
Tooltip=List object by content class
URL[]
URL[default]=classlists/list/folder
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[navigation]=true
Shown[default]=true
Shown[browse]=true

*/ ?>
