<?php /* #?ini charset="utf-8"?

[ActionSettings]
ExtensionDirectories[]=subtreelocation

*/
