<?php /* #?ini charset="utf-8"?

[ScriptBin]
# the user name used when adding location with the bin/php/subtreelocation.php script
UserName=admin

[ScriptMonitor]
# Max size for add location direct without schedule in ezscriptmonitor
# MaxSubtreeSize=2


*/ ?>
