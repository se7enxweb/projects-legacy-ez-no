<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=ezscriptmonitor
ModuleList[]=scriptmonitor
#ModuleList[]=test

*/ ?>
