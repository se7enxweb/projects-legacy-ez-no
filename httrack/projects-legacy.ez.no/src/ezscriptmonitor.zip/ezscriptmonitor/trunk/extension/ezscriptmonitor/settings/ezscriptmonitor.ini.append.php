<?php /* #?ini charset="utf-8"?

[GeneralSettings]
ScriptSiteAccess=ezwebin_site_admin
PhpCliCommand=/usr/bin/php

*/ ?>
