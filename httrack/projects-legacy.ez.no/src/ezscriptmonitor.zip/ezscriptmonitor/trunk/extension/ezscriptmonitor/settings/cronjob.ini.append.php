<?php /* #?ini charset="utf8"?

[CronjobSettings]
ExtensionDirectories[]=ezscriptmonitor

[CronjobPart-runscheduledscripts]
Scripts[]
Scripts[]=runscheduledscripts.php

*/?>
