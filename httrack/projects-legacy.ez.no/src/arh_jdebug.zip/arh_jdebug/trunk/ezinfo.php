<?php
class ggxmlviewInfo
{
    static function info()
    {
        return array(
            'Name' => "arh_jdebug",
            'Version' => "0.3-dev",
            'Copyright' => "Copyright (C) 2010-2012 A. Rhouati",
            'License' => "GNU General Public License v2.0"
        );
    }
}
?>
