<?php /*

[DebugJquerySettings]
DebugOutput=enabled

# define the default output to show
# 5 items : httpVariables, timing, templateusage, debug-toolbar
DefaultOutput=templateusage

*/ ?>