<?php /*

[ExtensionSettings]
DesignExtensions[]=arh_jdebug

*/ ?>