<?php /* #?ini charset="utf-8"?

[AuditSettings]
AuditFileNames[ip-login]=ip_login.log
AuditFileNames[ip-change]=ip_change.log

*/ ?>