<?php /* #?ini charset="iso-8859-1"?

[ActionSettings]
ExtensionDirectories[]=cmsxauthip

*/ ?>