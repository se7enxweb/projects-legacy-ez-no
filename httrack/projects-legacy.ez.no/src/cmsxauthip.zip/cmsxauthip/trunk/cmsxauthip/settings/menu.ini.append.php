<?php /*

[NavigationPart]
Part[ezauthipnavigationpart]=IP Authentication

[TopAdminMenu]
Tabs[]=authip

[Topmenu_authip]
NavigationPartIdentifier=ezauthipnavigationpart
Name=IP Authentication
#Tooltip=Administrate IP Authentication
URL[]
URL[default]=authip/view
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[navigation]=true
Shown[default]=true
Shown[browse]=true

*/ ?>
