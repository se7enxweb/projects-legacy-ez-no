<?php /* #?ini charset="utf-8"?

# Action used to select owner of address
[BrowseForAuthIpUser]
ReturnType=ObjectID
SelectionType=single
StartNode=users
Class[]
Class[]=user
TopLevelNodes[]
TopLevelNodes[]=users
*/
?>
