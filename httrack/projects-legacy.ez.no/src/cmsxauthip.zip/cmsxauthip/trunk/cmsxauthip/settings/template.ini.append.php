<?php /*

[PHP]
PHPOperatorList[long2ip]=long2ip

*/ ?>