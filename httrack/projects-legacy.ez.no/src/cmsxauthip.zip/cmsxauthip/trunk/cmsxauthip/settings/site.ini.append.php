<?php /*

[TemplateSettings]
# ExtensionAutoloadPath[]=cmsxauthip

[UserSettings]
ExtensionDirectory[]=cmsxauthip

# Reset array to disable standard login handler that bypass the 
#LoginHandler[]
LoginHandler[]=AuthIP
#SingleSignOnHandlerArray[]
#SingleSignOnHandlerArray[]=AuthIP

[RegionalSettings]
TranslationExtensions[]=cmsxauthip


*/ ?>