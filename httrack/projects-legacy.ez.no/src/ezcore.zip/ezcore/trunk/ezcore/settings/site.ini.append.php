<?php /* #?ini charset="utf-8"?


[TemplateSettings]
ExtensionAutoloadPath[]=ezcore


[SSLZoneSettings] 
ModuleViewAccessMode[ezcore/*]=keep

[RoleSettings]
PolicyOmitList[]=ezcore/hello

[SiteAccessSettings]
AnonymousAccessList[]=ezcore/hello



*/ ?>