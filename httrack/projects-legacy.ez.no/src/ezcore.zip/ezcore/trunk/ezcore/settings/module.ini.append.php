<?php /* #?ini charset="utf-8"?

[ModuleSettings]
ExtensionRepositories[]=ezcore

# DEPRECATED: not needed anymore since index_ajax.php fully supports access rules
ExtensionAjaxRepositories[]=ezcore

ModuleList[]=ezcore

*/ ?>