<?php /* #?ini charset="utf-8"?

[ExtensionSettings]
DesignExtensions[]=ezcore

[StylesheetSettings]
CSSFileList[]=ezcore_admin.css

[JavaScriptSettings]
#JavaScriptList[]=ez_core.js
#JavaScriptList[]=animation.js
#JavaScriptList[]=accordion.js




*/ ?>