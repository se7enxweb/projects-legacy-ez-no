<?php /* #?ini charset="utf-8"?


[CronjobSettings]
ExtensionDirectories[]=ezcore

[CronjobPart-reverse_proxy_purge]
Scripts[]
Scripts[]=reverse_proxy_purge.php


[CronjobSettings-hide_unhide]
Scripts[]
Scripts[]=hide_unhide.php

*/ ?>