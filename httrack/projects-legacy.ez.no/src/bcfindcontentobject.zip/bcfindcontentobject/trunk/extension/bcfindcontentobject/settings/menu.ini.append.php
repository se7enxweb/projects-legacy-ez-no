
[NavigationPart]
Part[findnavigationpart]=Find
 
[TopAdminMenu]
Tabs[]=find
 
[Topmenu_find]
NavigationPartIdentifier=findnavigationpart
Name=Find
Tooltip=Find content objects quickly.
URL[]
URL[default]=find/form
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

