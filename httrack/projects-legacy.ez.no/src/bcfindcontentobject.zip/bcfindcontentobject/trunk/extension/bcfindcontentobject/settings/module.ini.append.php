<?php /*
 
[ModuleSettings] 
ExtensionRepositories[]=bcfindcontentobject
ModuleList[]=find
 
*/ ?>
