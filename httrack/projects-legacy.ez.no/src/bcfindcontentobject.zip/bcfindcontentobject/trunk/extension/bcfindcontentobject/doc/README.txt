README
======

BC Find Content Object

Copyright 2011 Brookins Consulting
License GNU GPL v2 (or later)

----------------------
About
----------------------

This extension when activated provides admin lookup of content objects.

It provides lookup based on content object name, user name, user email, node_id, object_id

----------------------
Install
----------------------

Unpack extension into extension directory.

Activate extension

Load admin, click on the 'Find' menu, search for content as needed

