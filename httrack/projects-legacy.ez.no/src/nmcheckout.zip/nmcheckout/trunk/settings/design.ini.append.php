<?php
/*
[ExtensionSettings]
DesignExtensions[]=nmcheckout
DesignExtensions[]=nmlibjquery
DesignExtensions[]=nmlibjquery_autocomplete

[StylesheetSettings]
CSSFileList[]=checkout.css

[JavaScriptSettings]
JavaScriptList[]=jquery-latest.js
JavaScriptList[]=jquery.tools.min.js
JavaScriptList[]=checkout_tip.js
JavaScriptList[]=jquery.ajaxQueue.js
JavaScriptList[]=jquery.autocomplete.pack.js
JavaScriptList[]=jquery.bgiframe.min.js
JavaScriptList[]=checkout_admin.js
JavaScriptList[]=checkout.js
*/
?>