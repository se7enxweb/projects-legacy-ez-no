[RegionalSettings]
TranslationExtensions[]=nmcheckout