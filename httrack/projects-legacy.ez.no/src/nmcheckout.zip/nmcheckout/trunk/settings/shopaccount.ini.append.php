[HandlerSettings]
# A list of extensions which have shop account handlers
# It's common to create a settings/shopaccount.ini.append file
# in your extension and add the extension name to automatically
# get handlers from the extension when it's turned on.
ExtensionRepositories[]=nmcheckout
