<!DOCTYPE TS><TS>
<context>
    <name>checkout/accountview/html</name>
    <message>
        <source>Delivery address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Att</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT no.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delivery and invoice address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invoice address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>checkout/accountview/text</name>
    <message>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT no.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delivery and invoice address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invoice address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>checkout/confirmationmail</name>
    <message>
        <source>Hi %firstname %lastname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>We have registred the following on you</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT no.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delivery address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Att</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>checkout/design</name>
    <message>
        <source>My page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login needed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>checkout/edit</name>
    <message>
        <source>Edit order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit order [%count]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This order was made with another shouaccounthandler, and could not be edited.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please contact the site administrator if you have questions about this</source>
        <translation type="obsolete"></translation>
    </message>
    <message>
        <source>Please contact the site administrator if you have questions about this.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit products for order [%order_id]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search for product to add to the order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total price ex. vat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total price inc. vat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The product amount is not numeric and bigger than zero. Its now set back.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete marked products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orderlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>checkout/global</name>
    <message>
        <source>Shopping basket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order summary</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>checkout/login</name>
    <message>
        <source>Existing client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forgot your password?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose client type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The email or/and password was wrong, please try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>From 20.09.2009 everybody haft to register as new customer, due to new shop process</source>
        <translation type="obsolete"></translation>
    </message>
</context>
<context>
    <name>checkout/mypage</name>
    <message>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to see the details of your order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order no. %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You need to be logged in to see this page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can log in here.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>checkout/register</name>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order data invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your order data did not fully validate. Please correct the errors below, and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Company</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VAT no.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>We&apos;ll send a copy of the order to this email address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please provide a password to make it easier to shop with us again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Repeat your password to ensure that you&apos;ve spelled it correctly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delivery address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Street</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invoice address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Same as delivery address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delivery method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact first name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact last name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No result found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To short search string</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Terms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I accept the terms</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>customshop</name>
    <message>
        <source>Shop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/content/datatype/ezuser</name>
    <message>
        <source>Account status</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/admin/shop/orderlist</name>
    <message>
        <source>Orders [%count]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert selection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (ex. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total (inc. VAT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select order for removal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>( removed )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The order list is empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Archive selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Archive selected orders.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click this button to store changes if you have modified any of the fields above.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>design/standard/content/datatype</name>
    <message>
        <source>User ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>locked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configure user account settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View order list</source>
        <translation type="obsolete"></translation>
    </message>
</context>
<context>
    <name>elby/confirmationmail</name>
    <message>
        <source>Delivery and invoice adress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invoice address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>nmcheckout/confirmationmail</name>
    <message>
        <source>Confirmation on registred user at %sitename (%siteurl)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>nmcheckout/content/datatype</name>
    <message>
        <source>View order list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
