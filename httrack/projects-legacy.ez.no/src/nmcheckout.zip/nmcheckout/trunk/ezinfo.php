<?php

class nmCheckoutInfo
{
    static function info()
    {
        return array(
            'Name' => '<a href="http://projects.ez.no/nmcheckout">NM Checkout</a> extension',
            'Version' => '1.0-0',
            'Author' => "<a href='http://www.netmaking.no/'>Netmaking - Webdesign and CMS</a>",
            'Copyright' => "Copyright (C) 2009-2010 Netmaking AS",
            'License' => 'GNU General Public License v2.0',
        );
    }
}

?>
