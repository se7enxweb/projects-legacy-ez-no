<!DOCTYPE TS><TS>
<context>
    <name>extension/ezmultiupload</name>
    <message>
        <source>Multiupload</source>
        <translation>Multi-upload</translation>
    </message>
    <message>
        <source>The files are uploaded to</source>
        <translation>Os arquivos serão enviados para</translation>
    </message>
    <message>
        <source>Select files</source>
        <translation>Selecionar arquivos</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <source>Starting...</source>
        <translation>Iniciando...</translation>
    </message>
    <message>
        <source>Thumbnail created.</source>
        <translation>Miniatura criada.</translation>
    </message>
    <message>
        <source>All files received.</source>
        <translation>Todos os arquivos foram recebidos.</translation>
    </message>
    <message>
        <source>Unable to load Flash content. You can download the latest version of Flash Player from the</source>
        <translation>Não foi possível carregar conteúdo em Flash. Você pode baixar a versão mais recente do Flash Player de</translation>
    </message>
    <message>
        <source>Adobe Flash Player Download Center</source>
        <translation>Centro de downloads do Adobe Flash Player</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Upload canceled.</source>
        <translation>Envio cancelado</translation>
    </message>
</context>
<context>
    <name>design/admin/popupmenu</name>
    <message>
        <source>Upload multiple files</source>
        <translation>Enviar múltiplos arquivos</translation>
    </message>
</context>
</TS>
