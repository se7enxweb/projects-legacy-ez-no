<!DOCTYPE TS><TS>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Template Location</source>
        <translation>Template Pfad</translation>
    </message>
    <message>
        <source>Empty</source>
        <translation>Leer</translation>
    </message>
</context>
<context>
    <name>extension/ezxmkinstaller</name>
    <message>
        <source>XML Publisher</source>
        <translation>XML Publizierer</translation>
    </message>
</context>
<context>
    <name>ezxmlinstaller/datatypes</name>
    <message>
        <source>Feature Select</source>
        <comment>Datatype name</comment>
        <translation>Funktionsauswahl</translation>
    </message>
</context>
</TS>
