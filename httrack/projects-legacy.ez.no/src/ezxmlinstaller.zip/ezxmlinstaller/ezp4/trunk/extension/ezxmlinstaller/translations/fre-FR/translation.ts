<!DOCTYPE TS><TS>
<context>
    <name>design/standard/class/datatype</name>
    <message>
        <source>Template Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extension/ezxmkinstaller</name>
    <message>
        <source>XML Publisher</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ezxmlinstaller/datatypes</name>
    <message>
        <source>Feature Select</source>
        <comment>Datatype name</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
