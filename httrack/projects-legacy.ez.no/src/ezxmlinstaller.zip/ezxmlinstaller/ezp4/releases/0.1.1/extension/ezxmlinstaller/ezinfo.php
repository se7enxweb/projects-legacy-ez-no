<?php

class ezxmlinstallerInfo
{
    function info()
    {
        return array( 'Name' => "eZ Publish XML Installer",
                      'Version' => "0.0.1",
                      'Copyright' => "Copyright (C) 2007 dis@ez.no",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>