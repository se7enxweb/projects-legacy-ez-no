<?php

$Module = array( "name" => "reCAPTCHA" );
$FunctionList['bypass_captcha'] = array();

?>
