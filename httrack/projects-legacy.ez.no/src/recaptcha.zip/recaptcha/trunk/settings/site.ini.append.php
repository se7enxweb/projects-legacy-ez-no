<?php /* #?ini charset="utf-8"?

[TemplateSettings]
ExtensionAutoloadPath[]=recaptcha

#[RegionalSettings]
#TranslationExtensions[]=recaptcha

*/ ?>
