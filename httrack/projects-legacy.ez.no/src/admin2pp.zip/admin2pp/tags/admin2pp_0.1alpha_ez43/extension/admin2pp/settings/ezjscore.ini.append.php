<?php /*
#
# $Id: ezjscore.ini.append.php 96 2010-03-24 22:10:34Z dpobel $
# $HeadURL: http://svn.projects.ez.no/admin2pp/tags/admin2pp_0.1alpha_ez43/extension/admin2pp/settings/ezjscore.ini.append.php $
#

[eZJSCore]
ExternalScripts[jqueryui]=http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js
LocalScripts[jqueryui]=jquery-ui-1.8.0.min.js
Packer=3

[Packer]
AppendLastModifiedTime=enabled


[ezjscServer]
FunctionList[]=admin2ppajax

[ezjscServer_admin2pp]
Class=admin2ppFunctions
File=extension/admin2pp/classes/admin2ppfunctions.php

[ezjscServer_admin2ppajax]
Class=admin2ppAjaxFunctions
File=extension/admin2pp/classes/admin2ppajaxfunctions.php


*/ ?>
