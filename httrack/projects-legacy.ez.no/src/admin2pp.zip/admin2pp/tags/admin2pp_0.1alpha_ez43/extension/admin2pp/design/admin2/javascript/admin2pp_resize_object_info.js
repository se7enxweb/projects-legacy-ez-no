/**
 * $Id: admin2pp_resize_object_info.js 93 2010-03-22 12:48:53Z dpobel $
 * $HeadURL: http://svn.projects.ez.no/admin2pp/tags/admin2pp_0.1alpha_ez43/extension/admin2pp/design/admin2/javascript/admin2pp_resize_object_info.js $
 */

function admin2ppObjectInfoResizable( prefName, height )
{
    var tmpArray = height.split( ',' );
    this.prefName = prefName;
    this.heightBox = parseInt( tmpArray[0] );
    this.heightTab = parseInt( tmpArray[1] );
    if ( !this.heightTab || !this.heightBox )
    {
        this.heightTab = 0;
        this.heightBox = 0;
    }
    this.globalSelector = '#fix .box-content:first';
    this.tabSelector = '.tab-content';
}

admin2ppObjectInfoResizable.prototype =
{
    init:function()
         {
             var instance = this;
             var elt = jQuery( this.globalSelector )

             if ( this.heightBox != 0 && this.heightTab != 0 )
             {
                 this.initSize();
             }
             elt.resizable( { handles: 's',
                              alsoResize: instance.tabSelector,
                              minHeight: 30,
                              stop: function( evt, ui )
                                    {
                                        instance.heightBox = jQuery( instance.globalSelector ). height();
                                        instance.heightTab = jQuery( instance.tabSelector ).height();
                                        admin2ppAjaxSavePreference( instance.prefName, instance.heightBox + ',' + instance.heightTab );
                                        jQuery( instance.globalSelector ).css( 'width', 'auto' );
                                        jQuery( instance.tabSelector ).css( 'width', 'auto' );
                                    }
                            } );
         },

    initSize:function()
             {
                jQuery( this.globalSelector ).css( 'height', this.heightBox + 'px' );
                jQuery( this.tabSelector ).css( 'height', this.heightTab + 'px' );
             }

}
