<?php /*
#
# $Id: icon.ini.append.php 21 2010-02-20 12:56:56Z dpobel $
# $HeadURL: http://svn.projects.ez.no/admin2pp/tags/admin2pp_0.1alpha_ez43/extension/admin2pp/settings/icon.ini.append.php $
#

[IconSettings]
Theme=crystal-admin-opt43
Repository=extension/admin2pp/share/icons

*/ ?>
