<?php /*
#
# $Id: module.ini.append.php 42 2010-03-01 15:39:03Z dpobel $
# $HeadURL: http://svn.projects.ez.no/admin2pp/trunk/extension/admin2pp/settings/module.ini.append.php $
#

[ModuleSettings]
ExtensionRepositories[]=admin2pp


*/ ?>
