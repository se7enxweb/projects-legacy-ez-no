<?php

class dpgnuInfo
{
    static function info()
    {
        return array( 'name' => 'dP Google News URL',
                      'version' => '2.0.3',
                      'copyright' => 'Copyright (C) 2007 Damien Pitard',
                      'license'   => 'GNU General Public License v2.0' );
    }
}
?>