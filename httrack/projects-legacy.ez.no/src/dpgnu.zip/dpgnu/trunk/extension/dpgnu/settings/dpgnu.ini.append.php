<?php /* #?ini charset="iso-8859-1"?

[GNUSettings]
# Classes where node_id should be added in URL
Classes[]=
Classes[]=article

# Do not add node_id for children of...
IgnoreChildrenOf[]

*/ ?>