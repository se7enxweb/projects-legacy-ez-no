<?php /* #?ini charset="iso-8859-1"?

[GNUSettings]
Classes[]=
Classes[]=article

IgnoreChildrenOf[]

*/ ?>