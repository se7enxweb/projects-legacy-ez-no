<?php /*

[ExtensionSettings]
DesignExtensions[]=rbgadmin

*/ ?>