<?php
class ggsysinfoInfo
{
    static function info()
    {
        return array( 'Name' => "rbgadmin",
                      'Version' => "0.1",
                      'Copyright' => "Copyright (C) 2009 R. Benedetti",
                      'License' => "GNU General Public License v2.0"
                     );
    }
}
?>